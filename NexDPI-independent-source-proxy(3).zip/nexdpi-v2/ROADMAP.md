# NexDPI roadmap

## Current alpha

NexDPI keeps its own Android UI, VPN service, TUN packet dispatcher, whitelist, proxy manager, and TCP/UDP relays. The native TCP/UDP desynchronization engine is integrated from hufrea/byedpi under its MIT license at a fixed upstream commit. The ByeDPI Android application and its UI are not used.

## Next validation

- Build native libraries for arm64-v8a, armeabi-v7a, and x86_64 in GitHub Actions.
- Validate local SOCKS5 CONNECT and UDP ASSOCIATE on a physical Android device.
- Test DNS, TCP/TLS, UDP/QUIC on Wi-Fi and mobile networks.
- Measure latency, throughput, battery use, and recovery after network changes.
- Keep the one-button interface and hide CLI arguments behind preset selection.

No local engine can promise access when the destination IP, route, or all usable transport paths are blocked. NexDPI has no VPS or remote tunnel.
