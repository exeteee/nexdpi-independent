# Third-party engine notice

NexDPI integrates the native TCP/UDP desynchronization core from [hufrea/byedpi](https://github.com/hufrea/byedpi), pinned to upstream commit `e2684772fbda45f2ff4fc220922a010370534216`. The upstream core is distributed under the MIT License; its LICENSE file is fetched and retained in the build source directory before compilation.

The NexDPI Android application, original UI, VPN service, packet dispatcher, whitelist, and proxy manager remain separate. This integration does not use the ByeDPI Android application or its interface.
