#include <jni.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <android/log.h>

#include "params.h"
#include "proxy.h"

/* Public entry points from ByeDPI's own command-line implementation. */
extern int parse_args(int argc, char **argv);
extern int init(void);

#define TAG "NexDPI-Native"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

static pthread_mutex_t engine_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_t engine_thread;
static int engine_listener = -1;
static int engine_started = 0;

static void *engine_loop(void *opaque) {
    int fd = (int)(intptr_t)opaque;
    int result = start_event_loop(fd);
    if (result != 0) LOGE("ByeDPI event loop exited: %d", result);
    return NULL;
}

/* Fixed internal strategy ladder; the app exposes no command-line arguments or tuning UI.
 * Profile 1: TCP/443 disorder and UDP/443 fake datagrams. On timeout/redirect/TLS error, try SNI-aware split + TLS record split.
 * On another failure, try a different SNI-relative split boundary.
 */
JNIEXPORT jint JNICALL
Java_com_exeteee_nexdpi_vpn_ByeDpiNative_nativeStart(JNIEnv *env, jobject thiz, jint port) {
    (void)env;
    (void)thiz;
    if (port < 1 || port > 65535) return -10;

    pthread_mutex_lock(&engine_lock);
    if (engine_started) {
        pthread_mutex_unlock(&engine_lock);
        return 0;
    }

    char port_text[8];
    snprintf(port_text, sizeof(port_text), "%d", (int)port);
    char *argv[] = {
        (char *)"nexdpi-native",
        (char *)"-i", (char *)"127.0.0.1",
        (char *)"-p", port_text,
        (char *)"-c", (char *)"256",
        (char *)"-b", (char *)"16384",
        (char *)"-K", (char *)"t,u",
        (char *)"-V", (char *)"443",
        (char *)"-d", (char *)"1",
        (char *)"-a", (char *)"1",
        (char *)"-t", (char *)"8",
        (char *)"-A", (char *)"t,r,s",
        (char *)"-K", (char *)"t,h",
        (char *)"-V", (char *)"443",
        (char *)"-s", (char *)"1+s",
        (char *)"-r", (char *)"1+s",
        (char *)"-A", (char *)"t,r,s",
        (char *)"-K", (char *)"t,h",
        (char *)"-V", (char *)"443",
        (char *)"-s", (char *)"0+sm",
        (char *)"-r", (char *)"0+sm",
        NULL
    };
    const int argc = (int)(sizeof(argv) / sizeof(argv[0])) - 1;

    int result = parse_args(argc, argv);
    if (result != 0) {
        LOGE("ByeDPI parse_args failed: %d", result);
        pthread_mutex_unlock(&engine_lock);
        return -11;
    }
    if (init() < 0) {
        LOGE("ByeDPI init failed");
        pthread_mutex_unlock(&engine_lock);
        return -12;
    }

    engine_listener = listen_socket(&params.laddr);
    if (engine_listener < 0) {
        LOGE("ByeDPI local SOCKS5 listener failed");
        pthread_mutex_unlock(&engine_lock);
        return -13;
    }

    if (pthread_create(&engine_thread, NULL, engine_loop, (void *)(intptr_t)engine_listener) != 0) {
        close(engine_listener);
        engine_listener = -1;
        LOGE("ByeDPI event thread creation failed");
        pthread_mutex_unlock(&engine_lock);
        return -14;
    }
    pthread_detach(engine_thread);
    engine_started = 1;
    LOGI("Native ByeDPI core started on 127.0.0.1:%d", (int)port);
    pthread_mutex_unlock(&engine_lock);
    return 0;
}
