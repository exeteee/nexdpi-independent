package com.exeteee.nexdpi.vpn

import java.io.EOFException
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

/** Local native ByeDPI SOCKS5 bridge. Strategy selection is compiled in; no user arguments. */
object ByeDpiNative {
    const val LOCAL_PORT = 18764
    private const val CONNECT_TIMEOUT_MS = 5_000
    @Volatile private var libraryLoaded = false
    @Volatile private var engineReady = false

    @Synchronized
    fun ensureStarted(): Boolean {
        if (engineReady) return true
        return try {
            if (!libraryLoaded) {
                System.loadLibrary("byedpi")
                libraryLoaded = true
            }
            engineReady = nativeStart(LOCAL_PORT) == 0
            engineReady
        } catch (_: UnsatisfiedLinkError) {
            false
        } catch (_: SecurityException) {
            false
        }
    }

    /** Called after VpnService.protect(socket); the native engine owns the real destination socket. */
    @Throws(IOException::class)
    fun connect(socket: Socket, destination: InetAddress, port: Int, timeoutMillis: Int) {
        if (!ensureStarted()) throw IOException("Native DPI engine did not start")
        socket.connect(InetSocketAddress(InetAddress.getByAddress(byteArrayOf(127, 0, 0, 1)), LOCAL_PORT), timeoutMillis)
        socket.soTimeout = timeoutMillis.coerceIn(250, 30_000)
        val input = socket.getInputStream()
        val output = socket.getOutputStream()

        output.write(byteArrayOf(0x05, 0x01, 0x00)) // SOCKS5, one method, no authentication
        output.flush()
        val greeting = readFully(input, 2)
        if (greeting[0].toInt() != 5 || greeting[1].toInt() != 0) {
            throw IOException("Local SOCKS5 engine rejected no-auth mode")
        }

        val address = destination.address
        val addressType = when (address.size) {
            4 -> 1
            16 -> 4
            else -> throw IOException("Unsupported destination address family")
        }
        val request = ByteArray(4 + address.size + 2)
        request[0] = 5
        request[1] = 1 // CONNECT
        request[2] = 0
        request[3] = addressType.toByte()
        System.arraycopy(address, 0, request, 4, address.size)
        request[4 + address.size] = (port ushr 8).toByte()
        request[5 + address.size] = port.toByte()
        output.write(request)
        output.flush()

        val reply = readFully(input, 4)
        if (reply[0].toInt() != 5 || reply[1].toInt() != 0) {
            throw IOException("Native DPI SOCKS5 CONNECT failed (code ${reply[1].toInt() and 0xff})")
        }
        val boundAddressLength = when (reply[3].toInt() and 0xff) {
            1 -> 4
            4 -> 16
            3 -> readFully(input, 1)[0].toInt() and 0xff
            else -> throw IOException("Invalid SOCKS5 bind address type")
        }
        readFully(input, boundAddressLength + 2) // bind address and port
        socket.soTimeout = 0
    }

    private fun readFully(input: java.io.InputStream, length: Int): ByteArray {
        val result = ByteArray(length)
        var offset = 0
        while (offset < length) {
            val count = input.read(result, offset, length - offset)
            if (count < 0) throw EOFException("Unexpected EOF in local SOCKS5 handshake")
            if (count == 0) continue
            offset += count
        }
        return result
    }

    private external fun nativeStart(port: Int): Int
}
