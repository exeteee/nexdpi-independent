package com.exeteee.nexdpi.vpn

import java.io.Closeable
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.security.SecureRandom
import java.util.ArrayDeque
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Local TCP-to-socket relay for NexDPI's routed TUN path. It terminates the app-facing TCP
 * handshake, opens a protected direct socket to the real destination, and translates the two
 * byte streams. Flow state is bounded; physical-device behavior still requires validation.
 */
class TcpFlowRelay(
    private val protectSocket: (Socket) -> Boolean,
    private val packetWriter: (ByteArray) -> Unit,
    private val maxFlows: Int = DEFAULT_MAX_FLOWS,
    private val connectTimeoutMillis: Int = DEFAULT_CONNECT_TIMEOUT_MILLIS,
    private val idleTimeoutMillis: Long = DEFAULT_IDLE_TIMEOUT_MILLIS,
    private val mtu: Int = DEFAULT_MTU,
    private val tlsSplitSelector: TlsSplitStrategySelector = TlsSplitStrategySelector(),
    private val tlsSplitDelayMillis: Long = DEFAULT_TLS_SPLIT_DELAY_MILLIS,
    private val tlsInspectionEnabled: Boolean = true,
    private val initialServerSequence: () -> Long = {
        SecureRandom().nextInt().toLong() and SEQUENCE_MASK
    },
    private val socketFactory: () -> Socket = { Socket() },
    private val socketConnector: (Socket, InetAddress, Int, Int) -> Unit = { socket, address, port, timeout ->
        socket.connect(InetSocketAddress(address, port), timeout)
    }
) : Closeable {
    private enum class State { CONNECTING, SYN_ACK_SENT, ESTABLISHED, APP_FIN, REMOTE_FIN, CLOSING, CLOSED }

    private data class FlowKey(
        val ipVersion: Int,
        val sourceAddress: String,
        val destinationAddress: String,
        val sourcePort: Int,
        val destinationPort: Int
    )

    private data class PendingSegment(
        val endSequence: Long,
        val packet: ByteArray,
        var lastSentNanos: Long,
        var attempts: Int
    )

    private class Flow(
        val key: FlowKey,
        val template: TcpSegment,
        val clientInitialSequence: Long,
        val serverInitialSequence: Long
    ) {
        val closed = AtomicBoolean(false)
        val lastActivityNanos = AtomicLong(System.nanoTime())
        val monitor = Object()
        val pending = ArrayDeque<PendingSegment>()
        val clientStream = TcpSlidingWindow(addSequence(clientInitialSequence, 1))
        val tlsHelloGate = TlsClientHelloGate()
        val tlsOutcomeRecorded = AtomicBoolean(false)
        @Volatile var tlsHost: String? = null
        @Volatile var tlsStrategy: TlsSplitPoint? = null
        @Volatile var tlsAttemptAtNanos: Long = 0L
        @Volatile var state = State.CONNECTING
        @Volatile var socket: Socket? = null
        @Volatile var reader: Thread? = null
        var nextClientSequence = addSequence(clientInitialSequence, 1)
        var nextServerSequence = addSequence(serverInitialSequence, 1)
        var lastAcknowledgedServerSequence = addSequence(serverInitialSequence, 1)
        var peerWindow = DEFAULT_PEER_WINDOW
        var duplicateAcks = 0
        @Volatile var appFin = false
        @Volatile var remoteFin = false

        companion object {
            private const val DEFAULT_PEER_WINDOW = 32_768
        }
    }

    private val lock = Any()
    private val flows = LinkedHashMap<FlowKey, Flow>(16, 0.75f, true)
    private val closed = AtomicBoolean(false)

    init {
        require(maxFlows in 1..MAX_ALLOWED_FLOWS) { "maxFlows must be 1..$MAX_ALLOWED_FLOWS" }
        require(connectTimeoutMillis in 250..30_000) { "Invalid TCP connect timeout" }
        require(idleTimeoutMillis in 5_000..MAX_IDLE_TIMEOUT_MILLIS) { "Invalid TCP idle timeout" }
        require(mtu in 576..65_535) { "Invalid TCP MTU" }
        require(tlsSplitDelayMillis in 0..250) { "Invalid TLS split delay" }
    }

    /** Accepts one app-originated IPv4/IPv6 TCP packet. Invalid checksums are discarded. */
    fun handlePacket(packet: ByteArray, length: Int = packet.size) {
        if (closed.get()) return
        val segment = TcpPacketCodec.parse(packet, length) ?: return
        if (!TcpPacketCodec.isValidTcpChecksum(segment, packet)) return
        handle(segment)
    }

    fun handle(segment: TcpSegment) {
        if (closed.get()) return
        val key = segment.toKey()
        if (segment.isSyn && !segment.isAck) {
            handleSyn(key, segment)
            return
        }
        val flow = synchronized(lock) { flows[key] } ?: return
        flow.lastActivityNanos.set(System.nanoTime())

        if (segment.isRst) {
            removeFlow(flow)
            return
        }

        var shouldRemoveAfterHandling = false
        synchronized(flow.monitor) {
            if (segment.isSyn) {
                // Retransmitted initial SYN: resend the same SYN-ACK when it is ready.
                if (segment.sequenceNumber == flow.clientInitialSequence && flow.state != State.CONNECTING) {
                    sendSynAck(flow)
                }
                return
            }

            if (segment.isAck) acknowledgeRemoteBytes(flow, segment.acknowledgementNumber, segment.windowSize)

            if (flow.state == State.SYN_ACK_SENT && segment.isAck &&
                segment.acknowledgementNumber == flow.nextServerSequence) {
                flow.state = State.ESTABLISHED
                flow.monitor.notifyAll()
            }

            if (flow.state == State.ESTABLISHED || flow.state == State.APP_FIN || flow.state == State.REMOTE_FIN) {
                if (processClientPayloadLocked(flow, segment)) {
                    // Close after releasing the per-flow monitor to avoid lock inversion.
                    flow.state = State.CLOSING
                    flow.monitor.notifyAll()
                    shouldRemoveAfterHandling = true
                }
            }
        }
        if (shouldRemoveAfterHandling) removeFlow(flow)
    }

    fun activeFlowCount(): Int = synchronized(lock) { flows.size }

    private fun handleSyn(key: FlowKey, segment: TcpSegment) {
        val existing = synchronized(lock) { flows[key] }
        if (existing != null) {
            if (segment.sequenceNumber == existing.clientInitialSequence && existing.state != State.CONNECTING) {
                sendSynAck(existing)
            }
            return
        }

        val serverIsn = initialServerSequence() and SEQUENCE_MASK
        val flow = Flow(key, segment.copyDeep(), segment.sequenceNumber, serverIsn)
        synchronized(lock) {
            if (closed.get()) return
            pruneExpiredLocked()
            if (flows.size >= maxFlows) {
                sendReset(segment, serverIsn)
                return
            }
            flows[key] = flow
        }
        flow.reader = Thread({ connectAndRead(flow) }, "NexDPI-TCP-flow").apply {
            isDaemon = true
            start()
        }
    }

    private fun connectAndRead(flow: Flow) {
        if (closed.get() || flow.closed.get()) return
        var connectingSocket: Socket? = null
        val socket = try {
            socketFactory().also { created ->
                connectingSocket = created
                flow.socket = created
                // Publish the connecting socket so VPN shutdown can interrupt connect().
                if (closed.get() || flow.closed.get()) throw IOException("TCP relay closed during connect")
                if (!protectSocket(created)) throw IOException("Unable to protect TCP socket from VPN loop")
                created.tcpNoDelay = true
                socketConnector(
                    created,
                    InetAddress.getByAddress(flow.template.destinationAddress),
                    flow.template.destinationPort,
                    connectTimeoutMillis
                )
                created.soTimeout = READ_POLL_TIMEOUT_MILLIS
            }
        } catch (_: Exception) {
            try { connectingSocket?.close() } catch (_: Exception) { }
            sendReset(flow)
            removeFlow(flow)
            return
        }

        if (closed.get() || flow.closed.get()) {
            try { socket.close() } catch (_: Exception) { }
            return
        }
        flow.socket = socket
        flow.state = State.SYN_ACK_SENT
        sendSynAck(flow)

        try {
            val input = socket.getInputStream()
            val buffer = ByteArray(DATA_MSS)
            while (!closed.get() && !flow.closed.get()) {
                if (isIdle(flow)) {
                    recordTlsOutcome(flow, remoteResponded = false)
                    break
                }
                try {
                    val count = input.read(buffer)
                    if (count < 0) {
                        waitForHandshake(flow)
                        recordTlsOutcome(flow, remoteResponded = false)
                        if (flow.state == State.SYN_ACK_SENT) {
                            sendReset(flow)
                            break
                        }
                        handleRemoteEof(flow)
                        maintainAfterRemoteEof(flow)
                        break
                    }
                    if (count == 0) continue
                    flow.lastActivityNanos.set(System.nanoTime())
                    recordTlsOutcome(flow, remoteResponded = true)
                    waitForHandshake(flow)
                    if (flow.closed.get()) break
                    if (flow.state == State.SYN_ACK_SENT) {
                        sendReset(flow)
                        removeFlow(flow)
                        break
                    }
                    if (flow.state == State.ESTABLISHED || flow.state == State.APP_FIN || flow.state == State.REMOTE_FIN) {
                        sendRemoteData(flow, buffer.copyOf(count))
                    }
                } catch (_: SocketTimeoutException) {
                    flushExpiredClientHello(flow)
                    recordTlsOutcomeIfTimedOut(flow)
                    retransmitIfDue(flow)
                }
            }
        } catch (_: Exception) {
            recordTlsOutcome(flow, remoteResponded = false)
            if (!flow.closed.get()) sendReset(flow)
        } finally {
            removeFlow(flow)
        }
    }

    private fun waitForHandshake(flow: Flow) {
        synchronized(flow.monitor) {
            var remaining = HANDSHAKE_WAIT_MILLIS
            while (!flow.closed.get() && flow.state == State.SYN_ACK_SENT && remaining > 0) {
                val started = System.nanoTime()
                flow.monitor.wait(HANDSHAKE_POLL_MILLIS)
                val elapsed = (System.nanoTime() - started) / NANOS_PER_MILLISECOND
                remaining -= elapsed.coerceAtLeast(1)
            }
        }
    }

    /** Returns true when the caller must tear this flow down. flow.monitor is held. */
    private fun processClientPayloadLocked(flow: Flow, segment: TcpSegment): Boolean {
        if (segment.payload.isNotEmpty()) {
            val newlyContiguous = flow.clientStream.accept(segment.sequenceNumber, segment.payload)
            if (newlyContiguous == null) {
                sendReset(flow)
                return true
            }
            flow.nextClientSequence = flow.clientStream.nextSequence()
            if (newlyContiguous.isNotEmpty()) {
                try {
                    val socket = flow.socket ?: return true
                    if (!tlsInspectionEnabled) {
                        val output = socket.getOutputStream()
                        output.write(newlyContiguous)
                        output.flush()
                    } else when (val decision = flow.tlsHelloGate.append(newlyContiguous)) {
                        TlsGateDecision.Hold -> Unit
                        is TlsGateDecision.ForwardRaw -> {
                            val output = socket.getOutputStream()
                            output.write(decision.bytes)
                            output.flush()
                        }
                        is TlsGateDecision.SplitClientHello -> {
                            val host = decision.hello.serverName
                            val strategy = tlsSplitSelector.next(host)
                            flow.tlsHost = host
                            flow.tlsStrategy = strategy
                            flow.tlsAttemptAtNanos = System.nanoTime()
                            flow.tlsOutcomeRecorded.set(false)
                            TlsSplitWriter.write(
                                socket = socket,
                                stream = decision.bytes,
                                hello = decision.hello,
                                strategy = strategy,
                                interWriteDelayMillis = tlsSplitDelayMillis
                            )
                        }
                    }
                } catch (_: Exception) {
                    sendReset(flow)
                    return true
                }
            }
        }

        if (segment.isFin) {
            val finSequence = addSequence(segment.sequenceNumber, segment.payload.size.toLong())
            if (finSequence == flow.nextClientSequence && !flow.appFin) {
                flow.appFin = true
                flow.nextClientSequence = addSequence(flow.nextClientSequence, 1)
                try { flow.socket?.shutdownOutput() } catch (_: Exception) { }
                flow.state = if (flow.remoteFin) State.CLOSING else State.APP_FIN
            }
        }

        sendAck(flow)
        return flow.appFin && flow.remoteFin && flow.pending.isEmpty()
    }


    private fun recordTlsOutcomeIfTimedOut(flow: Flow) {
        if (flow.tlsStrategy == null || flow.tlsOutcomeRecorded.get()) return
        val elapsed = System.nanoTime() - flow.tlsAttemptAtNanos
        if (elapsed >= TLS_REMOTE_RESPONSE_TIMEOUT_NANOS) {
            recordTlsOutcome(flow, remoteResponded = false)
        }
    }

    private fun recordTlsOutcome(flow: Flow, remoteResponded: Boolean) {
        val strategy = flow.tlsStrategy ?: return
        if (!flow.tlsOutcomeRecorded.compareAndSet(false, true)) return
        tlsSplitSelector.recordOutcome(flow.tlsHost, strategy, remoteResponded)
    }

    private fun flushExpiredClientHello(flow: Flow) {
        val expired = flow.tlsHelloGate.flushIfExpired() ?: return
        try {
            val output = flow.socket?.getOutputStream() ?: return
            output.write(expired)
            output.flush()
        } catch (_: Exception) {
            sendReset(flow)
            removeFlow(flow)
        }
    }

    private fun sendSynAck(flow: Flow) {
        val mss = maxPayload(flow)
        val options = byteArrayOf(2, 4, (mss ushr 8).toByte(), mss.toByte())
        emit(
            flow,
            sequence = flow.serverInitialSequence,
            acknowledgement = flow.nextClientSequence,
            flags = TcpPacketCodec.FLAG_SYN or TcpPacketCodec.FLAG_ACK,
            window = LOCAL_RECEIVE_WINDOW,
            options = options
        )
    }

    private fun sendAck(flow: Flow) {
        synchronized(flow.monitor) {
            emit(
                flow,
                sequence = flow.nextServerSequence,
                acknowledgement = flow.nextClientSequence,
                flags = TcpPacketCodec.FLAG_ACK,
                window = LOCAL_RECEIVE_WINDOW
            )
        }
    }

    private fun sendRemoteData(flow: Flow, bytes: ByteArray) {
        recordTlsOutcome(flow, remoteResponded = true)
        var offset = 0
        val mss = maxPayload(flow)
        while (offset < bytes.size && !flow.closed.get()) {
            val chunk = bytes.copyOfRange(offset, minOf(offset + mss, bytes.size))
            val packet: ByteArray
            synchronized(flow.monitor) {
                while (!flow.closed.get() && !isIdle(flow) && outstandingBytes(flow) + chunk.size > flow.peerWindow) {
                    flow.monitor.wait(WINDOW_WAIT_MILLIS)
                }
                if (flow.closed.get() || isIdle(flow)) return
                val sequence = flow.nextServerSequence
                packet = buildPacket(
                    flow,
                    sequence,
                    flow.nextClientSequence,
                    TcpPacketCodec.FLAG_ACK or TcpPacketCodec.FLAG_PSH,
                    LOCAL_RECEIVE_WINDOW,
                    chunk
                ) ?: return
                val end = addSequence(sequence, chunk.size.toLong())
                flow.nextServerSequence = end
                flow.pending.addLast(PendingSegment(end, packet, System.nanoTime(), 1))
            }
            emitRaw(packet)
            offset += chunk.size
        }
    }

    private fun handleRemoteEof(flow: Flow) {
        if (flow.closed.get() || flow.remoteFin) return
        synchronized(flow.monitor) {
            val sequence = flow.nextServerSequence
            val packet = buildPacket(
                flow,
                sequence,
                flow.nextClientSequence,
                TcpPacketCodec.FLAG_FIN or TcpPacketCodec.FLAG_ACK,
                LOCAL_RECEIVE_WINDOW,
                ByteArray(0)
            ) ?: return
            flow.nextServerSequence = addSequence(sequence, 1)
            flow.pending.addLast(PendingSegment(flow.nextServerSequence, packet, System.nanoTime(), 1))
            flow.remoteFin = true
            flow.state = if (flow.appFin) State.CLOSING else State.REMOTE_FIN
            emitRaw(packet)
        }
    }

    private fun maintainAfterRemoteEof(flow: Flow) {
        while (!closed.get() && !flow.closed.get() && !isIdle(flow)) {
            retransmitIfDue(flow)
            synchronized(flow.monitor) {
                if (flow.appFin && flow.remoteFin && flow.pending.isEmpty()) return
                flow.monitor.wait(WINDOW_WAIT_MILLIS)
            }
        }
    }

    private fun acknowledgeRemoteBytes(flow: Flow, acknowledgement: Long, window: Int) {
        synchronized(flow.monitor) {
            val advance = sequenceDistance(flow.lastAcknowledgedServerSequence, acknowledgement)
            val inFlight = sequenceDistance(flow.lastAcknowledgedServerSequence, flow.nextServerSequence)
            if (advance <= inFlight) {
                flow.peerWindow = window
                if (advance > 0) {
                    flow.lastAcknowledgedServerSequence = acknowledgement
                    while (flow.pending.isNotEmpty()) {
                        val first = flow.pending.first()
                        val remaining = sequenceDistance(flow.lastAcknowledgedServerSequence, first.endSequence)
                        if (remaining in 1 until HALF_SEQUENCE_SPACE) break
                        flow.pending.removeFirst()
                    }
                    flow.duplicateAcks = 0
                } else if (flow.pending.isNotEmpty()) {
                    flow.duplicateAcks++
                    if (flow.duplicateAcks >= FAST_RETRANSMIT_DUP_ACKS) {
                        val first = flow.pending.first()
                        first.lastSentNanos = System.nanoTime()
                        first.attempts++
                        emitRaw(first.packet)
                        flow.duplicateAcks = 0
                    }
                }
            }
            flow.monitor.notifyAll()
        }
    }

    private fun retransmitIfDue(flow: Flow) {
        val now = System.nanoTime()
        var packetToSend: ByteArray? = null
        var mustClose = false
        synchronized(flow.monitor) {
            val first = flow.pending.firstOrNull() ?: return
            if (now - first.lastSentNanos < RETRANSMIT_TIMEOUT_NANOS) return
            if (first.attempts >= MAX_RETRANSMISSIONS) {
                mustClose = true
            } else {
                first.attempts++
                first.lastSentNanos = now
                packetToSend = first.packet
            }
        }
        packetToSend?.let(::emitRaw)
        if (mustClose) {
            sendReset(flow)
            removeFlow(flow)
        }
    }

    private fun outstandingBytes(flow: Flow): Long =
        sequenceDistance(flow.lastAcknowledgedServerSequence, flow.nextServerSequence)

    private fun maxPayload(flow: Flow): Int {
        val ipHeader = if (flow.template.ipVersion == 4) 20 else 40
        return minOf(DATA_MSS, mtu - ipHeader - 20).coerceAtLeast(1)
    }

    private fun emit(
        flow: Flow,
        sequence: Long,
        acknowledgement: Long,
        flags: Int,
        window: Int,
        payload: ByteArray = ByteArray(0),
        options: ByteArray = ByteArray(0)
    ) {
        val packet = buildPacket(flow, sequence, acknowledgement, flags, window, payload, options) ?: return
        emitRaw(packet)
    }

    private fun buildPacket(
        flow: Flow,
        sequence: Long,
        acknowledgement: Long,
        flags: Int,
        window: Int,
        payload: ByteArray = ByteArray(0),
        options: ByteArray = ByteArray(0)
    ): ByteArray? = TcpPacketCodec.build(
        ipVersion = flow.template.ipVersion,
        sourceAddress = flow.template.destinationAddress,
        destinationAddress = flow.template.sourceAddress,
        sourcePort = flow.template.destinationPort,
        destinationPort = flow.template.sourcePort,
        sequenceNumber = sequence,
        acknowledgementNumber = acknowledgement,
        flags = flags,
        windowSize = window,
        payload = payload,
        tcpOptions = options,
        mtu = mtu
    )

    private fun sendReset(flow: Flow) {
        emit(
            flow,
            sequence = flow.nextServerSequence,
            acknowledgement = flow.nextClientSequence,
            flags = TcpPacketCodec.FLAG_RST or TcpPacketCodec.FLAG_ACK,
            window = 0
        )
    }

    private fun sendReset(segment: TcpSegment, sequence: Long) {
        val packet = TcpPacketCodec.build(
            ipVersion = segment.ipVersion,
            sourceAddress = segment.destinationAddress,
            destinationAddress = segment.sourceAddress,
            sourcePort = segment.destinationPort,
            destinationPort = segment.sourcePort,
            sequenceNumber = sequence,
            acknowledgementNumber = addSequence(segment.sequenceNumber, 1),
            flags = TcpPacketCodec.FLAG_RST or TcpPacketCodec.FLAG_ACK,
            windowSize = 0,
            mtu = mtu
        ) ?: return
        emitRaw(packet)
    }

    private fun emitRaw(packet: ByteArray) {
        if (closed.get()) return
        try { packetWriter(packet) } catch (_: Exception) { }
    }

    private fun isIdle(flow: Flow): Boolean =
        System.nanoTime() - flow.lastActivityNanos.get() >= idleTimeoutMillis * NANOS_PER_MILLISECOND

    private fun pruneExpiredLocked() {
        val now = System.nanoTime()
        val expired = flows.values.filter {
            now - it.lastActivityNanos.get() >= idleTimeoutMillis * NANOS_PER_MILLISECOND
        }
        expired.forEach {
            flows.remove(it.key)
            closeFlowLocked(it)
        }
    }

    private fun removeFlow(flow: Flow) {
        synchronized(lock) {
            if (flows[flow.key] === flow) flows.remove(flow.key)
            closeFlowLocked(flow)
        }
    }

    private fun closeFlowLocked(flow: Flow) {
        if (flow.closed.compareAndSet(false, true)) {
            flow.state = State.CLOSED
            synchronized(flow.monitor) { flow.monitor.notifyAll() }
            try { flow.socket?.close() } catch (_: Exception) { }
            flow.clientStream.clear()
            flow.tlsHelloGate.clear()
        }
    }

    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        synchronized(lock) {
            flows.values.toList().forEach(::closeFlowLocked)
            flows.clear()
        }
    }

    private fun TcpSegment.toKey() = FlowKey(
        ipVersion = ipVersion,
        sourceAddress = sourceAddress.toHex(),
        destinationAddress = destinationAddress.toHex(),
        sourcePort = sourcePort,
        destinationPort = destinationPort
    )

    private fun TcpSegment.copyDeep() = copy(
        sourceAddress = sourceAddress.copyOf(),
        destinationAddress = destinationAddress.copyOf(),
        options = options.copyOf(),
        payload = payload.copyOf()
    )

    private fun ByteArray.toHex(): String = joinToString(separator = "") { "%02x".format(it.toInt() and 0xff) }

    companion object {
        const val DEFAULT_MAX_FLOWS = 32
        const val MAX_ALLOWED_FLOWS = 256
        const val DEFAULT_CONNECT_TIMEOUT_MILLIS = 5_000
        const val DEFAULT_IDLE_TIMEOUT_MILLIS = 120_000L
        const val MAX_IDLE_TIMEOUT_MILLIS = 600_000L
        const val DEFAULT_MTU = 1500
        const val DATA_MSS = 1200
        private const val LOCAL_RECEIVE_WINDOW = 32_768
        private const val READ_POLL_TIMEOUT_MILLIS = 250
        private const val HANDSHAKE_WAIT_MILLIS = 5_000L
        private const val HANDSHAKE_POLL_MILLIS = 100L
        private const val WINDOW_WAIT_MILLIS = 100L
        private const val FAST_RETRANSMIT_DUP_ACKS = 3
        private const val DEFAULT_TLS_SPLIT_DELAY_MILLIS = 35L
        private const val TLS_REMOTE_RESPONSE_TIMEOUT_NANOS = 8_000_000_000L
        private const val MAX_RETRANSMISSIONS = 5
        private const val RETRANSMIT_TIMEOUT_NANOS = 500_000_000L
        private const val NANOS_PER_MILLISECOND = 1_000_000L
        private const val SEQUENCE_MASK = 0xffff_ffffL
        private const val HALF_SEQUENCE_SPACE = 0x8000_0000L

        private fun addSequence(sequence: Long, amount: Long): Long = (sequence + amount) and SEQUENCE_MASK
        private fun sequenceDistance(from: Long, to: Long): Long = (to - from) and SEQUENCE_MASK
    }
}
