package com.exeteee.nexdpi

import android.os.Bundle
import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.exeteee.nexdpi.data.InstalledApp
import com.exeteee.nexdpi.data.InstalledAppCatalog
import com.exeteee.nexdpi.data.WhitelistRepository
import com.exeteee.nexdpi.proxy.ProxyParseResult
import com.exeteee.nexdpi.proxy.ProxyProfile
import com.exeteee.nexdpi.proxy.ProxyProfileStore
import com.exeteee.nexdpi.proxy.ProxySettings
import com.exeteee.nexdpi.proxy.ProxyType
import com.exeteee.nexdpi.proxy.TelegramProxyLinkParser
import com.exeteee.nexdpi.ui.NexDpiTheme
import com.exeteee.nexdpi.vpn.NexDpiVpnService
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val whitelistRepository = WhitelistRepository(applicationContext)
        val proxyStore = ProxyProfileStore(applicationContext)
        setContent {
            NexDpiTheme {
                NexDpiRoot(repository = whitelistRepository, proxyStore = proxyStore)
            }
        }
    }
}

private enum class Screen { HOME, WHITELIST, PROXIES }

@Composable
private fun NexDpiRoot(repository: WhitelistRepository, proxyStore: ProxyProfileStore) {
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    var whitelistCount by remember { mutableStateOf(repository.getPackages().size) }
    var proxySettings by remember { mutableStateOf(proxyStore.read()) }
    val context = LocalContext.current
    val applyProxyChanges = { updated: ProxySettings ->
        proxySettings = updated
        if (NexDpiVpnService.isRunning.value) {
            context.startService(
                Intent(context, NexDpiVpnService::class.java).setAction(NexDpiVpnService.ACTION_RESTART)
            )
        }
    }
    Surface(
        modifier = Modifier.fillMaxSize().safeDrawingPadding(),
        color = Color(0xFF080D12)
    ) {
        when (screen) {
            Screen.HOME -> HomeScreen(
                whitelistCount = whitelistCount,
                proxySettings = proxySettings,
                onOpenWhitelist = { screen = Screen.WHITELIST },
                onOpenProxies = { proxySettings = proxyStore.read(); screen = Screen.PROXIES }
            )
            Screen.PROXIES -> ProxyScreen(
                store = proxyStore,
                settings = proxySettings,
                onSettingsChanged = applyProxyChanges,
                onBack = { proxySettings = proxyStore.read(); screen = Screen.HOME }
            )
            Screen.WHITELIST -> WhitelistScreen(
                repository = repository,
                onBack = {
                    whitelistCount = repository.getPackages().size
                    screen = Screen.HOME
                }
            )
        }
    }
}

@Composable
private fun HomeScreen(
    whitelistCount: Int,
    proxySettings: ProxySettings,
    onOpenWhitelist: () -> Unit,
    onOpenProxies: () -> Unit
) {
    val context = LocalContext.current
    val vpnRunning by NexDpiVpnService.isRunning.collectAsState()
    val vpnError by NexDpiVpnService.lastError.collectAsState()
    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val serviceIntent = Intent(context, NexDpiVpnService::class.java)
                .setAction(NexDpiVpnService.ACTION_START)
            ContextCompat.startForegroundService(context, serviceIntent)
        } else {
            NexDpiVpnService.lastError.value = "Разрешение Android на VPN не предоставлено"
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF080D12))
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp, vertical = 26.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(11.dp)
                    .background(Color(0xFFC8FF4D), CircleShape)
            )
            Spacer(Modifier.width(10.dp))
            Text(
                text = "NEXDPI",
                color = Color(0xFFF0F4EA),
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 3.sp
            )
            Spacer(Modifier.weight(1f))
            Text(
                text = "INDEPENDENT / LOCAL",
                color = Color(0xFF81909B),
                fontSize = 9.sp,
                letterSpacing = 1.sp
            )
        }

        Spacer(Modifier.height(42.dp))
        Text(
            text = "Локальный движок.\nБез внешнего VPN.",
            color = Color(0xFFF0F4EA),
            fontSize = 36.sp,
            lineHeight = 39.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(12.dp))
        Text(
            text = "Системный DNS идёт через HTTPS. TCP и UDP обрабатываются локальным нативным DPI-движком; параметры подбираются автоматически. VPS не требуется.",
            color = Color(0xFF9AA8B3),
            fontSize = 14.sp,
            lineHeight = 21.sp
        )

        Spacer(Modifier.height(34.dp))
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Box(contentAlignment = Alignment.Center) {
                Canvas(modifier = Modifier.size(214.dp)) {
                    drawCircle(
                        color = Color(0xFF26333B),
                        style = Stroke(width = 2.dp.toPx())
                    )
                    drawArc(
                        color = if (vpnRunning) Color(0xFFC8FF4D) else Color(0xFF60717D),
                        startAngle = 218f,
                        sweepAngle = 255f,
                        useCenter = false,
                        style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                    )
                    drawCircle(
                        color = if (vpnRunning) Color(0xFFC8FF4D) else Color(0xFF60717D),
                        radius = 4.dp.toPx(),
                        center = Offset(size.width * 0.5f, size.height * 0.5f)
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (vpnRunning) "ACTIVE" else "STANDBY",
                        color = if (vpnRunning) Color(0xFFC8FF4D) else Color(0xFF81909B),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = if (vpnRunning) "NexDPI" else "Готов",
                        color = Color(0xFFF0F4EA),
                        fontSize = 22.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        Button(
            onClick = {
                if (vpnRunning) {
                    context.startService(
                        Intent(context, NexDpiVpnService::class.java)
                            .setAction(NexDpiVpnService.ACTION_STOP)
                    )
                } else {
                    val permissionIntent = VpnService.prepare(context)
                    if (permissionIntent == null) {
                        ContextCompat.startForegroundService(
                            context,
                            Intent(context, NexDpiVpnService::class.java)
                                .setAction(NexDpiVpnService.ACTION_START)
                        )
                    } else {
                        vpnPermissionLauncher.launch(permissionIntent)
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(58.dp),
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (vpnRunning) Color(0xFF26343E) else Color(0xFFC8FF4D),
                contentColor = if (vpnRunning) Color(0xFFF0F4EA) else Color(0xFF11170A)
            )
        ) {
            Text(
                text = if (vpnRunning) "ОТКЛЮЧИТЬ NEXDPI" else "ВКЛЮЧИТЬ NEXDPI",
                fontSize = 13.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            )
        }

        Spacer(Modifier.height(18.dp))
        StatusPanel(isRunning = vpnRunning, error = vpnError)

        Spacer(Modifier.height(14.dp))
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onOpenWhitelist),
            color = Color(0xFF111A23),
            shape = RoundedCornerShape(18.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF26343E))
        ) {
            Row(
                modifier = Modifier.padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Белый список",
                        color = Color(0xFFF0F4EA),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Приложения, работающие напрямую без NexDPI",
                        color = Color(0xFF8E9DA8),
                        fontSize = 12.sp
                    )
                }
                Text(
                    text = whitelistCount.toString(),
                    color = Color(0xFFC8FF4D),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        Surface(
            modifier = Modifier.fillMaxWidth().clickable(onClick = onOpenProxies),
            color = Color(0xFF111A23),
            shape = RoundedCornerShape(18.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF26343E))
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Прокси", color = Color(0xFFF0F4EA), fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        val selectedProxy = proxySettings.selected()
                        Text(
                            text = when {
                                selectedProxy == null -> "Не используется · добавить SOCKS5, HTTP CONNECT или MTProxy"
                                selectedProxy.type == ProxyType.SOCKS5 && proxySettings.enabled -> "SOCKS5 включён · ${selectedProxy.server}:${selectedProxy.port}"
                                selectedProxy.type == ProxyType.HTTP_CONNECT && proxySettings.enabled -> "HTTP CONNECT включён · ${selectedProxy.server}:${selectedProxy.port}"
                                selectedProxy.type == ProxyType.MTPROTO -> "MTProxy для Telegram · ${selectedProxy.server}:${selectedProxy.port}"
                                else -> "${selectedProxy.type.name} сохранён, но выключен · ${selectedProxy.server}:${selectedProxy.port}"
                            },
                            color = Color(0xFF8E9DA8), fontSize = 12.sp
                        )
                    }
                    Text("›", color = Color(0xFFC8FF4D), fontSize = 28.sp)
                }
            }
        }

        Spacer(Modifier.height(18.dp))
        Text(
            text = "ВАЖНОЕ ОГРАНИЧЕНИЕ",
            color = Color(0xFFC8FF4D),
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = "TCP и UDP без внешнего прокси идут через локальный нативный движок ByeDPI: TCP desync и UDP fake-пакеты с автоматическими резервными стратегиями. Системный DNS отправляется стороннему DoH-провайдеру. ICMP и другие IP-протоколы пока не поддерживаются. ECH и блокировки адресов/маршрутов могут оставаться недоступными; универсальный обход не гарантируется.",
            color = Color(0xFF7F8D98),
            fontSize = 12.sp,
            lineHeight = 18.sp
        )
    }
}

@Composable
private fun StatusPanel(isRunning: Boolean, error: String?) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color(0xFF111A23),
        shape = RoundedCornerShape(18.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF26343E))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text(
                text = "СОСТОЯНИЕ СЛУЖБЫ",
                color = Color(0xFF8E9DA8),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.4.sp
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = when {
                    isRunning -> "Локальный сетевой движок включён"
                    error != null -> "Не удалось включить NexDPI"
                    else -> "NexDPI выключен"
                },
                color = Color(0xFFF0F4EA),
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = error ?: if (isRunning) {
                    "Системный DNS идёт через HTTPS; TCP и UDP без внешнего прокси проходят через встроенное нативное ядро с автоматическими стратегиями. Эффективность зависит от типа фильтрации и сети."
                } else {
                    "Нажмите кнопку, чтобы запустить локальный сетевой движок."
                },
                color = Color(0xFF8E9DA8),
                fontSize = 12.sp,
                lineHeight = 18.sp
            )
            if (isRunning) {
                Spacer(Modifier.height(10.dp))
                Text(
                    text = "DOH: CLOUDFLARE · GOOGLE · QUAD9 (АВТОМАТИЧЕСКИЙ РЕЗЕРВ)",
                    color = Color(0xFFC8FF4D),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }
        }
    }
}

@Composable
private fun ProxyScreen(
    store: ProxyProfileStore,
    settings: ProxySettings,
    onSettingsChanged: (ProxySettings) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var link by rememberSaveable { mutableStateOf("") }
    var message by rememberSaveable { mutableStateOf<String?>(null) }
    BackHandler(onBack = onBack)

    fun refresh() = onSettingsChanged(store.read())

    Column(
        modifier = Modifier.fillMaxSize().background(Color(0xFF080D12))
            .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 24.dp)
    ) {
        Text(
            text = "‹  НАЗАД", color = Color(0xFFC8FF4D), fontSize = 12.sp,
            fontWeight = FontWeight.Bold, letterSpacing = 1.sp,
            modifier = Modifier.clickable(onClick = onBack)
        )
        Spacer(Modifier.height(28.dp))
        Text("Прокси", color = Color(0xFFF0F4EA), fontSize = 29.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Вставь ссылку из Telegram, SOCKS5 URI или HTTP proxy URI. SOCKS5 работает с TCP и UDP. HTTP CONNECT — только TCP и передаёт авторизацию без TLS до прокси; используй только доверенный сервер. MTProxy открывается в Telegram.",
            color = Color(0xFF9AA8B3), fontSize = 13.sp, lineHeight = 19.sp
        )
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            value = link,
            onValueChange = { link = it; message = null },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Ссылка на прокси") },
            placeholder = { Text("t.me/socks?... · t.me/proxy?... · socks5:// · http://") },
            minLines = 2,
            maxLines = 4,
            shape = RoundedCornerShape(14.dp)
        )
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = {
                when (val parsed = TelegramProxyLinkParser.parse(link)) {
                    is ProxyParseResult.Success -> {
                        store.upsert(parsed.profile, enable = parsed.profile.type != ProxyType.MTPROTO)
                        link = ""
                        message = when (parsed.profile.type) {
                            ProxyType.SOCKS5 -> "SOCKS5 добавлен и выбран для NexDPI."
                            ProxyType.HTTP_CONNECT -> "HTTP CONNECT добавлен и выбран. UDP будет блокироваться, а не отправляться напрямую."
                            ProxyType.MTPROTO -> "MTProxy добавлен. Нажми «Открыть в Telegram» для подключения."
                        }
                        refresh()
                    }
                    is ProxyParseResult.Error -> message = parsed.message
                }
            },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC8FF4D), contentColor = Color(0xFF11170A))
        ) { Text("ДОБАВИТЬ ПРОКСИ", fontWeight = FontWeight.Black, letterSpacing = 1.sp) }
        message?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = if (it.contains("добавлен")) Color(0xFFC8FF4D) else Color(0xFFFFB4A9), fontSize = 12.sp)
        }

        Spacer(Modifier.height(26.dp))
        Text("СОХРАНЁННЫЕ ПРОФИЛИ · ${settings.profiles.size}", color = Color(0xFFC8FF4D), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Spacer(Modifier.height(10.dp))
        if (settings.profiles.isEmpty()) {
            Text("Пока нет прокси. Можно добавить несколько профилей.", color = Color(0xFF8E9DA8), fontSize = 13.sp)
        } else {
            settings.profiles.forEach { profile ->
                val isSelected = settings.selectedId == profile.id
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 9.dp)
                        .clickable {
                            store.select(profile.id, profile.type != ProxyType.MTPROTO)
                            refresh()
                        },
                    color = if (isSelected) Color(0xFF17232B) else Color(0xFF111A23),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp, if (isSelected) Color(0xFFC8FF4D) else Color(0xFF26343E)
                    )
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    when (profile.type) {
                                        ProxyType.SOCKS5 -> "SOCKS5"
                                        ProxyType.HTTP_CONNECT -> "HTTP CONNECT"
                                        ProxyType.MTPROTO -> "MTProxy · Telegram"
                                    },
                                    color = Color(0xFFF0F4EA), fontSize = 14.sp, fontWeight = FontWeight.Bold
                                )
                                Spacer(Modifier.height(3.dp))
                                Text(
                                    "${profile.server}:${profile.port}", color = Color(0xFF8E9DA8), fontSize = 12.sp
                                )
                                if (profile.type == ProxyType.SOCKS5 && (!profile.username.isNullOrEmpty() || !profile.password.isNullOrEmpty())) {
                                    Text("Авторизация: логин и пароль сохранены", color = Color(0xFF81909B), fontSize = 10.sp)
                                }
                                if (profile.type == ProxyType.MTPROTO) {
                                    val mode = runCatching { com.exeteee.nexdpi.proxy.MtProtoSecret.parse(profile.secret.orEmpty()).mode }.getOrNull()
                                    Text("Secret: ${mode?.name ?: "неизвестный формат"}", color = Color(0xFF81909B), fontSize = 10.sp)
                                }
                            }
                            if (isSelected) Text("ВЫБРАН", color = Color(0xFFC8FF4D), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (profile.type != ProxyType.MTPROTO) {
                                Text(
                                    if (profile.type == ProxyType.SOCKS5) "Использовать в NexDPI · TCP + UDP" else "Использовать в NexDPI · только TCP",
                                    color = Color(0xFF9AA8B3), fontSize = 11.sp, modifier = Modifier.weight(1f)
                                )
                                Switch(
                                    checked = isSelected && settings.enabled,
                                    onCheckedChange = { enabled ->
                                        store.select(profile.id, enabled)
                                        refresh()
                                    }
                                )
                            } else {
                                Text("Только для Telegram", color = Color(0xFF9AA8B3), fontSize = 11.sp, modifier = Modifier.weight(1f))
                                Button(
                                    onClick = {
                                        val target = profile.telegramDeepLink()
                                        try {
                                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(target)))
                                        } catch (_: Exception) {
                                            val webLink = target.replaceFirst("tg://proxy", "https://t.me/proxy")
                                            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(webLink))) }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC8FF4D), contentColor = Color(0xFF11170A)),
                                    shape = RoundedCornerShape(10.dp)
                                ) { Text("ОТКРЫТЬ В TELEGRAM", fontSize = 9.sp, fontWeight = FontWeight.Black) }
                            }
                        }
                        Text(
                            "УДАЛИТЬ", color = Color(0xFFFFB4A9), fontSize = 10.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.End).clickable {
                                store.remove(profile.id)
                                refresh()
                            }.padding(top = 6.dp)
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Text(
            "SOCKS5 проксирует TCP и UDP, если сервер поддерживает UDP ASSOCIATE. HTTP CONNECT поддерживает TCP; UDP при его выборе блокируется. MTProxy — протокол Telegram, который открывается в нативном приложении Telegram и не является системным прокси. DNS-запросы NexDPI к DoH-провайдеру пока идут напрямую через сеть оператора.",
            color = Color(0xFF7F8D98), fontSize = 11.sp, lineHeight = 17.sp
        )
    }
}

@Composable
private fun WhitelistScreen(
    repository: WhitelistRepository,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var apps by remember { mutableStateOf<List<InstalledApp>>(emptyList()) }
    var selected by remember { mutableStateOf(repository.getPackages()) }
    var loading by remember { mutableStateOf(true) }
    val leaveWhitelist = {
        if (NexDpiVpnService.isRunning.value) {
            context.startService(
                Intent(context, NexDpiVpnService::class.java)
                    .setAction(NexDpiVpnService.ACTION_RESTART)
            )
        }
        onBack()
    }
    BackHandler(onBack = leaveWhitelist)

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) { InstalledAppCatalog.load(context) }
        loading = false
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF080D12))
            .padding(horizontal = 20.dp, vertical = 24.dp)
    ) {
        Text(
            text = "‹  НАЗАД",
            color = Color(0xFFC8FF4D),
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            modifier = Modifier.clickable { leaveWhitelist() }
        )
        Spacer(Modifier.height(28.dp))
        Text(
            text = "Белый список",
            color = Color(0xFFF0F4EA),
            fontSize = 29.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = "Выбранные приложения полностью обходят NexDPI и идут напрямую. Чтобы обход блокировки YouTube работал через движок, YouTube не должен быть выбран здесь. Изменения применяются после переподключения.",
            color = Color(0xFF9AA8B3),
            fontSize = 13.sp,
            lineHeight = 19.sp
        )
        Spacer(Modifier.height(18.dp))
        Text(
            text = "ВЫБРАНО: ${selected.size}",
            color = Color(0xFFC8FF4D),
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp
        )
        Spacer(Modifier.height(10.dp))

        when {
            loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Color(0xFFC8FF4D))
            }
            apps.isEmpty() -> Text(
                text = "Не удалось получить список приложений с ярлыками запуска.",
                color = Color(0xFF9AA8B3),
                fontSize = 13.sp
            )
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(apps, key = InstalledApp::packageName) { app ->
                    val checked = app.packageName in selected
                    Surface(
                        color = Color(0xFF111A23),
                        shape = RoundedCornerShape(15.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF26343E))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val newValue = !checked
                                    repository.setIncluded(app.packageName, newValue)
                                    selected = repository.getPackages()
                                }
                                .padding(horizontal = 14.dp, vertical = 11.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .background(Color(0xFF26343E), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = app.label.take(1).uppercase(),
                                    color = Color(0xFFC8FF4D),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = app.label,
                                    color = Color(0xFFF0F4EA),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = app.packageName,
                                    color = Color(0xFF81909B),
                                    fontSize = 10.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Switch(
                                checked = checked,
                                onCheckedChange = { newValue ->
                                    repository.setIncluded(app.packageName, newValue)
                                    selected = repository.getPackages()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
