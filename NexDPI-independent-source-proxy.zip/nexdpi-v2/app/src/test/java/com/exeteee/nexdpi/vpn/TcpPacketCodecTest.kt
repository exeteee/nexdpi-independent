package com.exeteee.nexdpi.vpn

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TcpPacketCodecTest {
    private val ipv4Source = byteArrayOf(192.toByte(), 0, 2, 10)
    private val ipv4Destination = byteArrayOf(203.toByte(), 0, 113, 20)
    private val ipv6Source = byteArrayOf(0x20, 0x01, 0x0d, 0xb8.toByte(), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1)
    private val ipv6Destination = byteArrayOf(0x20, 0x01, 0x0d, 0xb8.toByte(), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2)

    @Test
    fun buildsAndParsesIpv4SynAckWithValidChecksums() {
        val packet = TcpPacketCodec.build(
            ipVersion = 4,
            sourceAddress = ipv4Destination,
            destinationAddress = ipv4Source,
            sourcePort = 443,
            destinationPort = 50_000,
            sequenceNumber = 0xffff_fffeL,
            acknowledgementNumber = 0x1020_3040L,
            flags = TcpPacketCodec.FLAG_SYN or TcpPacketCodec.FLAG_ACK,
            windowSize = 32_768
        )
        assertNotNull(packet)
        packet!!
        val parsed = TcpPacketCodec.parse(packet)
        assertNotNull(parsed)
        parsed!!
        assertEquals(4, parsed.ipVersion)
        assertEquals(443, parsed.sourcePort)
        assertEquals(50_000, parsed.destinationPort)
        assertEquals(0xffff_fffeL, parsed.sequenceNumber)
        assertEquals(0x1020_3040L, parsed.acknowledgementNumber)
        assertTrue(parsed.isSyn && parsed.isAck)
        assertEquals(32_768, parsed.windowSize)
        assertTrue(TcpPacketCodec.isValidTcpChecksum(parsed, packet))
        assertEquals(0, ipv4HeaderChecksum(packet))
    }

    @Test
    fun buildsIpv6AckWithOddLengthPayloadAndValidPseudoHeaderChecksum() {
        val payload = "hello!".toByteArray()
        val packet = TcpPacketCodec.build(
            ipVersion = 6,
            sourceAddress = ipv6Destination,
            destinationAddress = ipv6Source,
            sourcePort = 443,
            destinationPort = 51_000,
            sequenceNumber = 100,
            acknowledgementNumber = 200,
            flags = TcpPacketCodec.FLAG_ACK or TcpPacketCodec.FLAG_PSH,
            windowSize = 65_535,
            payload = payload
        )
        assertNotNull(packet)
        packet!!
        val parsed = TcpPacketCodec.parse(packet)
        assertNotNull(parsed)
        parsed!!
        assertEquals(6, parsed.ipVersion)
        assertArrayEquals(payload, parsed.payload)
        assertTrue(parsed.isAck && parsed.isPsh)
        assertTrue(TcpPacketCodec.isValidTcpChecksum(parsed, packet))
    }

    @Test
    fun parsesIpv4HeaderOptionsBeforeTcpHeader() {
        val base = ipv4PacketWithPayload()
        val packet = ByteArray(base.size + 4)
        base.copyOfRange(0, 20).copyInto(packet, 0)
        byteArrayOf(1, 1, 1, 1).copyInto(packet, 20)
        base.copyOfRange(20, base.size).copyInto(packet, 24)
        packet[0] = 0x46
        put16(packet, 2, packet.size)
        put16(packet, 10, 0)
        put16(packet, 10, checksum(packet, 0, 24))

        val parsed = TcpPacketCodec.parse(packet)
        assertNotNull(parsed)
        parsed!!
        assertEquals(50_001, parsed.sourcePort)
        assertArrayEquals("data".toByteArray(), parsed.payload)
    }

    @Test
    fun parsesTcpAfterIpv6HopByHopExtension() {
        val base = ipv6PacketWithPayload()
        val packet = ByteArray(base.size + 8)
        base.copyOfRange(0, 40).copyInto(packet, 0)
        packet[6] = 0 // Hop-by-Hop options
        put16(packet, 4, u16(base, 4) + 8)
        packet[40] = 6 // TCP follows the extension
        packet[41] = 0 // Eight-byte extension header
        base.copyOfRange(40, base.size).copyInto(packet, 48)

        val parsed = TcpPacketCodec.parse(packet)
        assertNotNull(parsed)
        assertArrayEquals("v6-data".toByteArray(), parsed!!.payload)
    }

    @Test
    fun rejectsFragmentedIpv4AndNonAtomicIpv6Packets() {
        val ipv4 = ipv4PacketWithPayload().apply { put16(this, 6, 0x2000) }
        assertNull(TcpPacketCodec.parse(ipv4))

        val ipv6Base = ipv6PacketWithPayload()
        val ipv6Fragment = ByteArray(ipv6Base.size + 8)
        ipv6Base.copyOfRange(0, 40).copyInto(ipv6Fragment, 0)
        ipv6Fragment[6] = 44
        put16(ipv6Fragment, 4, u16(ipv6Base, 4) + 8)
        ipv6Fragment[40] = 6
        put16(ipv6Fragment, 42, 8) // Non-zero fragment offset.
        put32(ipv6Fragment, 44, 1)
        ipv6Base.copyOfRange(40, ipv6Base.size).copyInto(ipv6Fragment, 48)
        assertNull(TcpPacketCodec.parse(ipv6Fragment))
    }

    @Test
    fun rejectsMalformedTcpDataOffsetAndTruncatedPacket() {
        val packet = ipv4PacketWithPayload()
        packet[32] = 0x40 // TCP data offset = 4 (invalid, below 5)
        assertNull(TcpPacketCodec.parse(packet))
        assertNull(TcpPacketCodec.parse(packet.copyOf(24)))
    }

    @Test
    fun rejectsInvalidBuildParametersAndOverMtuSegments() {
        assertNull(TcpPacketCodec.build(
            4, ipv4Source, ipv4Destination, 1, 2, -1, 0,
            TcpPacketCodec.FLAG_SYN, 1024
        ))
        assertNull(TcpPacketCodec.build(
            4, ipv4Source, ipv4Destination, 1, 2, 0, 0,
            TcpPacketCodec.FLAG_SYN, 1024, ByteArray(1500)
        ))
        assertNull(TcpPacketCodec.build(
            5, ipv4Source, ipv4Destination, 1, 2, 0, 0,
            TcpPacketCodec.FLAG_SYN, 1024
        ))
    }


    @Test
    fun buildsTcpOptionsAndPreservesPayload() {
        val options = byteArrayOf(2, 4, 4, 176.toByte()) // MSS 1200
        val payload = "with-options".toByteArray()
        val packet = TcpPacketCodec.build(
            ipVersion = 4,
            sourceAddress = ipv4Source,
            destinationAddress = ipv4Destination,
            sourcePort = 12345,
            destinationPort = 443,
            sequenceNumber = 100,
            acknowledgementNumber = 200,
            flags = TcpPacketCodec.FLAG_SYN or TcpPacketCodec.FLAG_ACK,
            windowSize = 32_768,
            payload = payload,
            tcpOptions = options
        )
        assertNotNull(packet)
        packet!!
        val parsed = TcpPacketCodec.parse(packet)
        assertNotNull(parsed)
        parsed!!
        assertArrayEquals(options, parsed.options)
        assertArrayEquals(payload, parsed.payload)
        assertEquals(6, (packet[32].toInt() ushr 4) and 0x0f)
        assertTrue(TcpPacketCodec.isValidTcpChecksum(parsed, packet))
    }

    @Test
    fun rejectsInvalidIpv4HeaderChecksum() {
        val packet = ipv4PacketWithPayload().apply { this[8] = 63 }
        assertNull(TcpPacketCodec.parse(packet))
    }

    @Test
    fun checksumValidationRejectsAddressTampering() {
        val packet = ipv4PacketWithPayload()
        val segment = TcpPacketCodec.parse(packet)!!
        assertTrue(TcpPacketCodec.isValidTcpChecksum(segment, packet))
        val wrongAddress = segment.copy(sourceAddress = byteArrayOf(10, 0, 0, 1))
        assertFalse(TcpPacketCodec.isValidTcpChecksum(wrongAddress, packet))
    }

    private fun ipv4PacketWithPayload(): ByteArray = TcpPacketCodec.build(
        ipVersion = 4,
        sourceAddress = ipv4Source,
        destinationAddress = ipv4Destination,
        sourcePort = 50_001,
        destinationPort = 443,
        sequenceNumber = 1234,
        acknowledgementNumber = 5678,
        flags = TcpPacketCodec.FLAG_ACK or TcpPacketCodec.FLAG_PSH,
        windowSize = 4096,
        payload = "data".toByteArray()
    )!!

    private fun ipv6PacketWithPayload(): ByteArray = TcpPacketCodec.build(
        ipVersion = 6,
        sourceAddress = ipv6Source,
        destinationAddress = ipv6Destination,
        sourcePort = 52_000,
        destinationPort = 443,
        sequenceNumber = 123,
        acknowledgementNumber = 456,
        flags = TcpPacketCodec.FLAG_ACK,
        windowSize = 8192,
        payload = "v6-data".toByteArray()
    )!!

    private fun u16(bytes: ByteArray, offset: Int): Int =
        ((bytes[offset].toInt() and 0xff) shl 8) or (bytes[offset + 1].toInt() and 0xff)

    private fun put16(bytes: ByteArray, offset: Int, value: Int) {
        bytes[offset] = (value ushr 8).toByte()
        bytes[offset + 1] = value.toByte()
    }

    private fun put32(bytes: ByteArray, offset: Int, value: Long) {
        bytes[offset] = (value ushr 24).toByte()
        bytes[offset + 1] = (value ushr 16).toByte()
        bytes[offset + 2] = (value ushr 8).toByte()
        bytes[offset + 3] = value.toByte()
    }

    private fun checksum(bytes: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var index = offset
        val end = offset + length
        while (index + 1 < end) {
            sum += (((bytes[index].toInt() and 0xff) shl 8) or
                (bytes[index + 1].toInt() and 0xff)).toLong()
            index += 2
        }
        if (index < end) sum += ((bytes[index].toInt() and 0xff) shl 8).toLong()
        while ((sum ushr 16) != 0L) sum = (sum and 0xffff) + (sum ushr 16)
        return sum.inv().toInt() and 0xffff
    }

    private fun ipv4HeaderChecksum(packet: ByteArray): Int = checksum(packet, 0, (packet[0].toInt() and 0x0f) * 4)
}
