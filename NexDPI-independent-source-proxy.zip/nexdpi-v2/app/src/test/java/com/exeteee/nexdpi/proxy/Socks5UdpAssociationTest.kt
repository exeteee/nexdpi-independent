package com.exeteee.nexdpi.proxy

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

class Socks5UdpAssociationTest {
    @Test
    fun establishesUdpAssociationAndEncapsulatesRequestAndReply() {
        DatagramSocket(InetSocketAddress("127.0.0.1", 0)).use { relay ->
            relay.soTimeout = 2_000
            ServerSocket(0).use { controlServer ->
                var serverFailure: Throwable? = null
                val worker = thread(isDaemon = true) {
                    try {
                        controlServer.accept().use { control ->
                            assertArrayEquals(byteArrayOf(5, 1, 0), readFully(control, 3))
                            control.getOutputStream().write(byteArrayOf(5, 0))
                            assertArrayEquals(
                                byteArrayOf(5, 3, 0, 1, 0, 0, 0, 0, 0, 0),
                                readFully(control, 10)
                            )
                            val port = relay.localPort
                            control.getOutputStream().write(
                                byteArrayOf(5, 0, 0, 1, 127, 0, 0, 1, (port ushr 8).toByte(), port.toByte())
                            )
                            Thread.sleep(1_000)
                        }
                    } catch (error: Throwable) {
                        serverFailure = error
                    }
                }
                val profile = ProxyProfile(type = ProxyType.SOCKS5, server = "127.0.0.1", port = controlServer.localPort)
                Socks5UdpAssociation(
                    profile, byteArrayOf(1, 2, 3, 4), 53, { true }, { true }, timeoutMillis = 2_000
                ).use { association ->
                    association.send("dns".toByteArray())
                    val inbound = DatagramPacket(ByteArray(512), 512)
                    relay.receive(inbound)
                    assertArrayEquals(
                        byteArrayOf(0, 0, 0, 1, 1, 2, 3, 4, 0, 53),
                        inbound.data.copyOfRange(0, 10)
                    )
                    val response = byteArrayOf(0, 0, 0, 1, 1, 2, 3, 4, 0, 53) + "reply".toByteArray()
                    relay.send(DatagramPacket(response, response.size, inbound.socketAddress))
                    assertEquals("reply", association.receive().toString(Charsets.UTF_8))
                }
                worker.join(2_000)
                serverFailure?.let { throw AssertionError("SOCKS5 UDP test server failed", it) }
            }
        }
    }

    private fun readFully(socket: Socket, size: Int): ByteArray {
        val bytes = ByteArray(size)
        var offset = 0
        while (offset < size) {
            val count = socket.getInputStream().read(bytes, offset, size - offset)
            check(count > 0) { "Unexpected end of SOCKS5 control stream" }
            offset += count
        }
        return bytes
    }
}
