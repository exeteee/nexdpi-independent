package com.exeteee.nexdpi.vpn

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TlsClientHelloGateTest {
    @Test
    fun buffersIncompleteClientHelloAndReleasesItForSplittingWhenComplete() {
        val hello = clientHello("example.com")
        val gate = TlsClientHelloGate()
        assertTrue(gate.append(hello.copyOfRange(0, 12)) is TlsGateDecision.Hold)
        val result = gate.append(hello.copyOfRange(12, hello.size))
        assertTrue(result is TlsGateDecision.SplitClientHello)
        result as TlsGateDecision.SplitClientHello
        assertEquals("example.com", result.hello.serverName)
        assertEquals(hello.toList(), result.bytes.toList())
    }

    @Test
    fun forwardsNonTlsBytesImmediatelyAndPreservesFollowingBytes() {
        val gate = TlsClientHelloGate()
        val first = "GET / HTTP/1.1\\r\\n".toByteArray()
        val second = "Host: example.com\\r\\n".toByteArray()
        val firstResult = gate.append(first)
        assertTrue(firstResult is TlsGateDecision.ForwardRaw)
        assertEquals(first.toList(), (firstResult as TlsGateDecision.ForwardRaw).bytes.toList())
        val secondResult = gate.append(second) as TlsGateDecision.ForwardRaw
        assertEquals(second.toList(), secondResult.bytes.toList())
    }

    @Test
    fun forwardsEncryptedClientHelloUnchangedEvenWhenPublicNameIsVisible() {
        val hello = clientHello("public.example", includeEch = true)
        val gate = TlsClientHelloGate()
        val result = gate.append(hello)
        assertTrue(result is TlsGateDecision.ForwardRaw)
        assertEquals(hello.toList(), (result as TlsGateDecision.ForwardRaw).bytes.toList())
    }

    @Test
    fun forwardsClientHelloWithoutSniUnchanged() {
        val hello = clientHello(null)
        val gate = TlsClientHelloGate()
        val result = gate.append(hello)
        assertTrue(result is TlsGateDecision.ForwardRaw)
        assertEquals(hello.toList(), (result as TlsGateDecision.ForwardRaw).bytes.toList())
    }

    @Test
    fun incompleteHelloIsReleasedAfterBoundedTimeout() {
        var now = 1_000_000_000L
        val gate = TlsClientHelloGate(timeoutMillis = 350) { now }
        val hello = clientHello("example.org")
        val partial = hello.copyOfRange(0, 8)
        assertTrue(gate.append(partial) is TlsGateDecision.Hold)
        assertTrue(gate.flushIfExpired(now + 349_000_000L) == null)
        val expired = gate.flushIfExpired(now + 351_000_000L)
        assertEquals(partial.toList(), expired!!.toList())
        val remaining = hello.copyOfRange(partial.size, hello.size)
        val later = gate.append(remaining) as TlsGateDecision.ForwardRaw
        assertEquals(remaining.toList(), later.bytes.toList())
    }

    @Test
    fun strategySelectorExploresCandidatesThenPrefersTheBestObservedHostStrategy() {
        val selector = TlsSplitStrategySelector()
        val host = "example.com"
        val before = selector.next(host)
        val middle = selector.next(host)
        val after = selector.next(host)
        assertEquals(TlsSplitPoint.BEFORE_SNI, before)
        assertEquals(TlsSplitPoint.MIDDLE_OF_SNI, middle)
        assertEquals(TlsSplitPoint.AFTER_SNI, after)

        selector.recordOutcome(host, before, remoteResponded = false)
        selector.recordOutcome(host, middle, remoteResponded = false)
        selector.recordOutcome(host, after, remoteResponded = true)
        assertEquals(after, selector.next(host))
    }

    @Test
    fun strategySelectorKeepsHostHistoriesIndependentAndBounded() {
        val selector = TlsSplitStrategySelector(maxTrackedHosts = 2)
        assertEquals(TlsSplitPoint.BEFORE_SNI, selector.next("one.example"))
        assertEquals(TlsSplitPoint.BEFORE_SNI, selector.next("two.example"))
        assertEquals(TlsSplitPoint.BEFORE_SNI, selector.next("three.example"))
        assertEquals(2, selector.trackedHostCount())
        assertEquals(TlsSplitPoint.BEFORE_SNI, selector.next("one.example"))
    }

    private fun clientHello(serverName: String?, includeEch: Boolean = false): ByteArray {
        val body = ArrayList<Byte>()
        fun add(value: Int) { body.add(value.toByte()) }
        fun addU16(value: Int) { add(value ushr 8); add(value) }
        fun addBytes(bytes: ByteArray) { bytes.forEach { add(it.toInt() and 0xff) } }
        addU16(0x0303)
        repeat(32) { add(0) }
        add(0)
        addU16(2)
        addU16(0x1301)
        add(1)
        add(0)
        if (serverName == null) {
            addU16(0)
        } else {
            val hostname = serverName.toByteArray(Charsets.US_ASCII)
            val sniList = byteArrayOf(
                ((hostname.size + 3) ushr 8).toByte(),
                (hostname.size + 3).toByte(), 0,
                (hostname.size ushr 8).toByte(), hostname.size.toByte()
            ) + hostname
            val sniExtension = byteArrayOf(
                0, 0, (sniList.size ushr 8).toByte(), sniList.size.toByte()
            ) + sniList
            val trailingExtension = byteArrayOf(0, 23, 0, 0)
            val echExtension = if (includeEch) byteArrayOf(0xfe.toByte(), 0x0d, 0, 0) else ByteArray(0)
            val extensions = sniExtension + trailingExtension + echExtension
            addU16(extensions.size)
            addBytes(extensions)
        }
        val handshakeBody = body.toByteArray()
        val handshake = byteArrayOf(
            1, (handshakeBody.size ushr 16).toByte(),
            (handshakeBody.size ushr 8).toByte(), handshakeBody.size.toByte()
        ) + handshakeBody
        return byteArrayOf(
            22, 3, 1, (handshake.size ushr 8).toByte(), handshake.size.toByte()
        ) + handshake
    }
}
