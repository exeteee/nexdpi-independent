package com.exeteee.nexdpi.vpn

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TcpStreamReassemblerTest {
    private fun assertStreamEquals(expected: ByteArray, actual: ByteArray?) {
        assertTrue("Expected a non-null reassembled byte stream", actual != null)
        assertArrayEquals(expected, actual!!)
    }

    @Test
    fun reordersSegmentsAndEmitsOnlyWhenGapIsFilled() {
        val base = 1_000L
        val assembler = TcpStreamReassembler(base)
        assertStreamEquals(ByteArray(0), assembler.accept(base + 5, "world".toByteArray()))
        assertStreamEquals("helloworld".toByteArray(), assembler.accept(base, "hello".toByteArray()))
        assertEquals(10, assembler.bufferedContiguousBytes())
    }

    @Test
    fun acceptsIdenticalRetransmissionsWithoutDuplicatingBytes() {
        val base = 10L
        val assembler = TcpStreamReassembler(base)
        assertStreamEquals("hello".toByteArray(), assembler.accept(base, "hello".toByteArray()))
        assertStreamEquals(ByteArray(0), assembler.accept(base, "hello".toByteArray()))
        assertEquals(5, assembler.bufferedContiguousBytes())
    }

    @Test
    fun acceptsConsistentPartialOverlap() {
        val base = 100L
        val assembler = TcpStreamReassembler(base)
        assertStreamEquals(ByteArray(0), assembler.accept(base + 4, "efgh".toByteArray()))
        assertStreamEquals("abcdefgh".toByteArray(), assembler.accept(base, "abcdef".toByteArray()))
        assertStreamEquals(ByteArray(0), assembler.accept(base + 6, "gh".toByteArray()))
    }

    @Test
    fun rejectsConflictingOverlapAndLocksTheAssembler() {
        val base = 500L
        val assembler = TcpStreamReassembler(base)
        assertStreamEquals(ByteArray(0), assembler.accept(base + 3, "def".toByteArray()))
        assertNull(assembler.accept(base, "abcXYZ".toByteArray()))
        assertTrue(assembler.isFailed())
        assertNull(assembler.accept(base, "abcdef".toByteArray()))
    }

    @Test
    fun handlesUnsignedSequenceNumberWraparound() {
        val base = 0xffff_fffCL
        val assembler = TcpStreamReassembler(base)
        assertStreamEquals(ByteArray(0), assembler.accept(0L, "efgh".toByteArray()))
        assertStreamEquals("abcdefgh".toByteArray(), assembler.accept(base, "abcd".toByteArray()))
    }

    @Test
    fun ignoresPayloadThatEntirelyPredatesTheTrackedStream() {
        val assembler = TcpStreamReassembler(100L)
        assertStreamEquals(ByteArray(0), assembler.accept(90L, "old".toByteArray()))
        assertStreamEquals("new".toByteArray(), assembler.accept(100L, "new".toByteArray()))
    }

    @Test
    fun rejectsSegmentsOutsideTheConfiguredWindow() {
        val assembler = TcpStreamReassembler(1L, capacity = 16)
        assertNull(assembler.accept(1L + 16L, byteArrayOf(1)))
        assertTrue(assembler.isFailed())
    }

    @Test
    fun clearResetsDataAndFailureState() {
        val assembler = TcpStreamReassembler(20L, capacity = 8)
        assertNull(assembler.accept(28L, byteArrayOf(1)))
        assertTrue(assembler.isFailed())
        assembler.clear()
        assertTrue(!assembler.isFailed())
        assertStreamEquals(byteArrayOf(1, 2, 3), assembler.accept(20L, byteArrayOf(1, 2, 3)))
    }
}
