package com.exeteee.nexdpi.proxy

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ProxyProfileTest {
    @Test
    fun parsesTelegramSocksLinkAndDecodesCredentials() {
        val result = TelegramProxyLinkParser.parse(
            "https://t.me/socks?server=proxy.example&port=1080&user=alice&pass=p%40ss"
        ) as ProxyParseResult.Success
        assertEquals(ProxyType.SOCKS5, result.profile.type)
        assertEquals("proxy.example", result.profile.server)
        assertEquals(1080, result.profile.port)
        assertEquals("alice", result.profile.username)
        assertEquals("p@ss", result.profile.password)
    }

    @Test
    fun parsesTelegramMtProtoSecretVariants() {
        val basic = MtProtoSecret.parse("ab".repeat(16))
        val randomPadding = MtProtoSecret.parse("dd" + "ab".repeat(16))
        val fakeTlsHex = "ee" + "ab".repeat(16) + "example.com".toByteArray().joinToString("") { "%02x".format(it) }
        val fakeTls = MtProtoSecret.parse(fakeTlsHex)
        assertEquals(MtProtoSecret.Mode.BASIC, basic.mode)
        assertEquals(MtProtoSecret.Mode.RANDOM_PADDING, randomPadding.mode)
        assertEquals(MtProtoSecret.Mode.FAKE_TLS, fakeTls.mode)
        assertEquals("example.com", fakeTls.domain)
    }

    @Test
    fun parsesTelegramMtProtoLinkAndBuildsNativeTelegramDeepLink() {
        val result = TelegramProxyLinkParser.parse(
            "tg://proxy?server=mt.example&port=443&secret=${"cd".repeat(16)}"
        ) as ProxyParseResult.Success
        assertEquals(ProxyType.MTPROTO, result.profile.type)
        assertTrue(result.profile.telegramDeepLink().startsWith("tg://proxy?"))
    }

    @Test
    fun parsesSocksAndHttpConnectUris() {
        val socks = TelegramProxyLinkParser.parse("socks5h://user:pass@127.0.0.1:1080") as ProxyParseResult.Success
        val http = TelegramProxyLinkParser.parse("http://user:pass@127.0.0.1:8080") as ProxyParseResult.Success
        assertEquals(ProxyType.SOCKS5, socks.profile.type)
        assertEquals(ProxyType.HTTP_CONNECT, http.profile.type)
        assertEquals("pass", socks.profile.password)
        assertEquals(8080, http.profile.port)
    }

    @Test
    fun rejectsInvalidSecretAndMalformedEndpoint() {
        assertTrue(TelegramProxyLinkParser.parse("t.me/proxy?server=x&port=443&secret=nothex") is ProxyParseResult.Error)
        assertTrue(TelegramProxyLinkParser.parse("socks5://proxy.example:99999") is ProxyParseResult.Error)
        assertFalse(TelegramProxyLinkParser.parse("t.me/socks?server=127.0.0.1&port=1080") is ProxyParseResult.Error)
    }
}
