package com.exeteee.nexdpi.vpn

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class UdpFlowRelayTest {
    @Test
    fun relaysDatagramsOverOneProtectedSocketAndRestoresOriginalTuple() {
        DatagramSocket(0, InetAddress.getByName("127.0.0.1")).use { echo ->
            echo.soTimeout = 2_000
            val serverThread = Thread {
                repeat(2) {
                    val received = DatagramPacket(ByteArray(128), 128)
                    try {
                        echo.receive(received)
                        val reply = "reply-${String(received.data, received.offset, received.length)}".toByteArray()
                        echo.send(DatagramPacket(reply, reply.size, received.address, received.port))
                    } catch (_: SocketTimeoutException) { }
                }
            }.apply { isDaemon = true; start() }

            val responses = ArrayBlockingQueue<UdpDatagram>(4)
            val protectedCalls = java.util.concurrent.atomic.AtomicInteger()
            val relay = UdpFlowRelay(
                protectSocket = { protectedCalls.incrementAndGet(); true },
                packetWriter = { packet -> UdpPacketCodec.parse(packet)?.let(responses::offer) },
                idleTimeoutMillis = 5_000
            )
            try {
                relay.send(request(echo.localPort, sourcePort = 53_001, payload = "one"))
                relay.send(request(echo.localPort, sourcePort = 53_001, payload = "two"))
                val first = responses.poll(3, TimeUnit.SECONDS)
                val second = responses.poll(3, TimeUnit.SECONDS)
                assertNotNull(first)
                assertNotNull(second)
                val payloads = listOf(first!!.payload.toString(Charsets.UTF_8), second!!.payload.toString(Charsets.UTF_8)).sorted()
                assertEquals(listOf("reply-one", "reply-two"), payloads)
                assertEquals(1, protectedCalls.get())
                assertEquals(1, relay.activeFlowCount())
                assertTrue(first.sourceAddress.contentEquals(byteArrayOf(127, 0, 0, 1)))
                assertTrue(first.destinationAddress.contentEquals(byteArrayOf(10, 77, 0, 2)))
                assertEquals(echo.localPort, first.sourcePort)
                assertEquals(53_001, first.destinationPort)
            } finally {
                relay.close()
                serverThread.join(2_000)
            }
        }
    }

    @Test
    fun enforcesMaximumFlowCount() {
        DatagramSocket(0, InetAddress.getByName("127.0.0.1")).use { echo ->
            echo.soTimeout = 2_000
            val serverThread = Thread {
                repeat(2) {
                    val request = DatagramPacket(ByteArray(64), 64)
                    try { echo.receive(request) } catch (_: Exception) { }
                }
            }.apply { isDaemon = true; start() }
            val relay = UdpFlowRelay(
                protectSocket = { true },
                packetWriter = {},
                maxFlows = 1,
                idleTimeoutMillis = 5_000
            )
            try {
                relay.send(request(echo.localPort, sourcePort = 53_010, payload = "a"))
                var limited = false
                try {
                    relay.send(request(echo.localPort, sourcePort = 53_011, payload = "b"))
                } catch (_: java.io.IOException) {
                    limited = true
                }
                assertTrue(limited)
                assertEquals(1, relay.activeFlowCount())
            } finally {
                relay.close()
                serverThread.join(2_000)
            }
        }
    }

    @Test
    fun rejectsUnprotectedSocketAndClosesAllFlows() {
        DatagramSocket(0, InetAddress.getByName("127.0.0.1")).use { echo ->
            val rejectingRelay = UdpFlowRelay(
                protectSocket = { false },
                packetWriter = {}
            )
            var rejected = false
            try {
                rejectingRelay.send(request(echo.localPort, 53_020, "x"))
            } catch (_: java.io.IOException) {
                rejected = true
            } finally {
                rejectingRelay.close()
            }
            assertTrue(rejected)
            assertEquals(0, rejectingRelay.activeFlowCount())

            val closingRelay = UdpFlowRelay(protectSocket = { true }, packetWriter = {})
            closingRelay.send(request(echo.localPort, 53_021, "y"))
            assertEquals(1, closingRelay.activeFlowCount())
            closingRelay.close()
            assertEquals(0, closingRelay.activeFlowCount())
            var closed = false
            try { closingRelay.send(request(echo.localPort, 53_021, "z")) }
            catch (_: IllegalStateException) { closed = true }
            assertTrue(closed)
        }
    }

    private fun request(port: Int, sourcePort: Int, payload: String) = UdpDatagram(
        ipVersion = 4,
        sourceAddress = byteArrayOf(10, 77, 0, 2),
        destinationAddress = byteArrayOf(127, 0, 0, 1),
        sourcePort = sourcePort,
        destinationPort = port,
        payload = payload.toByteArray()
    )
    @Test
    fun doesNotLeakUdpDirectlyWhenSelectedProxyCannotCarryUdp() {
        val relay = UdpFlowRelay(
            protectSocket = { error("No direct socket should be created") },
            packetWriter = {},
            allowDirectFlows = false
        )
        try {
            var blocked = false
            try {
                relay.send(
                    UdpDatagram(
                        ipVersion = 4,
                        sourceAddress = byteArrayOf(10, 77, 0, 2),
                        destinationAddress = byteArrayOf(1, 1, 1, 1),
                        sourcePort = 53_100,
                        destinationPort = 443,
                        payload = byteArrayOf(1, 2, 3)
                    )
                )
            } catch (error: java.io.IOException) {
                blocked = error.message?.contains("не отправлен напрямую") == true
            }
            assertTrue(blocked)
            assertEquals(0, relay.activeFlowCount())
        } finally {
            relay.close()
        }
    }

}
