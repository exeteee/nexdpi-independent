package com.exeteee.nexdpi.proxy

import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

class Socks5ClientTest {
    @Test
    fun negotiatesUsernamePasswordAndConnectsToIpv4Target() {
        ServerSocket(0).use { server ->
            var serverFailure: Throwable? = null
            val worker = thread(isDaemon = true) {
                try {
                    server.accept().use { peer ->
                        assertArrayEquals(byteArrayOf(5, 2, 0, 2), readFully(peer, 4))
                        peer.getOutputStream().write(byteArrayOf(5, 2))
                        assertArrayEquals(byteArrayOf(1, 1), readFully(peer, 2))
                        assertEquals("u", readFully(peer, 1).toString(Charsets.UTF_8))
                        assertArrayEquals(byteArrayOf(1), readFully(peer, 1))
                        assertEquals("p", readFully(peer, 1).toString(Charsets.UTF_8))
                        peer.getOutputStream().write(byteArrayOf(1, 0))
                        val connect = readFully(peer, 10)
                        assertEquals(5, connect[0].toInt())
                        assertEquals(1, connect[1].toInt())
                        assertArrayEquals(byteArrayOf(1, 2, 3, 4), connect.copyOfRange(4, 8))
                        assertArrayEquals(byteArrayOf(1, 0xbb.toByte()), connect.copyOfRange(8, 10))
                        peer.getOutputStream().write(byteArrayOf(5, 0, 0, 1, 127, 0, 0, 1, 0x12, 0x34))
                    }
                } catch (error: Throwable) {
                    serverFailure = error
                }
            }
            val profile = ProxyProfile(
                type = ProxyType.SOCKS5, server = "127.0.0.1", port = server.localPort,
                username = "u", password = "p"
            )
            Socket().use { socket ->
                Socks5Client.connect(socket, profile, byteArrayOf(1, 2, 3, 4), 443, 2_000)
            }
            worker.join(2_000)
            serverFailure?.let { throw AssertionError("SOCKS5 test server failed", it) }
        }
    }

    private fun readFully(socket: Socket, size: Int): ByteArray {
        val bytes = ByteArray(size)
        var offset = 0
        while (offset < size) {
            val count = socket.getInputStream().read(bytes, offset, size - offset)
            check(count > 0) { "Unexpected end of SOCKS5 stream" }
            offset += count
        }
        return bytes
    }
}
