package com.exeteee.nexdpi.vpn

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.net.ServerSocket
import java.net.Socket
import java.io.ByteArrayOutputStream

class TlsClientHelloParserTest {
    @Test
    fun extractsSniAndExactByteRange() {
        val packet = clientHello("example.com")
        val parsed = TlsClientHelloParser.parse(packet)
        assertNotNull(parsed)
        parsed!!
        assertEquals("example.com", parsed.serverName)
        assertEquals("example.com".length, parsed.serverNameLength)
        assertEquals("example.com", packet.copyOfRange(
            parsed.serverNameOffset!!,
            parsed.serverNameOffset + parsed.serverNameLength!!
        ).toString(Charsets.US_ASCII))
        assertEquals(packet.size, parsed.recordEndOffset)
    }

    @Test
    fun computesAllThreeSniSplitCandidates() {
        val parsed = TlsClientHelloParser.parse(clientHello("example.com"))!!
        val before = TlsSplitPlanner.splitOffset(parsed, TlsSplitPoint.BEFORE_SNI)!!
        val middle = TlsSplitPlanner.splitOffset(parsed, TlsSplitPoint.MIDDLE_OF_SNI)!!
        val after = TlsSplitPlanner.splitOffset(parsed, TlsSplitPoint.AFTER_SNI)!!
        assertTrue(before < middle)
        assertTrue(middle < after)
        assertEquals(parsed.serverNameOffset!! + parsed.serverNameLength!!, after)
    }

    @Test
    fun splitWritesPreserveTheOriginalTlsByteStream() {
        val packet = clientHello("example.com")
        val parsed = TlsClientHelloParser.parse(packet)!!
        val chunks = TlsSplitPlanner.splitWrites(packet, parsed, TlsSplitPoint.MIDDLE_OF_SNI)
        assertNotNull(chunks)
        chunks!!
        assertEquals(2, chunks.size)
        assertEquals(packet.toList(), (chunks[0] + chunks[1]).toList())
        assertTrue(chunks.all { it.isNotEmpty() })
    }

    @Test
    fun splitWriterPreservesBytesOverALocalTcpSocket() {
        val packet = clientHello("example.com")
        val parsed = TlsClientHelloParser.parse(packet)!!
        val server = ServerSocket(0)
        val received = ByteArrayOutputStream()
        val serverThread = Thread {
            server.accept().use { accepted ->
                val buffer = ByteArray(512)
                while (true) {
                    val count = accepted.getInputStream().read(buffer)
                    if (count < 0) break
                    received.write(buffer, 0, count)
                }
            }
        }
        serverThread.start()
        Socket("127.0.0.1", server.localPort).use { client ->
            TlsSplitWriter.write(client, packet, parsed, TlsSplitPoint.MIDDLE_OF_SNI, 1)
            client.shutdownOutput()
        }
        serverThread.join(2_000)
        server.close()
        assertTrue(!serverThread.isAlive)
        assertEquals(packet.toList(), received.toByteArray().toList())
    }

    @Test
    fun parsesCaseInsensitiveSniAsLowercase() {
        val parsed = TlsClientHelloParser.parse(clientHello("ExAmPlE.CoM"))
        assertEquals("example.com", parsed?.serverName)
    }

    @Test
    fun detectsEncryptedClientHelloExtension() {
        val parsed = TlsClientHelloParser.parse(clientHello("public.example", includeEch = true))
        assertNotNull(parsed)
        assertTrue(parsed!!.encryptedClientHello)
        assertEquals("public.example", parsed.serverName)
    }

    @Test
    fun acceptsClientHelloWithoutSniButProvidesNoSplitOffset() {
        val parsed = TlsClientHelloParser.parse(clientHello(serverName = null))
        assertNotNull(parsed)
        parsed!!
        assertNull(parsed.serverName)
        assertNull(TlsSplitPlanner.splitOffset(parsed, TlsSplitPoint.BEFORE_SNI))
    }

    @Test
    fun rejectsNonHandshakeRecords() {
        val packet = clientHello("example.com")
        packet[0] = 23
        assertNull(TlsClientHelloParser.parse(packet))
    }

    @Test
    fun rejectsTruncatedRecordsAndHandshakeBodies() {
        val packet = clientHello("example.com")
        assertNull(TlsClientHelloParser.parse(packet.copyOf(packet.size - 1)))
        val badHandshakeLength = packet.copyOf().apply { this[6] = 0x7f }
        assertNull(TlsClientHelloParser.parse(badHandshakeLength))
    }

    @Test
    fun rejectsMalformedExtensionLengths() {
        val packet = clientHello("example.com")
        // Corrupt the SNI extension length so it exceeds the extension block.
        val parsed = TlsClientHelloParser.parse(packet)!!
        val extStart = parsed.serverNameOffset!! - 9
        val malformed = packet.copyOf().apply {
            this[extStart + 2] = 0x7f
            this[extStart + 3] = 0x7f
        }
        assertNull(TlsClientHelloParser.parse(malformed))
    }

    @Test
    fun rejectsInvalidHostLabels() {
        assertNull(TlsClientHelloParser.parse(clientHello("-bad.example")))
        assertNull(TlsClientHelloParser.parse(clientHello("bad..example")))
    }

    private fun clientHello(serverName: String?, includeEch: Boolean = false): ByteArray {
        val body = ArrayList<Byte>()
        fun add(value: Int) { body.add(value.toByte()) }
        fun addU16(value: Int) { add(value ushr 8); add(value) }
        fun addBytes(bytes: ByteArray) { bytes.forEach { add(it.toInt() and 0xff) } }

        addU16(0x0303) // legacy_version
        repeat(32) { add(0) } // random
        add(0) // session id length
        addU16(2) // cipher suites length
        addU16(0x1301) // TLS_AES_128_GCM_SHA256
        add(1) // compression methods length
        add(0) // null compression

        if (serverName == null) {
            addU16(0) // zero-length extension block
        } else {
            val hostname = serverName.toByteArray(Charsets.US_ASCII)
            val serverNameList = byteArrayOf(
                ((hostname.size + 3) ushr 8).toByte(),
                (hostname.size + 3).toByte(),
                0,
                (hostname.size ushr 8).toByte(),
                hostname.size.toByte()
            ) + hostname
            val extensionData = serverNameList
            val serverNameExtension = byteArrayOf(
                0, 0,
                (extensionData.size ushr 8).toByte(), extensionData.size.toByte()
            ) + extensionData
            // A trailing unknown extension keeps AFTER_SNI inside the handshake body.
            val trailingExtension = byteArrayOf(0, 23, 0, 0)
            val echExtension = if (includeEch) byteArrayOf(0xfe.toByte(), 0x0d, 0, 0) else ByteArray(0)
            val extensions = serverNameExtension + trailingExtension + echExtension
            addU16(extensions.size)
            addBytes(extensions)
        }

        val handshakeBody = body.toByteArray()
        val handshake = byteArrayOf(
            1,
            (handshakeBody.size ushr 16).toByte(),
            (handshakeBody.size ushr 8).toByte(),
            handshakeBody.size.toByte()
        ) + handshakeBody
        return byteArrayOf(
            22, 3, 1,
            (handshake.size ushr 8).toByte(), handshake.size.toByte()
        ) + handshake
    }
}
