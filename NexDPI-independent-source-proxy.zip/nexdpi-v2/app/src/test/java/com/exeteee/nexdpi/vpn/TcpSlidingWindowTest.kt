package com.exeteee.nexdpi.vpn

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TcpSlidingWindowTest {
    @Test
    fun streamsMoreThanOneWindowWithoutGrowingTheBuffer() {
        val window = TcpSlidingWindow(initialSequenceNumber = 100, capacity = 8)
        val combined = ArrayList<Byte>()
        repeat(20) { block ->
            val bytes = ByteArray(8) { (block * 8 + it).toByte() }
            val output = window.accept(100L + block * 8L, bytes)!!
            assertArrayEquals(bytes, output)
            combined.addAll(output!!.toList())
            assertEquals(0, window.bufferedBytes())
        }
        assertEquals(260L, window.nextSequence())
        assertEquals(160, combined.size)
    }

    @Test
    fun buffersOutOfOrderSegmentsAndEmitsOnceTheGapArrives() {
        val window = TcpSlidingWindow(1_000, 32)
        assertArrayEquals(ByteArray(0), window.accept(1_004, "ef".toByteArray())!!)
        assertEquals(2, window.bufferedBytes())
        assertArrayEquals("abcd ef".replace(" ", "").toByteArray(), window.accept(1_000, "abcd".toByteArray())!!)
        assertEquals(1_006L, window.nextSequence())
        assertEquals(0, window.bufferedBytes())
    }

    @Test
    fun handlesUnsignedSequenceWraparound() {
        val window = TcpSlidingWindow(0xffff_fffcL, 16)
        assertArrayEquals("abcd".toByteArray(), window.accept(0xffff_fffcL, "abcd".toByteArray())!!)
        assertEquals(0L, window.nextSequence())
        assertArrayEquals("ef".toByteArray(), window.accept(0L, "ef".toByteArray())!!)
        assertEquals(2L, window.nextSequence())
    }

    @Test
    fun acceptsIdenticalBufferedRetransmissionsAndIgnoresOldBytes() {
        val window = TcpSlidingWindow(50, 16)
        assertArrayEquals(ByteArray(0), window.accept(54, "ef".toByteArray())!!)
        assertArrayEquals(ByteArray(0), window.accept(54, "ef".toByteArray())!!)
        assertArrayEquals("abcdef".toByteArray(), window.accept(50, "abcd".toByteArray())!!)
        assertArrayEquals(ByteArray(0), window.accept(50, "abc".toByteArray())!!)
        assertEquals(0, window.bufferedBytes())
    }

    @Test
    fun rejectsConflictingOverlapAndClearsTheWindow() {
        val window = TcpSlidingWindow(100, 16)
        assertArrayEquals(ByteArray(0), window.accept(104, "ef".toByteArray())!!)
        assertNull(window.accept(104, "Ex".toByteArray()))
        assertTrue(window.isFailed())
        window.clear()
        assertTrue(!window.isFailed())
        assertEquals(0, window.bufferedBytes())
    }

    @Test
    fun rejectsSegmentsOutsideConfiguredWindow() {
        val window = TcpSlidingWindow(0, 8)
        assertNull(window.accept(8, byteArrayOf(1)))
        assertTrue(window.isFailed())
    }
}
