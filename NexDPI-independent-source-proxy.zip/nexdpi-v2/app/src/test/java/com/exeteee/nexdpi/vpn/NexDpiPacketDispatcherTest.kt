package com.exeteee.nexdpi.vpn

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NexDpiPacketDispatcherTest {
    @Test
    fun dispatchesValidDnsQueriesToEncryptedDnsHandler() {
        val dnsMessage = dnsQuery()
        val packet = udpRequestPacket(
            sourceAddress = byteArrayOf(10, 77, 0, 2),
            destinationAddress = byteArrayOf(10, 77, 0, 1),
            sourcePort = 53_211,
            destinationPort = 53,
            payload = dnsMessage
        )
        var received: DnsUdpQuery? = null
        val dispatcher = NexDpiPacketDispatcher(
            onDns = { received = it },
            onUdp = { throw AssertionError("DNS query was sent to generic UDP relay") },
            onTcp = { throw AssertionError("DNS query was sent to TCP relay") },
            onTcpDns = { throw AssertionError("UDP DNS query was sent to TCP DNS blocker") }
        )
        assertEquals(PacketDispatchResult.DNS, dispatcher.dispatch(packet))
        assertTrue(received?.dnsMessage?.contentEquals(dnsMessage) == true)
        assertEquals(53_211, received?.sourcePort)
    }

    @Test
    fun dispatchesOtherUdpTrafficWithoutChangingItsPayload() {
        val payload = byteArrayOf(1, 3, 5, 7, 9)
        val packet = udpRequestPacket(
            sourceAddress = byteArrayOf(10, 77, 0, 2),
            destinationAddress = byteArrayOf(1, 1, 1, 1),
            sourcePort = 50_000,
            destinationPort = 443,
            payload = payload
        )
        var received: UdpDatagram? = null
        val dispatcher = NexDpiPacketDispatcher(
            onDns = { throw AssertionError("non-DNS UDP reached DNS handler") },
            onUdp = { received = it },
            onTcp = { throw AssertionError("UDP packet reached TCP handler") },
            onTcpDns = { throw AssertionError("UDP packet reached TCP DNS blocker") }
        )
        assertEquals(PacketDispatchResult.UDP, dispatcher.dispatch(packet))
        assertTrue(received?.payload?.contentEquals(payload) == true)
        assertEquals(443, received?.destinationPort)
    }

    @Test
    fun dispatchesValidTcpOnlyAfterChecksumValidation() {
        val packet = tcpRequestPacket()
        var delivered = 0
        val dispatcher = NexDpiPacketDispatcher(
            onDns = { throw AssertionError("TCP reached DNS handler") },
            onUdp = { throw AssertionError("TCP reached UDP handler") },
            onTcp = { delivered++ },
            onTcpDns = { throw AssertionError("ordinary TCP reached TCP DNS blocker") }
        )
        assertEquals(PacketDispatchResult.TCP, dispatcher.dispatch(packet))
        assertEquals(1, delivered)
        val corrupt = packet.copyOf().apply { this[lastIndex] = (last().toInt() xor 1).toByte() }
        assertEquals(PacketDispatchResult.DROPPED, dispatcher.dispatch(corrupt))
        assertEquals(1, delivered)
    }

    @Test
    fun dropsUnsupportedAndMalformedIpPacketsWithoutLeakingThem() {
        val dispatcher = NexDpiPacketDispatcher(
            onDns = { throw AssertionError("unexpected DNS") },
            onUdp = { throw AssertionError("unexpected UDP") },
            onTcp = { throw AssertionError("unexpected TCP") },
            onTcpDns = { throw AssertionError("unexpected TCP DNS") }
        )
        assertEquals(PacketDispatchResult.DROPPED, dispatcher.dispatch(byteArrayOf(0x45, 0, 0, 20)))
        val icmp = ByteArray(20).apply {
            this[0] = 0x45
            this[2] = 0
            this[3] = 20
            this[9] = 1
        }
        assertEquals(PacketDispatchResult.DROPPED, dispatcher.dispatch(icmp))
    }

    @Test
    fun preventsMalformedUdpDnsAndTcpDnsFromLeakingToUnderlyingNetwork() {
        val malformedDns = udpRequestPacket(
            sourceAddress = byteArrayOf(10, 77, 0, 2),
            destinationAddress = byteArrayOf(10, 77, 0, 1),
            sourcePort = 53_222,
            destinationPort = 53,
            payload = ByteArray(12)
        )
        val tcpDns = TcpPacketCodec.build(
            ipVersion = 4,
            sourceAddress = byteArrayOf(10, 77, 0, 2),
            destinationAddress = byteArrayOf(8, 8, 8, 8),
            sourcePort = 53_333,
            destinationPort = 53,
            sequenceNumber = 900,
            acknowledgementNumber = 1_200,
            flags = TcpPacketCodec.FLAG_ACK,
            windowSize = 32_768
        )!!
        var tcpReset: ByteArray? = null
        var udpCalls = 0
        val dispatcher = NexDpiPacketDispatcher(
            onDns = { throw AssertionError("malformed DNS must not reach DoH") },
            onUdp = { udpCalls++ },
            onTcp = { throw AssertionError("TCP DNS must not be proxied in plaintext") },
            onTcpDns = { tcpReset = it }
        )
        assertEquals(PacketDispatchResult.DROPPED, dispatcher.dispatch(malformedDns))
        assertEquals(PacketDispatchResult.TCP_DNS_REJECTED, dispatcher.dispatch(tcpDns))
        assertEquals(0, udpCalls)
        val reset = TcpPacketCodec.parse(tcpReset!!)!!
        assertTrue(reset.isRst)
        assertEquals(1_200L, reset.sequenceNumber)
        assertEquals(0L, reset.acknowledgementNumber)
        assertEquals(0, udpCalls)
    }

    private fun udpRequestPacket(
        sourceAddress: ByteArray,
        destinationAddress: ByteArray,
        sourcePort: Int,
        destinationPort: Int,
        payload: ByteArray
    ): ByteArray {
        // The response codec reverses the supplied tuple, so invert it to construct an app packet.
        val reverse = UdpDatagram(
            ipVersion = 4,
            sourceAddress = destinationAddress,
            destinationAddress = sourceAddress,
            sourcePort = destinationPort,
            destinationPort = sourcePort,
            payload = byteArrayOf()
        )
        return UdpPacketCodec.buildResponsePackets(reverse, payload)!!.single()
    }

    private fun tcpRequestPacket(): ByteArray = TcpPacketCodec.build(
        ipVersion = 4,
        sourceAddress = byteArrayOf(10, 77, 0, 2),
        destinationAddress = byteArrayOf(1, 1, 1, 1),
        sourcePort = 52_000,
        destinationPort = 443,
        sequenceNumber = 100,
        acknowledgementNumber = 0,
        flags = TcpPacketCodec.FLAG_SYN,
        windowSize = 32_768
    )!!

    private fun dnsQuery(): ByteArray {
        val name = byteArrayOf(
            7, 'e'.code.toByte(), 'x'.code.toByte(), 'a'.code.toByte(), 'm'.code.toByte(),
            'p'.code.toByte(), 'l'.code.toByte(), 'e'.code.toByte(),
            3, 'c'.code.toByte(), 'o'.code.toByte(), 'm'.code.toByte(), 0
        )
        return ByteArray(12).apply {
            this[0] = 0x12
            this[1] = 0x34
            this[2] = 1
            this[5] = 1
        } + name + byteArrayOf(0, 1, 0, 1)
    }
}
