package com.exeteee.nexdpi.vpn

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DnsPacketCodecTest {
    @Test
    fun parsesIpv4DnsAndBuildsReverseResponse() {
        val query = ipv4DnsQuery()
        val parsed = DnsPacketCodec.parseQuery(query)
        assertNotNull(parsed)
        parsed!!
        assertEquals(4, parsed.ipVersion)
        assertEquals(50_000, parsed.sourcePort)
        assertEquals(0x1234, ((parsed.dnsMessage[0].toInt() and 0xff) shl 8) or
            (parsed.dnsMessage[1].toInt() and 0xff))

        val responseDns = parsed.dnsMessage.copyOf().apply {
            this[2] = 0x81.toByte()
            this[3] = 0x80.toByte()
            this[7] = 1
        }
        val response = DnsPacketCodec.buildResponse(parsed, responseDns)
        assertNotNull(response)
        response!!
        assertEquals(4, response[0].toInt() ushr 4)
        assertArrayEquals(byteArrayOf(10, 77, 0, 1), response.copyOfRange(12, 16))
        assertArrayEquals(byteArrayOf(192.toByte(), 0, 2, 10), response.copyOfRange(16, 20))
        assertEquals(53, u16(response, 20))
        assertEquals(50_000, u16(response, 22))
        assertEquals(0, checksum(response, 0, 20))
        assertEquals(0, udpChecksumV4(response))
    }

    @Test
    fun parsesIpv6DnsAndBuildsResponseWithMandatoryUdpChecksum() {
        val query = ipv6DnsQuery()
        val parsed = DnsPacketCodec.parseQuery(query)
        assertNotNull(parsed)
        parsed!!
        assertEquals(6, parsed.ipVersion)
        assertEquals(53_101, parsed.sourcePort)

        val response = DnsPacketCodec.buildResponse(parsed, parsed.dnsMessage)
        assertNotNull(response)
        response!!
        assertEquals(6, response[0].toInt() ushr 4)
        assertArrayEquals(parsed.destinationAddress, response.copyOfRange(8, 24))
        assertArrayEquals(parsed.sourceAddress, response.copyOfRange(24, 40))
        assertTrue(u16(response, 46) != 0)
        assertEquals(0, udpChecksumV6(response))
    }

    @Test
    fun ignoresTcpAndNonDnsUdpPackets() {
        val packet = ipv4DnsQuery()
        packet[9] = 6
        assertNull(DnsPacketCodec.parseQuery(packet))

        val udp = ipv4DnsQuery()
        udp[23] = 54
        assertNull(DnsPacketCodec.parseQuery(udp))
    }

    @Test
    fun fragmentsLargeIpv4DnsResponsesAndPreservesUdpChecksum() {
        val parsed = DnsPacketCodec.parseQuery(ipv4DnsQuery())!!
        val dns = largeDnsResponse()
        val fragments = DnsPacketCodec.buildResponsePackets(parsed, dns)
        assertNotNull(fragments)
        fragments!!
        assertTrue(fragments.size > 1)
        assertTrue(fragments.all { it.size <= 1500 })

        val udpSegment = reassembleIpv4(fragments)
        assertEquals(53, u16(udpSegment, 0))
        assertEquals(parsed.sourcePort, u16(udpSegment, 2))
        assertArrayEquals(dns, udpSegment.copyOfRange(8, udpSegment.size))

        val fullPacket = ByteArray(20 + udpSegment.size)
        fragments.first().copyOfRange(0, 20).copyInto(fullPacket, 0)
        put16(fullPacket, 2, fullPacket.size)
        put16(fullPacket, 6, 0)
        udpSegment.copyInto(fullPacket, 20)
        assertEquals(0, udpChecksumV4(fullPacket))
        put16(fullPacket, 10, 0)
        put16(fullPacket, 10, checksum(fullPacket, 0, 20))
        assertEquals(0, checksum(fullPacket, 0, 20))
    }

    @Test
    fun fragmentsLargeIpv6DnsResponsesAndPreservesUdpChecksum() {
        val parsed = DnsPacketCodec.parseQuery(ipv6DnsQuery())!!
        val dns = largeDnsResponse()
        val fragments = DnsPacketCodec.buildResponsePackets(parsed, dns)
        assertNotNull(fragments)
        fragments!!
        assertTrue(fragments.size > 1)
        assertTrue(fragments.all { it.size <= 1500 && (it[6].toInt() and 0xff) == 44 })

        val udpSegment = reassembleIpv6(fragments)
        assertEquals(53, u16(udpSegment, 0))
        assertEquals(parsed.sourcePort, u16(udpSegment, 2))
        assertArrayEquals(dns, udpSegment.copyOfRange(8, udpSegment.size))

        val fullPacket = ByteArray(40 + udpSegment.size)
        fragments.first().copyOfRange(0, 40).copyInto(fullPacket, 0)
        fullPacket[6] = 17
        put16(fullPacket, 4, udpSegment.size)
        udpSegment.copyInto(fullPacket, 40)
        assertEquals(0, udpChecksumV6(fullPacket))
    }

    @Test
    fun validatesUpstreamDnsResponseAndRejectsTruncatedOrMismatchedResponse() {
        val query = dnsQuestion()
        val response = query.copyOf().apply {
            this[2] = 0x81.toByte()
            this[3] = 0x80.toByte()
        }
        assertTrue(DnsPacketCodec.isValidDnsResponse(query, response))

        val truncated = response.copyOf().apply { this[2] = 0x83.toByte() }
        assertTrue(!DnsPacketCodec.isValidDnsResponse(query, truncated))

        val wrongId = response.copyOf().apply { this[0] = 0x55 }
        assertTrue(!DnsPacketCodec.isValidDnsResponse(query, wrongId))

        val wrongOpcode = response.copyOf().apply { this[2] = 0x89.toByte() }
        assertTrue(!DnsPacketCodec.isValidDnsResponse(query, wrongOpcode))

        val wrongQuestionCount = response.copyOf().apply { this[5] = 0x02 }
        assertTrue(!DnsPacketCodec.isValidDnsResponse(query, wrongQuestionCount))
    }

    @Test
    fun validatesQuestionNameTypeAndClassNotOnlyTransactionId() {
        val query = dnsQuestion()
        val valid = query.copyOf().apply {
            this[2] = 0x81.toByte()
            this[3] = 0x80.toByte()
        }
        assertTrue(DnsPacketCodec.isValidDnsResponse(query, valid))

        val wrongName = valid.copyOf().apply { this[13] = 'z'.code.toByte() }
        assertTrue(!DnsPacketCodec.isValidDnsResponse(query, wrongName))

        val wrongType = valid.copyOf().apply { this[26] = 28 }
        assertTrue(!DnsPacketCodec.isValidDnsResponse(query, wrongType))

        val wrongClass = valid.copyOf().apply { this[28] = 3 }
        assertTrue(!DnsPacketCodec.isValidDnsResponse(query, wrongClass))

        val differentCase = valid.copyOf().apply { this[13] = 'E'.code.toByte() }
        assertTrue(DnsPacketCodec.isValidDnsResponse(query, differentCase))
    }

    @Test
    fun rejectsMalformedOrLoopingQuestionCompressionPointers() {
        val query = dnsQuestion()
        val malformed = query.copyOf().apply {
            this[2] = 0x81.toByte()
            this[3] = 0x80.toByte()
            this[12] = 0xc0.toByte()
            this[13] = 0x0c
        }
        assertTrue(!DnsPacketCodec.isValidDnsResponse(query, malformed))

        val outOfBounds = query.copyOf().apply {
            this[2] = 0x81.toByte()
            this[3] = 0x80.toByte()
            this[12] = 0xff.toByte()
            this[13] = 0xff.toByte()
        }
        assertTrue(!DnsPacketCodec.isValidDnsResponse(query, outOfBounds))
    }

    @Test
    fun assignsDifferentFragmentIdsToConcurrentResponses() {
        val ipv4 = DnsPacketCodec.parseQuery(ipv4DnsQuery())!!
        val firstV4 = DnsPacketCodec.buildResponsePackets(ipv4, largeDnsResponse())!!.first()
        val secondV4 = DnsPacketCodec.buildResponsePackets(ipv4, largeDnsResponse())!!.first()
        assertTrue(u16(firstV4, 4) != u16(secondV4, 4))

        val ipv6 = DnsPacketCodec.parseQuery(ipv6DnsQuery())!!
        val firstV6 = DnsPacketCodec.buildResponsePackets(ipv6, largeDnsResponse())!!.first()
        val secondV6 = DnsPacketCodec.buildResponsePackets(ipv6, largeDnsResponse())!!.first()
        val firstId = ((firstV6[44].toInt() and 0xff) shl 24) or
            ((firstV6[45].toInt() and 0xff) shl 16) or
            ((firstV6[46].toInt() and 0xff) shl 8) or (firstV6[47].toInt() and 0xff)
        val secondId = ((secondV6[44].toInt() and 0xff) shl 24) or
            ((secondV6[45].toInt() and 0xff) shl 16) or
            ((secondV6[46].toInt() and 0xff) shl 8) or (secondV6[47].toInt() and 0xff)
        assertTrue(firstId != secondId)
    }

    @Test
    fun rejectsIpv4FragmentInputInsteadOfParsingPartialDns() {
        val packet = ipv4DnsQuery()
        put16(packet, 6, 0x2000)
        assertNull(DnsPacketCodec.parseQuery(packet))
    }

    @Test
    fun createsServfailAndPreservesTransactionAndQuestion() {
        val query = dnsQuestion()
        val response = DnsPacketCodec.servfail(query)
        assertNotNull(response)
        response!!
        assertEquals(query[0], response[0])
        assertEquals(query[1], response[1])
        assertTrue((response[2].toInt() and 0x80) != 0)
        assertEquals(2, response[3].toInt() and 0x0f)
        assertArrayEquals(query.copyOfRange(12, query.size), response.copyOfRange(12, response.size))
    }

    private fun ipv4DnsQuery(): ByteArray {
        val dns = dnsQuestion()
        val packet = ByteArray(20 + 8 + dns.size)
        packet[0] = 0x45
        put16(packet, 2, packet.size)
        packet[8] = 64
        packet[9] = 17
        byteArrayOf(192.toByte(), 0, 2, 10).copyInto(packet, 12)
        byteArrayOf(10, 77, 0, 1).copyInto(packet, 16)
        put16(packet, 20, 50_000)
        put16(packet, 22, 53)
        put16(packet, 24, 8 + dns.size)
        dns.copyInto(packet, 28)
        return packet
    }

    private fun ipv6DnsQuery(): ByteArray {
        val dns = dnsQuestion()
        val packet = ByteArray(40 + 8 + dns.size)
        packet[0] = 0x60
        put16(packet, 4, 8 + dns.size)
        packet[6] = 17
        packet[7] = 64
        val source = ByteArray(16).apply { this[0] = 0x20; this[1] = 1; this[15] = 10 }
        val destination = ByteArray(16).apply { this[0] = 0xfd.toByte(); this[1] = 0x77; this[2] = 0; this[3] = 0x77; this[15] = 1 }
        source.copyInto(packet, 8)
        destination.copyInto(packet, 24)
        put16(packet, 40, 53_101)
        put16(packet, 42, 53)
        put16(packet, 44, 8 + dns.size)
        dns.copyInto(packet, 48)
        return packet
    }

    private fun largeDnsResponse(): ByteArray = ByteArray(3_000).apply {
        dnsQuestion().copyInto(this)
        this[2] = 0x81.toByte()
        this[3] = 0x80.toByte()
    }

    private fun reassembleIpv4(fragments: List<ByteArray>): ByteArray {
        val totalSize = fragments.maxOf { fragment ->
            ((u16(fragment, 6) and 0x1fff) * 8) + fragment.size - 20
        }
        val result = ByteArray(totalSize)
        fragments.forEach { fragment ->
            val offset = (u16(fragment, 6) and 0x1fff) * 8
            fragment.copyOfRange(20, fragment.size).copyInto(result, offset)
        }
        return result
    }

    private fun reassembleIpv6(fragments: List<ByteArray>): ByteArray {
        val totalSize = fragments.maxOf { fragment ->
            ((u16(fragment, 42) ushr 3) * 8) + fragment.size - 48
        }
        val result = ByteArray(totalSize)
        fragments.forEach { fragment ->
            val offset = (u16(fragment, 42) ushr 3) * 8
            fragment.copyOfRange(48, fragment.size).copyInto(result, offset)
        }
        return result
    }

    private fun dnsQuestion(): ByteArray = byteArrayOf(
        0x12, 0x34, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x07, 0x65, 0x78, 0x61,
        0x6d, 0x70, 0x6c, 0x65, 0x03, 0x63, 0x6f, 0x6d,
        0x00, 0x00, 0x01, 0x00, 0x01
    )

    private fun u16(bytes: ByteArray, offset: Int): Int =
        ((bytes[offset].toInt() and 0xff) shl 8) or (bytes[offset + 1].toInt() and 0xff)

    private fun put16(bytes: ByteArray, offset: Int, value: Int) {
        bytes[offset] = (value ushr 8).toByte()
        bytes[offset + 1] = value.toByte()
    }

    private fun checksum(bytes: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var index = offset
        while (index + 1 < offset + length) {
            sum += (((bytes[index].toInt() and 0xff) shl 8) or
                (bytes[index + 1].toInt() and 0xff)).toLong()
            index += 2
        }
        while ((sum ushr 16) != 0L) sum = (sum and 0xffff) + (sum ushr 16)
        return sum.inv().toInt() and 0xffff
    }

    private fun udpChecksumV4(packet: ByteArray): Int {
        val length = u16(packet, 24)
        var sum = 0L
        for (offset in listOf(12, 14, 16, 18)) sum += u16(packet, offset).toLong()
        sum += 17 + length
        var index = 20
        while (index + 1 < 20 + length) {
            sum += u16(packet, index).toLong()
            index += 2
        }
        if (index < 20 + length) sum += ((packet[index].toInt() and 0xff) shl 8).toLong()
        while ((sum ushr 16) != 0L) sum = (sum and 0xffff) + (sum ushr 16)
        return sum.inv().toInt() and 0xffff
    }

    private fun udpChecksumV6(packet: ByteArray): Int {
        val length = u16(packet, 44)
        var sum = 0L
        var offset = 8
        while (offset < 40) {
            sum += u16(packet, offset).toLong()
            offset += 2
        }
        sum += length + 17L
        offset = 40
        while (offset + 1 < 40 + length) {
            sum += u16(packet, offset).toLong()
            offset += 2
        }
        if (offset < 40 + length) sum += ((packet[offset].toInt() and 0xff) shl 8).toLong()
        while ((sum ushr 16) != 0L) sum = (sum and 0xffff) + (sum ushr 16)
        return sum.inv().toInt() and 0xffff
    }
}
