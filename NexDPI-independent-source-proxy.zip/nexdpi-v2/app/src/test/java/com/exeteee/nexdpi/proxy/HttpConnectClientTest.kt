package com.exeteee.nexdpi.proxy

import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.Base64
import kotlin.concurrent.thread
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HttpConnectClientTest {
    @Test
    fun establishesConnectTunnelWithBasicAuthentication() {
        ServerSocket(0).use { server ->
            var serverFailure: Throwable? = null
            val worker = thread(isDaemon = true) {
                try {
                    server.accept().use { peer ->
                        val request = readHeaders(peer)
                        assertTrue(request.startsWith("CONNECT 1.2.3.4:443 HTTP/1.1\r\n"))
                        val expected = Base64.getEncoder().encodeToString("user:pass".toByteArray())
                        assertTrue(request.contains("Proxy-Authorization: Basic $expected"))
                        peer.getOutputStream().write("HTTP/1.1 200 Connection Established\r\n\r\nOK".toByteArray())
                    }
                } catch (error: Throwable) {
                    serverFailure = error
                }
            }
            val profile = ProxyProfile(
                type = ProxyType.HTTP_CONNECT, server = "127.0.0.1", port = server.localPort,
                username = "user", password = "pass"
            )
            Socket().use { socket ->
                HttpConnectClient.connect(socket, profile, InetAddress.getByAddress(byteArrayOf(1, 2, 3, 4)), 443, 2_000)
                val payload = ByteArray(2)
                var offset = 0
                while (offset < payload.size) offset += socket.getInputStream().read(payload, offset, payload.size - offset)
                assertEquals("OK", payload.toString(Charsets.UTF_8))
            }
            worker.join(2_000)
            serverFailure?.let { throw AssertionError("HTTP proxy test server failed", it) }
        }
    }

    private fun readHeaders(socket: Socket): String {
        val output = StringBuilder()
        while (output.length < 8_192 && !output.endsWith("\r\n\r\n")) {
            val value = socket.getInputStream().read()
            check(value >= 0) { "Proxy closed before returning headers" }
            output.append(value.toChar())
        }
        check(output.endsWith("\r\n\r\n"))
        return output.toString()
    }
}
