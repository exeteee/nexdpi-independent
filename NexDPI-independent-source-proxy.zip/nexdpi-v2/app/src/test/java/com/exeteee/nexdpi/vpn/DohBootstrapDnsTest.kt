package com.exeteee.nexdpi.vpn

import java.net.InetAddress
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DohBootstrapDnsTest {
    private val bootstrap = DohBootstrapDns()

    @Test
    fun cloudflareUsesPublishedIpv4AndIpv6Addresses() {
        val actual = bootstrap.lookup("cloudflare-dns.com")
        assertEquals(4, actual.size)
        assertContains(actual, "1.1.1.1")
        assertContains(actual, "1.0.0.1")
        assertContains(actual, "2606:4700:4700::1111")
        assertContains(actual, "2606:4700:4700::1001")
    }

    @Test
    fun googleUsesPublicDnsAnycastAddresses() {
        val actual = bootstrap.lookup("dns.google")
        assertEquals(4, actual.size)
        assertContains(actual, "8.8.8.8")
        assertContains(actual, "8.8.4.4")
        assertContains(actual, "2001:4860:4860::8888")
        assertContains(actual, "2001:4860:4860::8844")
    }

    @Test
    fun quad9UsesPublishedAnycastAddresses() {
        val actual = bootstrap.lookup("dns.quad9.net")
        assertEquals(4, actual.size)
        assertContains(actual, "9.9.9.9")
        assertContains(actual, "149.112.112.112")
        assertContains(actual, "2620:fe::fe")
        assertContains(actual, "2620:fe::9")
    }

    @Test
    fun lookupIsCaseInsensitive() {
        assertEquals(
            bootstrap.lookup("dns.google").map { it.address.toList() },
            bootstrap.lookup("DNS.GOOGLE").map { it.address.toList() }
        )
    }

    private fun assertContains(actual: List<InetAddress>, expected: String) {
        val expectedBytes = InetAddress.getByName(expected).address
        assertTrue("Missing bootstrap address $expected", actual.any { it.address.contentEquals(expectedBytes) })
    }
}
