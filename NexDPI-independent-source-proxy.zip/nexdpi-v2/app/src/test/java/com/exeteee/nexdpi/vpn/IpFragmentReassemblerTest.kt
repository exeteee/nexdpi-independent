package com.exeteee.nexdpi.vpn

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class IpFragmentReassemblerTest {
    @Test
    fun reassemblesIpv4FragmentsArrivingOutOfOrder() {
        val original = ipv4DnsQuery()
        val fragments = fragmentIpv4(original, 24)
        val reassembler = IpFragmentReassembler()

        assertNull(reassembler.accept(fragments[1]))
        val rebuilt = reassembler.accept(fragments[0])
        assertNotNull(rebuilt)
        rebuilt!!
        assertArrayEquals(original, rebuilt)
        assertNotNull(DnsPacketCodec.parseQuery(rebuilt))
    }

    @Test
    fun reassemblesIpv6FragmentsAndRemovesFragmentHeader() {
        val original = ipv6DnsQuery()
        val fragments = fragmentIpv6(original, 24)
        val reassembler = IpFragmentReassembler()

        assertNull(reassembler.accept(fragments[1]))
        val rebuilt = reassembler.accept(fragments[0])
        assertNotNull(rebuilt)
        rebuilt!!
        assertArrayEquals(original, rebuilt)
        assertNotNull(DnsPacketCodec.parseQuery(rebuilt))
    }

    @Test
    fun discardsOverlappingIpv4Fragments() {
        val original = ipv4DnsQuery()
        val fragments = fragmentIpv4(original, 24)
        val overlapping = fragments[1].copyOf()
        put16(overlapping, 6, 1) // Offset 8 overlaps the first fragment's payload.
        put16(overlapping, 10, 0)
        put16(overlapping, 10, checksum(overlapping, 0, (overlapping[0].toInt() and 0x0f) * 4))
        val reassembler = IpFragmentReassembler()

        assertNull(reassembler.accept(fragments[0]))
        assertNull(reassembler.accept(overlapping))
        // Once overlap is detected the whole datagram is discarded.
        assertNull(reassembler.accept(fragments[1]))
    }

    @Test
    fun clearDropsIncompleteDatagramsBetweenVpnSessions() {
        val original = ipv4DnsQuery()
        val fragments = fragmentIpv4(original, 24)
        val reassembler = IpFragmentReassembler()

        assertNull(reassembler.accept(fragments[0]))
        reassembler.clear()
        assertNull(reassembler.accept(fragments[1]))
        val rebuilt = reassembler.accept(fragments[0])
        assertNotNull(rebuilt)
        assertArrayEquals(original, rebuilt!!)
    }

    @Test
    fun rejectsIpv4FragmentsWithInvalidHeaderChecksum() {
        val fragment = fragmentIpv4(ipv4DnsQuery(), 24).first().apply {
            this[8] = 63
        }
        assertNull(IpFragmentReassembler().accept(fragment))
    }

    @Test
    fun passesUnfragmentedPacketsThroughUnchanged() {
        val packet = ipv4DnsQuery()
        assertTrue(IpFragmentReassembler().accept(packet) === packet)
    }

    private fun fragmentIpv4(packet: ByteArray, firstPayloadSize: Int): List<ByteArray> {
        val headerLength = (packet[0].toInt() and 0x0f) * 4
        val payload = packet.copyOfRange(headerLength, packet.size)
        require(firstPayloadSize % 8 == 0 && firstPayloadSize < payload.size)
        return listOf(
            makeIpv4Fragment(packet, headerLength, payload, 0, firstPayloadSize, true),
            makeIpv4Fragment(packet, headerLength, payload, firstPayloadSize, payload.size - firstPayloadSize, false)
        )
    }

    private fun makeIpv4Fragment(
        original: ByteArray,
        headerLength: Int,
        payload: ByteArray,
        offset: Int,
        length: Int,
        more: Boolean
    ): ByteArray {
        val fragment = ByteArray(headerLength + length)
        original.copyOfRange(0, headerLength).copyInto(fragment)
        put16(fragment, 2, fragment.size)
        put16(fragment, 4, 0x4242)
        put16(fragment, 6, (offset / 8) or if (more) 0x2000 else 0)
        payload.copyInto(fragment, headerLength, offset, offset + length)
        put16(fragment, 10, 0)
        put16(fragment, 10, checksum(fragment, 0, headerLength))
        return fragment
    }

    private fun fragmentIpv6(packet: ByteArray, firstPayloadSize: Int): List<ByteArray> {
        val payload = packet.copyOfRange(40, packet.size)
        require(firstPayloadSize % 8 == 0 && firstPayloadSize < payload.size)
        return listOf(
            makeIpv6Fragment(packet, payload, 0, firstPayloadSize, true),
            makeIpv6Fragment(packet, payload, firstPayloadSize, payload.size - firstPayloadSize, false)
        )
    }

    private fun makeIpv6Fragment(
        original: ByteArray,
        payload: ByteArray,
        offset: Int,
        length: Int,
        more: Boolean
    ): ByteArray {
        val fragment = ByteArray(48 + length)
        original.copyOfRange(0, 40).copyInto(fragment)
        fragment[6] = 44
        put16(fragment, 4, 8 + length)
        fragment[40] = 17
        val flags = offset or if (more) 1 else 0
        put16(fragment, 42, flags)
        put32(fragment, 44, 0x10203040)
        payload.copyInto(fragment, 48, offset, offset + length)
        return fragment
    }

    private fun ipv4DnsQuery(): ByteArray {
        val dns = dnsQuestion()
        val packet = ByteArray(20 + 8 + dns.size)
        packet[0] = 0x45
        put16(packet, 2, packet.size)
        put16(packet, 4, 0x4242)
        packet[8] = 64
        packet[9] = 17
        byteArrayOf(192.toByte(), 0, 2, 10).copyInto(packet, 12)
        byteArrayOf(10, 77, 0, 1).copyInto(packet, 16)
        put16(packet, 20, 50_000)
        put16(packet, 22, 53)
        put16(packet, 24, 8 + dns.size)
        dns.copyInto(packet, 28)
        put16(packet, 10, checksum(packet, 0, 20))
        return packet
    }

    private fun ipv6DnsQuery(): ByteArray {
        val dns = dnsQuestion()
        val packet = ByteArray(40 + 8 + dns.size)
        packet[0] = 0x60
        put16(packet, 4, 8 + dns.size)
        packet[6] = 17
        packet[7] = 64
        ByteArray(16).apply { this[0] = 0x20; this[1] = 1; this[15] = 10 }.copyInto(packet, 8)
        ByteArray(16).apply { this[0] = 0xfd.toByte(); this[1] = 0x77; this[2] = 0; this[3] = 0x77; this[15] = 1 }.copyInto(packet, 24)
        put16(packet, 40, 53_101)
        put16(packet, 42, 53)
        put16(packet, 44, 8 + dns.size)
        dns.copyInto(packet, 48)
        return packet
    }

    private fun dnsQuestion(): ByteArray = byteArrayOf(
        0x12, 0x34, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x07, 0x65, 0x78, 0x61,
        0x6d, 0x70, 0x6c, 0x65, 0x03, 0x63, 0x6f, 0x6d,
        0x00, 0x00, 0x01, 0x00, 0x01
    )

    private fun u16(bytes: ByteArray, offset: Int): Int =
        ((bytes[offset].toInt() and 0xff) shl 8) or (bytes[offset + 1].toInt() and 0xff)

    private fun put16(bytes: ByteArray, offset: Int, value: Int) {
        bytes[offset] = (value ushr 8).toByte()
        bytes[offset + 1] = value.toByte()
    }

    private fun checksum(bytes: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var index = offset
        while (index + 1 < offset + length) {
            sum += (((bytes[index].toInt() and 0xff) shl 8) or
                (bytes[index + 1].toInt() and 0xff)).toLong()
            index += 2
        }
        while ((sum ushr 16) != 0L) sum = (sum and 0xffff) + (sum ushr 16)
        return sum.inv().toInt() and 0xffff
    }

    private fun put32(bytes: ByteArray, offset: Int, value: Int) {
        bytes[offset] = (value ushr 24).toByte()
        bytes[offset + 1] = (value ushr 16).toByte()
        bytes[offset + 2] = (value ushr 8).toByte()
        bytes[offset + 3] = value.toByte()
    }
}
