package com.exeteee.nexdpi.vpn

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class UdpPacketCodecTest {
    private val v4Local = byteArrayOf(10, 77, 0, 2)
    private val v4Remote = byteArrayOf(203.toByte(), 0, 113, 9)
    private val v6Local = byteArrayOf(0xfd.toByte(), 0x77, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2)
    private val v6Remote = byteArrayOf(0x20, 0x01, 0x0d, 0xb8.toByte(), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9)

    @Test
    fun buildsAndParsesIpv4UdpResponseWithValidChecksum() {
        val payload = "udp-response".toByteArray()
        val packet = UdpPacketCodec.buildResponsePackets(
            request(4), payload
        )!!.single()
        val parsed = UdpPacketCodec.parse(packet)
        assertNotNull(parsed)
        parsed!!
        assertEquals(4, parsed.ipVersion)
        assertArrayEquals(v4Remote, parsed.sourceAddress)
        assertArrayEquals(v4Local, parsed.destinationAddress)
        assertEquals(443, parsed.sourcePort)
        assertEquals(53_000, parsed.destinationPort)
        assertArrayEquals(payload, parsed.payload)
        assertTrue(UdpPacketCodec.isValidUdpChecksum(parsed, packet))
        assertEquals(0, checksum(packet, 0, 20))
    }

    @Test
    fun buildsAndParsesIpv6UdpResponseWithMandatoryChecksum() {
        val payload = byteArrayOf(1, 2, 3, 4, 5)
        val packet = UdpPacketCodec.buildResponsePackets(request(6), payload)!!.single()
        val parsed = UdpPacketCodec.parse(packet)
        assertNotNull(parsed)
        parsed!!
        assertEquals(6, parsed.ipVersion)
        assertArrayEquals(v6Remote, parsed.sourceAddress)
        assertArrayEquals(v6Local, parsed.destinationAddress)
        assertArrayEquals(payload, parsed.payload)
        assertTrue(UdpPacketCodec.isValidUdpChecksum(parsed, packet))
        assertTrue(u16(packet, 46) != 0)
    }

    @Test
    fun acceptsIpv4ZeroUdpChecksumButRejectsIpv6ZeroChecksum() {
        val ipv4 = UdpPacketCodec.buildResponsePackets(request(4), byteArrayOf(1, 2))!!.single()
        put16(ipv4, 26, 0)
        assertNotNull(UdpPacketCodec.parse(ipv4))

        val ipv6 = UdpPacketCodec.buildResponsePackets(request(6), byteArrayOf(1, 2))!!.single()
        put16(ipv6, 46, 0)
        assertNull(UdpPacketCodec.parse(ipv6))
    }

    @Test
    fun parsesIpv4OptionsBeforeUdpHeader() {
        val base = UdpPacketCodec.buildResponsePackets(request(4), "opts".toByteArray())!!.single()
        val packet = ByteArray(base.size + 4)
        base.copyOfRange(0, 20).copyInto(packet)
        byteArrayOf(1, 1, 1, 1).copyInto(packet, 20)
        base.copyOfRange(20, base.size).copyInto(packet, 24)
        packet[0] = 0x46
        put16(packet, 2, packet.size)
        put16(packet, 10, 0)
        put16(packet, 10, checksum(packet, 0, 24))

        val parsed = UdpPacketCodec.parse(packet)
        assertNotNull(parsed)
        assertArrayEquals("opts".toByteArray(), parsed!!.payload)
    }

    @Test
    fun parsesIpv6HopByHopHeaderBeforeUdp() {
        val base = UdpPacketCodec.buildResponsePackets(request(6), "hbh".toByteArray())!!.single()
        val packet = ByteArray(base.size + 8)
        base.copyOfRange(0, 40).copyInto(packet)
        packet[6] = 0
        put16(packet, 4, u16(base, 4) + 8)
        packet[40] = 17
        packet[41] = 0
        base.copyOfRange(40, base.size).copyInto(packet, 48)

        val parsed = UdpPacketCodec.parse(packet)
        assertNotNull(parsed)
        assertArrayEquals("hbh".toByteArray(), parsed!!.payload)
    }

    @Test
    fun rejectsBadChecksumAndMalformedLengths() {
        val packet = UdpPacketCodec.buildResponsePackets(request(4), "checksum".toByteArray())!!.single()
        packet[packet.lastIndex] = (packet.last().toInt() xor 1).toByte()
        assertNull(UdpPacketCodec.parse(packet))

        val badIpHeader = UdpPacketCodec.buildResponsePackets(request(4), "ip checksum".toByteArray())!!.single()
        badIpHeader[8] = 63
        assertNull(UdpPacketCodec.parse(badIpHeader))

        val malformed = UdpPacketCodec.buildResponsePackets(request(4), byteArrayOf(1))!!.single()
        put16(malformed, 24, 7)
        assertNull(UdpPacketCodec.parse(malformed))
        assertNull(UdpPacketCodec.parse(malformed, 27))
    }

    @Test
    fun fragmentsLargeIpv4DatagramAndReassemblesIt() {
        val payload = ByteArray(4_000) { (it * 31).toByte() }
        val fragments = UdpPacketCodec.buildResponsePackets(request(4), payload, mtu = 600)
        assertNotNull(fragments)
        fragments!!
        assertTrue(fragments.size > 1)
        assertTrue(fragments.all { it.size <= 600 })
        val reassembler = IpFragmentReassembler()
        var complete: ByteArray? = null
        fragments.reversed().forEach { complete = reassembler.accept(it) ?: complete }
        assertNotNull(complete)
        val parsed = UdpPacketCodec.parse(complete!!)
        assertNotNull(parsed)
        assertArrayEquals(payload, parsed!!.payload)
    }

    @Test
    fun fragmentsLargeIpv6DatagramAndReassemblesIt() {
        val payload = ByteArray(4_000) { (it * 17).toByte() }
        val fragments = UdpPacketCodec.buildResponsePackets(request(6), payload, mtu = 600)
        assertNotNull(fragments)
        fragments!!
        assertTrue(fragments.size > 1)
        assertTrue(fragments.all { it.size <= 600 })
        val reassembler = IpFragmentReassembler()
        var complete: ByteArray? = null
        fragments.forEach { complete = reassembler.accept(it) ?: complete }
        assertNotNull(complete)
        val parsed = UdpPacketCodec.parse(complete!!)
        assertNotNull(parsed)
        assertArrayEquals(payload, parsed!!.payload)
    }

    @Test
    fun rejectsInvalidResponseParametersAndFragmentedInput() {
        assertNull(UdpPacketCodec.buildResponsePackets(request(4), ByteArray(65_528)))
        assertNull(UdpPacketCodec.buildResponsePackets(request(4), byteArrayOf(1), mtu = 500))
        val fragmented = UdpPacketCodec.buildResponsePackets(request(4), ByteArray(2_000), mtu = 600)!!.first()
        assertFalse(UdpPacketCodec.parse(fragmented) != null)
    }

    private fun request(version: Int) = if (version == 4) {
        UdpDatagram(4, v4Local, v4Remote, 53_000, 443, byteArrayOf(9))
    } else {
        UdpDatagram(6, v6Local, v6Remote, 53_000, 443, byteArrayOf(9))
    }

    private fun u16(bytes: ByteArray, offset: Int): Int =
        ((bytes[offset].toInt() and 0xff) shl 8) or (bytes[offset + 1].toInt() and 0xff)

    private fun put16(bytes: ByteArray, offset: Int, value: Int) {
        bytes[offset] = (value ushr 8).toByte()
        bytes[offset + 1] = value.toByte()
    }

    private fun checksum(bytes: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var index = offset
        val end = offset + length
        while (index + 1 < end) {
            sum += (((bytes[index].toInt() and 0xff) shl 8) or (bytes[index + 1].toInt() and 0xff)).toLong()
            index += 2
        }
        if (index < end) sum += ((bytes[index].toInt() and 0xff) shl 8).toLong()
        while ((sum ushr 16) != 0L) sum = (sum and 0xffff) + (sum ushr 16)
        return sum.inv().toInt() and 0xffff
    }
}
