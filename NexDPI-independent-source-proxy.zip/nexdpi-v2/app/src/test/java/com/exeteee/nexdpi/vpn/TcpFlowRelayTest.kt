package com.exeteee.nexdpi.vpn

import java.net.InetAddress
import java.net.ServerSocket
import java.net.SocketTimeoutException
import java.net.SocketAddress
import java.net.SocketException
import java.net.Socket
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TcpFlowRelayTest {
    private val clientAddress = byteArrayOf(10, 77, 0, 2)
    private val loopbackAddress = byteArrayOf(127, 0, 0, 1)

    @Test
    fun performsLocalTcpHandshakeAndRelaysBidirectionalStream() {
        ServerSocket(0, 8, InetAddress.getByName("127.0.0.1")).use { server ->
            server.soTimeout = 3_000
            val serverFailure = ArrayBlockingQueue<Throwable>(1)
            val serverThread = Thread {
                try {
                    server.accept().use { accepted ->
                        accepted.soTimeout = 3_000
                        val request = ByteArray(5)
                        var offset = 0
                        while (offset < request.size) {
                            val read = accepted.getInputStream().read(request, offset, request.size - offset)
                            if (read < 0) throw AssertionError("unexpected EOF")
                            offset += read
                        }
                        if (!request.contentEquals("hello".toByteArray())) throw AssertionError("bad request")
                        accepted.getOutputStream().write("world".toByteArray())
                        accepted.getOutputStream().flush()
                    }
                } catch (error: Throwable) {
                    serverFailure.offer(error)
                }
            }.apply { isDaemon = true; start() }

            val output = ArrayBlockingQueue<ByteArray>(16)
            val protectedCalls = AtomicInteger()
            val relay = TcpFlowRelay(
                protectSocket = { protectedCalls.incrementAndGet(); true },
                packetWriter = { packet -> output.offer(packet.copyOf()) },
                initialServerSequence = { 2_000L },
                idleTimeoutMillis = 15_000
            )
            try {
                relay.handlePacket(clientPacket(server.localPort, sequence = 1_000, acknowledgement = 0,
                    flags = TcpPacketCodec.FLAG_SYN))
                val (synAck, _) = nextPacket(output) { it.isSyn && it.isAck }
                assertEquals(2_000L, synAck.sequenceNumber)
                assertEquals(1_001L, synAck.acknowledgementNumber)
                assertTrue(synAck.options.contentEquals(byteArrayOf(2, 4, 4, 176.toByte())))

                relay.handlePacket(clientPacket(server.localPort, sequence = 1_001, acknowledgement = 2_001,
                    flags = TcpPacketCodec.FLAG_ACK))
                relay.handlePacket(clientPacket(server.localPort, sequence = 1_001, acknowledgement = 2_001,
                    flags = TcpPacketCodec.FLAG_ACK or TcpPacketCodec.FLAG_PSH,
                    payload = "hello".toByteArray()))

                val (remoteData, remoteDataPacket) = nextPacket(output) { it.payload.contentEquals("world".toByteArray()) }
                assertEquals(2_001L, remoteData.sequenceNumber)
                assertEquals(1_006L, remoteData.acknowledgementNumber)
                assertTrue(remoteData.isAck)
                assertTrue(TcpPacketCodec.isValidTcpChecksum(remoteData, remoteDataPacket))

                // Wait for the remote FIN before acknowledging both its sequence space and data.
                val (remoteFin, _) = nextPacket(output) { it.isFin && it.isAck }
                assertEquals(2_006L, remoteFin.sequenceNumber)
                assertEquals(1_006L, remoteFin.acknowledgementNumber)
                relay.handlePacket(clientPacket(server.localPort, sequence = 1_006, acknowledgement = 2_007,
                    flags = TcpPacketCodec.FLAG_ACK))
                relay.handlePacket(clientPacket(server.localPort, sequence = 1_006, acknowledgement = 2_007,
                    flags = TcpPacketCodec.FLAG_ACK or TcpPacketCodec.FLAG_FIN))
                assertEquals(0, relay.activeFlowCount())
                assertEquals(1, protectedCalls.get())
                serverFailure.poll(1, TimeUnit.SECONDS)?.let { throw AssertionError("local echo server failed", it) }
            } finally {
                relay.close()
                serverThread.join(2_000)
            }
        }
    }

    @Test
    fun relaysClientUploadLargerThanSlidingWindow() {
        val expected = ByteArray(100_000) { (it * 31).toByte() }
        ServerSocket(0, 8, InetAddress.getByName("127.0.0.1")).use { server ->
            server.soTimeout = 5_000
            val serverFailure = ArrayBlockingQueue<Throwable>(1)
            val serverThread = Thread {
                try {
                    server.accept().use { accepted ->
                        accepted.soTimeout = 5_000
                        val received = ByteArray(expected.size)
                        var offset = 0
                        while (offset < received.size) {
                            val count = accepted.getInputStream().read(received, offset, received.size - offset)
                            if (count < 0) throw AssertionError("unexpected EOF after $offset bytes")
                            offset += count
                        }
                        if (!received.contentEquals(expected)) throw AssertionError("large upload changed in transit")
                        accepted.getOutputStream().write("ok".toByteArray())
                        accepted.getOutputStream().flush()
                    }
                } catch (error: Throwable) {
                    serverFailure.offer(error)
                }
            }.apply { isDaemon = true; start() }

            val output = ArrayBlockingQueue<ByteArray>(512)
            val relay = TcpFlowRelay(
                protectSocket = { true },
                packetWriter = { packet -> output.offer(packet.copyOf()) },
                initialServerSequence = { 20_000L },
                idleTimeoutMillis = 15_000
            )
            try {
                relay.handlePacket(clientPacket(server.localPort, sequence = 10_000, acknowledgement = 0,
                    flags = TcpPacketCodec.FLAG_SYN))
                nextPacket(output) { it.isSyn && it.isAck }
                relay.handlePacket(clientPacket(server.localPort, sequence = 10_001, acknowledgement = 20_001,
                    flags = TcpPacketCodec.FLAG_ACK))

                var offset = 0
                while (offset < expected.size) {
                    val end = minOf(offset + 1_000, expected.size)
                    val flags = TcpPacketCodec.FLAG_ACK or TcpPacketCodec.FLAG_PSH
                    relay.handlePacket(clientPacket(
                        server.localPort,
                        sequence = 10_001L + offset,
                        acknowledgement = 20_001,
                        flags = flags,
                        payload = expected.copyOfRange(offset, end)
                    ))
                    offset = end
                }

                val (reply, _) = nextPacket(output) { it.payload.contentEquals("ok".toByteArray()) }
                assertEquals(10_001L + expected.size, reply.acknowledgementNumber)
                assertTrue(serverFailure.poll(1, TimeUnit.SECONDS) == null)
            } finally {
                relay.close()
                serverThread.join(2_000)
            }
        }
    }

    @Test
    fun relaysRemoteDownloadLargerThanPeerWindowWithAcknowledgements() {
        val expected = ByteArray(100_000) { (it * 17 + 3).toByte() }
        ServerSocket(0, 8, InetAddress.getByName("127.0.0.1")).use { server ->
            server.soTimeout = 5_000
            val serverFailure = ArrayBlockingQueue<Throwable>(1)
            val serverThread = Thread {
                try {
                    server.accept().use { accepted ->
                        accepted.getOutputStream().write(expected)
                        accepted.getOutputStream().flush()
                        accepted.shutdownOutput()
                    }
                } catch (error: Throwable) {
                    serverFailure.offer(error)
                }
            }.apply { isDaemon = true; start() }

            val output = ArrayBlockingQueue<ByteArray>(512)
            val relayed = ByteArrayOutputStream(expected.size)
            val receivedBytes = AtomicInteger()
            val receivedAll = CountDownLatch(1)
            val relayReference = AtomicReference<TcpFlowRelay?>()
            val clientSequence = 30_001L
            val relay = TcpFlowRelay(
                protectSocket = { true },
                packetWriter = { packet ->
                    output.offer(packet.copyOf())
                    val segment = TcpPacketCodec.parse(packet)
                    if (segment != null && (segment.payload.isNotEmpty() || segment.isFin)) {
                        synchronized(relayed) { relayed.write(segment.payload) }
                        val newlyReceived = receivedBytes.addAndGet(segment.payload.size)
                        if (newlyReceived >= expected.size) receivedAll.countDown()
                        val acknowledgement = (segment.sequenceNumber + segment.payload.size +
                            if (segment.isFin) 1 else 0) and 0xffff_ffffL
                        relayReference.get()?.handlePacket(clientPacket(
                            server.localPort,
                            sequence = clientSequence,
                            acknowledgement = acknowledgement,
                            flags = TcpPacketCodec.FLAG_ACK
                        ))
                    }
                },
                initialServerSequence = { 40_000L },
                idleTimeoutMillis = 15_000
            )
            relayReference.set(relay)
            try {
                relay.handlePacket(clientPacket(server.localPort, sequence = 30_000, acknowledgement = 0,
                    flags = TcpPacketCodec.FLAG_SYN))
                nextPacket(output) { it.isSyn && it.isAck }
                relay.handlePacket(clientPacket(server.localPort, sequence = clientSequence, acknowledgement = 40_001,
                    flags = TcpPacketCodec.FLAG_ACK))
                assertTrue("server response was not fully relayed", receivedAll.await(8, TimeUnit.SECONDS))
                synchronized(relayed) {
                    assertTrue(relayed.toByteArray().contentEquals(expected))
                }
                serverFailure.poll(1, TimeUnit.SECONDS)?.let { throw AssertionError("download server failed", it) }
            } finally {
                relay.close()
                serverThread.join(2_000)
            }
        }
    }

    @Test
    fun splitsTlsClientHelloInsideTcpRelayWithoutChangingItsBytes() {
        val hello = clientHello("example.com")
        ServerSocket(0, 8, InetAddress.getByName("127.0.0.1")).use { server ->
            server.soTimeout = 3_000
            val serverFailure = ArrayBlockingQueue<Throwable>(1)
            val serverThread = Thread {
                try {
                    server.accept().use { accepted ->
                        accepted.soTimeout = 3_000
                        val received = ByteArray(hello.size)
                        var offset = 0
                        while (offset < received.size) {
                            val count = accepted.getInputStream().read(received, offset, received.size - offset)
                            if (count < 0) throw AssertionError("unexpected EOF in ClientHello")
                            offset += count
                        }
                        if (!received.contentEquals(hello)) throw AssertionError("TLS split changed ClientHello bytes")
                        accepted.getOutputStream().write("ok".toByteArray())
                        accepted.getOutputStream().flush()
                    }
                } catch (error: Throwable) {
                    serverFailure.offer(error)
                }
            }.apply { isDaemon = true; start() }

            val output = ArrayBlockingQueue<ByteArray>(16)
            val selector = TlsSplitStrategySelector(listOf(TlsSplitPoint.MIDDLE_OF_SNI))
            val relay = TcpFlowRelay(
                protectSocket = { true },
                packetWriter = { packet -> output.offer(packet.copyOf()) },
                tlsSplitSelector = selector,
                tlsSplitDelayMillis = 0,
                initialServerSequence = { 7_000L },
                idleTimeoutMillis = 10_000
            )
            try {
                relay.handlePacket(clientPacket(server.localPort, sequence = 6_000, acknowledgement = 0,
                    flags = TcpPacketCodec.FLAG_SYN))
                nextPacket(output) { it.isSyn && it.isAck }
                relay.handlePacket(clientPacket(server.localPort, sequence = 6_001, acknowledgement = 7_001,
                    flags = TcpPacketCodec.FLAG_ACK))
                val splitAt = 11
                relay.handlePacket(clientPacket(server.localPort, sequence = 6_001, acknowledgement = 7_001,
                    flags = TcpPacketCodec.FLAG_ACK or TcpPacketCodec.FLAG_PSH,
                    payload = hello.copyOfRange(0, splitAt)))
                relay.handlePacket(clientPacket(server.localPort, sequence = 6_001L + splitAt, acknowledgement = 7_001,
                    flags = TcpPacketCodec.FLAG_ACK or TcpPacketCodec.FLAG_PSH,
                    payload = hello.copyOfRange(splitAt, hello.size)))

                val (reply, _) = nextPacket(output) { it.payload.contentEquals("ok".toByteArray()) }
                assertEquals(6_001L + hello.size, reply.acknowledgementNumber)
                assertEquals(1 to 0, selector.outcomeCounts("example.com", TlsSplitPoint.MIDDLE_OF_SNI))
                serverFailure.poll(1, TimeUnit.SECONDS)?.let { throw AssertionError("TLS test server failed", it) }
            } finally {
                relay.close()
                serverThread.join(2_000)
            }
        }
    }

    @Test
    fun closingRelayClosesSocketWhileConnectIsInProgress() {
        val connectStarted = CountDownLatch(1)
        val socketClosed = CountDownLatch(1)
        val connectingSocket = object : Socket() {
            override fun connect(endpoint: SocketAddress?, timeout: Int) {
                connectStarted.countDown()
                if (!socketClosed.await(3, TimeUnit.SECONDS)) throw SocketTimeoutException("test timeout")
                throw SocketException("closed by relay")
            }

            override fun close() {
                socketClosed.countDown()
                super.close()
            }
        }
        val relay = TcpFlowRelay(
            protectSocket = { true },
            packetWriter = {},
            socketFactory = { connectingSocket }
        )
        try {
            relay.handlePacket(clientPacket(443, sequence = 1_000, acknowledgement = 0,
                flags = TcpPacketCodec.FLAG_SYN))
            assertTrue(connectStarted.await(2, TimeUnit.SECONDS))
            relay.close()
            assertTrue(socketClosed.await(1, TimeUnit.SECONDS))
            assertEquals(0, relay.activeFlowCount())
        } finally {
            relay.close()
        }
    }

    @Test
    fun refusesConnectionWhenProtectFails() {
        ServerSocket(0, 8, InetAddress.getByName("127.0.0.1")).use { reserved ->
            val port = reserved.localPort
            reserved.close()
            val output = ArrayBlockingQueue<ByteArray>(4)
            val relay = TcpFlowRelay(
                protectSocket = { false },
                packetWriter = { packet -> output.offer(packet.copyOf()) },
                initialServerSequence = { 5_000L }
            )
            try {
                relay.handlePacket(clientPacket(port, sequence = 10, acknowledgement = 0,
                    flags = TcpPacketCodec.FLAG_SYN))
                val (reset, _) = nextPacket(output) { it.isRst }
                assertTrue(reset.isAck)
                assertEquals(11L, reset.acknowledgementNumber)
                val cleanupDeadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(1)
                while (relay.activeFlowCount() != 0 && System.nanoTime() < cleanupDeadline) {
                    Thread.sleep(10)
                }
                assertEquals(0, relay.activeFlowCount())
            } finally {
                relay.close()
            }
        }
    }

    @Test
    fun rejectsPacketsWithInvalidTcpChecksum() {
        val output = ArrayBlockingQueue<ByteArray>(2)
        val relay = TcpFlowRelay(protectSocket = { true }, packetWriter = { packet -> output.offer(packet.copyOf()) })
        try {
            val packet = clientPacket(443, 1, 0, TcpPacketCodec.FLAG_SYN)
            packet[packet.lastIndex] = (packet.last().toInt() xor 1).toByte()
            relay.handlePacket(packet)
            assertEquals(0, relay.activeFlowCount())
            assertTrue(output.isEmpty())
        } finally {
            relay.close()
        }
    }

    private fun nextPacket(
        queue: ArrayBlockingQueue<ByteArray>,
        predicate: (TcpSegment) -> Boolean
    ): Pair<TcpSegment, ByteArray> {
        val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(4)
        while (System.nanoTime() < deadline) {
            val packet = queue.poll(200, TimeUnit.MILLISECONDS) ?: continue
            val segment = TcpPacketCodec.parse(packet) ?: continue
            if (predicate(segment)) return segment to packet
        }
        throw AssertionError("expected TCP segment was not received")
    }

    private fun clientHello(serverName: String): ByteArray {
        val body = ArrayList<Byte>()
        fun add(value: Int) { body.add(value.toByte()) }
        fun addU16(value: Int) { add(value ushr 8); add(value) }
        fun addBytes(bytes: ByteArray) { bytes.forEach { add(it.toInt() and 0xff) } }
        addU16(0x0303)
        repeat(32) { add(0) }
        add(0)
        addU16(2)
        addU16(0x1301)
        add(1)
        add(0)
        val hostname = serverName.toByteArray(Charsets.US_ASCII)
        val sniList = byteArrayOf(
            ((hostname.size + 3) ushr 8).toByte(), (hostname.size + 3).toByte(), 0,
            (hostname.size ushr 8).toByte(), hostname.size.toByte()
        ) + hostname
        val sniExtension = byteArrayOf(0, 0, (sniList.size ushr 8).toByte(), sniList.size.toByte()) + sniList
        val extensions = sniExtension + byteArrayOf(0, 23, 0, 0)
        addU16(extensions.size)
        addBytes(extensions)
        val handshakeBody = body.toByteArray()
        val handshake = byteArrayOf(
            1, (handshakeBody.size ushr 16).toByte(),
            (handshakeBody.size ushr 8).toByte(), handshakeBody.size.toByte()
        ) + handshakeBody
        return byteArrayOf(22, 3, 1, (handshake.size ushr 8).toByte(), handshake.size.toByte()) + handshake
    }

    private fun clientPacket(
        destinationPort: Int,
        sequence: Long,
        acknowledgement: Long,
        flags: Int,
        payload: ByteArray = ByteArray(0)
    ): ByteArray = TcpPacketCodec.build(
        ipVersion = 4,
        sourceAddress = clientAddress,
        destinationAddress = loopbackAddress,
        sourcePort = 54_000,
        destinationPort = destinationPort,
        sequenceNumber = sequence,
        acknowledgementNumber = acknowledgement,
        flags = flags,
        windowSize = 32_768,
        payload = payload
    )!!

}
