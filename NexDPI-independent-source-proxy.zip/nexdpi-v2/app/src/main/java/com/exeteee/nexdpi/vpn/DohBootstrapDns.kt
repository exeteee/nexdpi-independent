package com.exeteee.nexdpi.vpn

import java.net.InetAddress
import okhttp3.Dns

/**
 * Resolves the DoH endpoint hostnames to their published anycast addresses.
 * This avoids relying on the carrier's plaintext DNS just to reach the encrypted
 * DNS provider. TLS still validates the original hostname from the HTTPS URL.
 */
class DohBootstrapDns : Dns {
    override fun lookup(hostname: String): List<InetAddress> {
        val addresses = BOOTSTRAP_ADDRESSES[hostname.lowercase()]
            ?: return Dns.SYSTEM.lookup(hostname)

        return addresses.map { address ->
            // All entries are numeric IP literals; this does not make a DNS query.
            InetAddress.getByName(address)
        }
    }

    companion object {
        private val BOOTSTRAP_ADDRESSES = mapOf(
            "cloudflare-dns.com" to listOf(
                "1.1.1.1",
                "1.0.0.1",
                "2606:4700:4700::1111",
                "2606:4700:4700::1001"
            ),
            "dns.google" to listOf(
                "8.8.8.8",
                "8.8.4.4",
                "2001:4860:4860::8888",
                "2001:4860:4860::8844"
            ),
            "dns.quad9.net" to listOf(
                "9.9.9.9",
                "149.112.112.112",
                "2620:fe::fe",
                "2620:fe::9"
            )
        )
    }
}
