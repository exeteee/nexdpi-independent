package com.exeteee.nexdpi.proxy

import java.net.URI
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.UUID

/** SOCKS5/MTProto are Telegram mobile proxy types; HTTP CONNECT is available through Telegram's HTTP proxy support. */
enum class ProxyType { SOCKS5, HTTP_CONNECT, MTPROTO }

data class ProxyProfile(
    val id: String = UUID.randomUUID().toString(),
    val type: ProxyType,
    val server: String,
    val port: Int,
    val username: String? = null,
    val password: String? = null,
    val secret: String? = null,
    val label: String = ""
) {
    init {
        require(server.isNotBlank()) { "Адрес прокси не указан" }
        require(server.length <= 253) { "Слишком длинный адрес прокси" }
        require(server.none { it.isWhitespace() || it in "/?#@\\" }) { "Некорректный адрес прокси" }
        require(port in 1..65535) { "Порт должен быть от 1 до 65535" }
        if (type == ProxyType.MTPROTO) require(!secret.isNullOrBlank()) { "Для MTProto нужен secret" }
        if (type != ProxyType.MTPROTO) require(secret == null) { "Этот тип прокси не использует MTProto secret" }
        require((username?.toByteArray(StandardCharsets.UTF_8)?.size ?: 0) <= 255)
        require((password?.toByteArray(StandardCharsets.UTF_8)?.size ?: 0) <= 255)
    }

    fun displayName(): String = label.ifBlank {
        "${when (type) { ProxyType.SOCKS5 -> "SOCKS5"; ProxyType.HTTP_CONNECT -> "HTTP CONNECT"; ProxyType.MTPROTO -> "MTProto" }} · $server:$port"
    }

    /** Native deep link: Telegram itself performs its full MTProxy handshake. */
    fun telegramDeepLink(): String {
        require(type == ProxyType.MTPROTO) { "Deep link is only available for MTProto" }
        return URIBuilder.build("proxy", mapOf(
            "server" to server,
            "port" to port.toString(),
            "secret" to requireNotNull(secret)
        ))
    }

    override fun toString(): String = "ProxyProfile(id=$id, type=$type, server=$server, port=$port, credentials=redacted)"
}

data class ProxySettings(
    val profiles: List<ProxyProfile> = emptyList(),
    val selectedId: String? = null,
    val enabled: Boolean = false
) {
    fun selected(): ProxyProfile? = profiles.firstOrNull { it.id == selectedId }
}

sealed class ProxyParseResult {
    data class Success(val profile: ProxyProfile) : ProxyParseResult()
    data class Error(val message: String) : ProxyParseResult()
}

/** Parses Telegram t.me/tg:// proxy links plus SOCKS5 and HTTP CONNECT URI forms. */
object TelegramProxyLinkParser {
    fun parse(input: String): ProxyParseResult {
        val raw = input.trim().trim('<', '>', '"', '\'')
        if (raw.isEmpty()) return ProxyParseResult.Error("Вставь ссылку на прокси")
        return try {
            when {
                raw.startsWith("socks5://", ignoreCase = true) || raw.startsWith("socks5h://", ignoreCase = true) -> parseSocksUri(raw)
                raw.startsWith("http://", ignoreCase = true) && !isTelegramHost(raw) -> parseHttpConnectUri(raw)
                raw.startsWith("tg://", ignoreCase = true) || raw.startsWith("tg:", ignoreCase = true) -> parseTelegramUri(raw)
                raw.startsWith("http://", ignoreCase = true) || raw.startsWith("https://", ignoreCase = true) ||
                    raw.startsWith("t.me/", ignoreCase = true) || raw.startsWith("telegram.me/", ignoreCase = true) ||
                    raw.startsWith("telegram.dog/", ignoreCase = true) -> parseTelegramLink(raw)
                else -> ProxyParseResult.Error("Поддерживаются Telegram-ссылки t.me/proxy и t.me/socks, socks5:// и http://host:port")
            }
        } catch (error: IllegalArgumentException) {
            ProxyParseResult.Error(error.message ?: "Некорректная ссылка на прокси")
        } catch (_: Exception) {
            ProxyParseResult.Error("Не удалось разобрать ссылку на прокси")
        }
    }

    private fun isTelegramHost(raw: String): Boolean = runCatching {
        URI(raw).host?.lowercase(Locale.ROOT)?.let {
            it == "t.me" || it == "telegram.me" || it == "telegram.dog" || it.endsWith(".t.me")
        } == true
    }.getOrDefault(false)

    private fun parseHttpConnectUri(raw: String): ProxyParseResult {
        val uri = URI(raw)
        require(uri.rawPath.isNullOrEmpty() || uri.rawPath == "/") { "HTTP proxy URI не должен содержать путь" }
        require(uri.rawQuery == null && uri.rawFragment == null) { "HTTP proxy URI содержит лишние параметры" }
        val host = uri.host ?: throw IllegalArgumentException("В HTTP proxy URI не указан сервер")
        val port = uri.port.takeIf { it in 1..65535 }
            ?: throw IllegalArgumentException("В HTTP proxy URI не указан корректный порт")
        val userInfo = uri.rawUserInfo?.split(':', limit = 2)
        return ProxyParseResult.Success(
            ProxyProfile(
                type = ProxyType.HTTP_CONNECT,
                server = host,
                port = port,
                username = userInfo?.getOrNull(0)?.let(::decode),
                password = userInfo?.getOrNull(1)?.let(::decode)
            )
        )
    }

    private fun parseTelegramUri(raw: String): ProxyParseResult {
        val normalized = if (raw.startsWith("tg://", true)) raw else raw.replaceFirst("tg:", "tg://", true)
        val uri = URI(normalized)
        val kind = uri.host?.lowercase(Locale.ROOT) ?: uri.rawSchemeSpecificPart.substringBefore('?').trimStart('/')
        val params = parseQuery(uri.rawQuery ?: uri.rawSchemeSpecificPart.substringAfter('?', ""))
        return build(kind, params)
    }

    private fun parseTelegramLink(raw: String): ProxyParseResult {
        val normalized = if (raw.startsWith("http", true)) raw else "https://$raw"
        val uri = URI(normalized)
        val host = uri.host?.lowercase(Locale.ROOT)
            ?: throw IllegalArgumentException("В ссылке отсутствует домен")
        require(host == "t.me" || host == "telegram.me" || host == "telegram.dog" || host.endsWith(".t.me")) {
            "Это не ссылка Telegram"
        }
        val kind = uri.path.trim('/').substringBefore('/').lowercase(Locale.ROOT)
        val params = parseQuery(uri.rawQuery ?: "")
        return build(kind, params)
    }

    private fun parseSocksUri(raw: String): ProxyParseResult {
        val uri = URI(raw)
        val host = uri.host ?: throw IllegalArgumentException("В socks5:// не указан сервер")
        val port = uri.port.takeIf { it in 1..65535 } ?: throw IllegalArgumentException("В socks5:// не указан корректный порт")
        val userInfo = uri.rawUserInfo?.split(':', limit = 2)
        return ProxyParseResult.Success(
            ProxyProfile(
                type = ProxyType.SOCKS5,
                server = host,
                port = port,
                username = userInfo?.getOrNull(0)?.let(::decode),
                password = userInfo?.getOrNull(1)?.let(::decode)
            )
        )
    }

    private fun build(kind: String, params: Map<String, String>): ProxyParseResult {
        val server = params["server"]?.trim().orEmpty()
        require(server.isNotBlank()) { "В ссылке отсутствует server" }
        val port = params["port"]?.toIntOrNull()?.takeIf { it in 1..65535 }
            ?: throw IllegalArgumentException("В ссылке отсутствует корректный port")
        return when (kind) {
            "socks" -> ProxyParseResult.Success(
                ProxyProfile(
                    type = ProxyType.SOCKS5,
                    server = server,
                    port = port,
                    username = params["user"],
                    password = params["pass"]
                )
            )
            "proxy" -> {
                val secret = params["secret"]?.trim()?.lowercase(Locale.ROOT)
                    ?: throw IllegalArgumentException("В ссылке MTProto отсутствует secret")
                MtProtoSecret.parse(secret)
                ProxyParseResult.Success(ProxyProfile(type = ProxyType.MTPROTO, server = server, port = port, secret = secret))
            }
            else -> ProxyParseResult.Error("Это не ссылка на SOCKS5 или MTProto")
        }
    }

    private fun parseQuery(query: String): Map<String, String> {
        if (query.isBlank()) return emptyMap()
        return query.split('&').mapNotNull { item ->
            if (item.isBlank()) return@mapNotNull null
            val index = item.indexOf('=')
            val key = decode(if (index >= 0) item.substring(0, index) else item).lowercase(Locale.ROOT)
            val value = decode(if (index >= 0) item.substring(index + 1) else "")
            key to value
        }.toMap()
    }

    private fun decode(value: String): String = URLDecoder.decode(value, StandardCharsets.UTF_8.name())
}

/** Telegram MTProxy secret formats: raw 16-byte, dd+16-byte, or ee+16-byte+SNI. */
data class MtProtoSecret(val mode: Mode, val key: ByteArray, val domain: String? = null, val encoded: String) {
    enum class Mode { BASIC, RANDOM_PADDING, FAKE_TLS }

    override fun toString(): String = "MtProtoSecret(mode=$mode, domain=$domain, secret=redacted)"

    companion object {
        fun parse(hex: String): MtProtoSecret {
            require(hex.length % 2 == 0 && hex.matches(Regex("[0-9a-fA-F]+"))) { "MTProto secret должен быть hex-строкой" }
            val bytes = hex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
            return when {
                bytes.size == 16 -> MtProtoSecret(Mode.BASIC, bytes, encoded = hex.lowercase(Locale.ROOT))
                bytes.size == 17 && (bytes[0].toInt() and 0xff) == 0xdd ->
                    MtProtoSecret(Mode.RANDOM_PADDING, bytes.copyOfRange(1, 17), encoded = hex.lowercase(Locale.ROOT))
                bytes.size >= 18 && (bytes[0].toInt() and 0xff) == 0xee -> {
                    val domain = bytes.copyOfRange(17, bytes.size).toString(StandardCharsets.UTF_8)
                    require(domain.matches(Regex("[A-Za-z0-9.-]{1,253}")) && !domain.startsWith('.') && !domain.endsWith('.')) {
                        "В MTProto FakeTLS secret указан некорректный домен"
                    }
                    MtProtoSecret(Mode.FAKE_TLS, bytes.copyOfRange(1, 17), domain, hex.lowercase(Locale.ROOT))
                }
                else -> throw IllegalArgumentException("Неподдерживаемый формат MTProto secret (нужен обычный, dd или ee)")
            }
        }
    }
}

private object URIBuilder {
    fun build(path: String, query: Map<String, String>): String {
        val params = query.entries.joinToString("&") { (key, value) ->
            "${encode(key)}=${encode(value)}"
        }
        return "tg://$path?$params"
    }

    private fun encode(value: String): String = java.net.URLEncoder.encode(value, StandardCharsets.UTF_8.name())
}
