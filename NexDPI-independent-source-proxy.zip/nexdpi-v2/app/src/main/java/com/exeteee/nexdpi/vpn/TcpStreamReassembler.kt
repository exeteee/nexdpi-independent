package com.exeteee.nexdpi.vpn

/**
 * Bounded, single-direction TCP byte-stream assembler intended for the initial TLS handshake.
 * It accepts payload segments by TCP sequence number, tolerates reordering and identical
 * retransmissions, and returns only newly contiguous bytes. It is not a complete TCP stack.
 */
class TcpStreamReassembler(
    initialSequenceNumber: Long,
    private val capacity: Int = DEFAULT_CAPACITY
) {
    private val initialSequence = validateSequence(initialSequenceNumber)
    private val windowCapacity = validateCapacity(capacity)
    private val bytes = ByteArray(windowCapacity)
    private val present = BooleanArray(windowCapacity)
    private var contiguousLength = 0
    private var deliveredLength = 0
    private var failed = false

    /**
     * @return new contiguous stream bytes; an empty array means no new contiguous data; null
     * means the segment is invalid, out of bounds, or conflicts with previously received bytes.
     */
    @Synchronized
    fun accept(sequenceNumber: Long, payload: ByteArray): ByteArray? {
        if (failed) return null
        if (sequenceNumber !in 0..SEQUENCE_MASK) return fail()
        if (payload.isEmpty()) return ByteArray(0)

        val forwardDistance = (sequenceNumber - initialSequence) and SEQUENCE_MASK
        val signedOffset = if (forwardDistance >= HALF_SEQUENCE_SPACE) {
            forwardDistance - SEQUENCE_SPACE
        } else {
            forwardDistance
        }

        val trimPrefix = if (signedOffset < 0) -signedOffset else 0L
        if (trimPrefix >= payload.size.toLong()) {
            // The whole segment is older than the start of the tracked stream.
            return ByteArray(0)
        }
        val offset = if (signedOffset < 0) 0L else signedOffset
        val effectiveLength = payload.size - trimPrefix.toInt()
        val end = offset + effectiveLength
        if (end > capacity.toLong()) return fail()

        val sourceOffset = trimPrefix.toInt()
        for (index in 0 until effectiveLength) {
            val target = offset.toInt() + index
            val incoming = payload[sourceOffset + index]
            if (present[target]) {
                if (bytes[target] != incoming) return fail()
            } else {
                bytes[target] = incoming
                present[target] = true
            }
        }

        while (contiguousLength < capacity && present[contiguousLength]) {
            contiguousLength++
        }
        if (contiguousLength <= deliveredLength) return ByteArray(0)

        val newlyContiguous = bytes.copyOfRange(deliveredLength, contiguousLength)
        deliveredLength = contiguousLength
        return newlyContiguous
    }

    @Synchronized
    fun isFailed(): Boolean = failed

    @Synchronized
    fun bufferedContiguousBytes(): Int = deliveredLength

    @Synchronized
    fun clear() {
        bytes.fill(0)
        present.fill(false)
        contiguousLength = 0
        deliveredLength = 0
        failed = false
    }

    private fun fail(): ByteArray? {
        failed = true
        bytes.fill(0)
        present.fill(false)
        contiguousLength = 0
        deliveredLength = 0
        return null
    }

    companion object {
        const val DEFAULT_CAPACITY = 65_536
        const val MAX_CAPACITY = 65_536
        private const val SEQUENCE_SPACE = 0x1_0000_0000L
        private const val HALF_SEQUENCE_SPACE = 0x8000_0000L
        private const val SEQUENCE_MASK = 0xffff_ffffL

        private fun validateCapacity(value: Int): Int {
            require(value in 1..MAX_CAPACITY) { "TCP stream buffer capacity must be 1..$MAX_CAPACITY" }
            return value
        }

        private fun validateSequence(value: Long): Long {
            require(value in 0..SEQUENCE_MASK) { "TCP sequence number must be unsigned 32-bit" }
            return value
        }
    }
}
