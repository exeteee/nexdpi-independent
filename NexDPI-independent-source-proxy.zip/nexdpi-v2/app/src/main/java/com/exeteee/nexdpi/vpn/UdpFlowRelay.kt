package com.exeteee.nexdpi.vpn

import java.io.Closeable
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketTimeoutException
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Bounded local UDP flow relay used by NexDPI's routed TUN path. Each five-tuple owns a
 * protected direct-network datagram socket; replies are rebuilt with the original app tuple
 * and injected through the supplied TUN writer.
 */
class UdpFlowRelay(
    private val protectSocket: (DatagramSocket) -> Boolean,
    private val packetWriter: (ByteArray) -> Unit,
    private val maxFlows: Int = DEFAULT_MAX_FLOWS,
    private val idleTimeoutMillis: Long = DEFAULT_IDLE_TIMEOUT_MILLIS,
    private val receiveTimeoutMillis: Int = DEFAULT_RECEIVE_TIMEOUT_MILLIS,
    private val mtu: Int = DEFAULT_MTU,
    private val socketFactory: () -> DatagramSocket = { DatagramSocket(null) },
    private val proxyAssociationFactory: ((UdpDatagram) -> com.exeteee.nexdpi.proxy.Socks5UdpAssociation)? = null,
    private val allowDirectFlows: Boolean = true
) : Closeable {
    private data class FlowKey(
        val ipVersion: Int,
        val sourceAddress: String,
        val destinationAddress: String,
        val sourcePort: Int,
        val destinationPort: Int
    )

    private interface FlowChannel : Closeable {
        fun send(payload: ByteArray)
        fun receive(): ByteArray
    }

    private class DirectUdpChannel(
        private val socket: DatagramSocket,
        private val destination: InetSocketAddress
    ) : FlowChannel {
        override fun send(payload: ByteArray) {
            socket.send(DatagramPacket(payload, payload.size, destination))
        }

        override fun receive(): ByteArray {
            val buffer = ByteArray(MAX_UDP_PAYLOAD)
            val packet = DatagramPacket(buffer, buffer.size)
            socket.receive(packet)
            return packet.data.copyOfRange(packet.offset, packet.offset + packet.length)
        }

        override fun close() = socket.close()
    }

    private class Socks5UdpChannel(
        private val association: com.exeteee.nexdpi.proxy.Socks5UdpAssociation
    ) : FlowChannel {
        override fun send(payload: ByteArray) = association.send(payload)
        override fun receive(): ByteArray = association.receive()
        override fun close() = association.close()
    }

    private class Flow(
        val key: FlowKey,
        val template: UdpDatagram,
        val channel: FlowChannel
    ) {
        val closed = AtomicBoolean(false)
        val lastActivityNanos = AtomicLong(System.nanoTime())
        val sendLock = Any()
        @Volatile var reader: Thread? = null
    }

    private val lock = Any()
    private val flows = LinkedHashMap<FlowKey, Flow>(16, 0.75f, true)
    private val closed = AtomicBoolean(false)

    init {
        require(maxFlows in 1..MAX_ALLOWED_FLOWS) { "maxFlows must be 1..$MAX_ALLOWED_FLOWS" }
        require(idleTimeoutMillis in 1_000..MAX_IDLE_TIMEOUT_MILLIS) { "Invalid UDP idle timeout" }
        require(receiveTimeoutMillis in 50..5_000) { "Invalid UDP receive timeout" }
        require(mtu in 576..65_535) { "Invalid UDP tunnel MTU" }
    }

    /**
     * Sends one parsed app datagram to its destination. A missing flow is created only when
     * capacity is available. Socket protection happens before connect/send to avoid VPN loops.
     */
    @Throws(IOException::class)
    fun send(datagram: UdpDatagram) {
        check(!closed.get()) { "UDP relay is closed" }
        require(datagram.ipVersion == 4 && datagram.sourceAddress.size == 4 && datagram.destinationAddress.size == 4 ||
            datagram.ipVersion == 6 && datagram.sourceAddress.size == 16 && datagram.destinationAddress.size == 16) {
            "Invalid UDP address family"
        }
        require(datagram.sourcePort in 0..65_535 && datagram.destinationPort in 1..65_535) {
            "Invalid UDP port"
        }

        val key = datagram.toKey()
        val flow = synchronized(lock) {
            check(!closed.get()) { "UDP relay is closed" }
            pruneExpiredLocked()
            flows[key] ?: createFlowLocked(key, datagram)
        }

        try {
            synchronized(flow.sendLock) {
                if (flow.closed.get()) throw IOException("UDP flow has already closed")
                flow.channel.send(datagram.payload)
                flow.lastActivityNanos.set(System.nanoTime())
            }
        } catch (error: Exception) {
            removeFlow(flow)
            if (error is IOException) throw error
            throw IOException("UDP send failed", error)
        }
    }

    fun activeFlowCount(): Int = synchronized(lock) { flows.size }

    private fun createFlowLocked(key: FlowKey, datagram: UdpDatagram): Flow {
        if (flows.size >= maxFlows) throw IOException("UDP flow limit reached")
        val channel = if (proxyAssociationFactory != null) {
            Socks5UdpChannel(proxyAssociationFactory.invoke(datagram))
        } else {
            if (!allowDirectFlows) throw IOException("Выбранный прокси не поддерживает UDP; пакет не отправлен напрямую")
            val socket = try {
                socketFactory()
            } catch (error: Exception) {
                throw IOException("Unable to create UDP socket", error)
            }
            try {
                if (!protectSocket(socket)) throw IOException("Unable to protect UDP socket from VPN loop")
                socket.soTimeout = receiveTimeoutMillis
                val destination = InetAddress.getByAddress(datagram.destinationAddress)
                socket.connect(InetSocketAddress(destination, datagram.destinationPort))
                DirectUdpChannel(socket, InetSocketAddress(destination, datagram.destinationPort))
            } catch (error: Exception) {
                try { socket.close() } catch (_: Exception) { }
                if (error is IOException) throw error
                throw IOException("Unable to open UDP flow", error)
            }
        }
        val flow = Flow(key, datagram.copyDeep(), channel)
        flows[key] = flow
        flow.reader = Thread({ receiveLoop(flow) }, "NexDPI-UDP-relay").apply {
            isDaemon = true
            start()
        }
        return flow
    }

    private fun receiveLoop(flow: Flow) {
        try {
            while (!closed.get() && !flow.closed.get()) {
                if (isIdle(flow)) break
                try {
                    val payload = flow.channel.receive()
                    flow.lastActivityNanos.set(System.nanoTime())
                    val responses = UdpPacketCodec.buildResponsePackets(flow.template, payload, mtu) ?: continue
                    responses.forEach { packet ->
                        if (!closed.get() && !flow.closed.get()) {
                            try { packetWriter(packet) } catch (_: Exception) { }
                        }
                    }
                } catch (_: SocketTimeoutException) {
                    // Periodic wake-up allows bounded idle-flow expiration.
                }
            }
        } catch (_: Exception) {
            // Network switch, socket close or underlying datagram error ends this flow only.
        } finally {
            removeFlow(flow)
        }
    }

    private fun isIdle(flow: Flow): Boolean {
        val idleNanos = System.nanoTime() - flow.lastActivityNanos.get()
        return idleNanos >= idleTimeoutMillis * NANOS_PER_MILLISECOND
    }

    private fun pruneExpiredLocked() {
        val now = System.nanoTime()
        val expired = flows.values.filter {
            now - it.lastActivityNanos.get() >= idleTimeoutMillis * NANOS_PER_MILLISECOND
        }
        expired.forEach {
            flows.remove(it.key)
            closeFlowLocked(it)
        }
    }

    private fun removeFlow(flow: Flow) {
        synchronized(lock) {
            if (flows[flow.key] === flow) flows.remove(flow.key)
            closeFlowLocked(flow)
        }
    }

    private fun closeFlowLocked(flow: Flow) {
        if (flow.closed.compareAndSet(false, true)) {
            try { flow.channel.close() } catch (_: Exception) { }
        }
    }

    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        synchronized(lock) {
            flows.values.toList().forEach(::closeFlowLocked)
            flows.clear()
        }
    }

    private fun UdpDatagram.toKey() = FlowKey(
        ipVersion = ipVersion,
        sourceAddress = sourceAddress.toHex(),
        destinationAddress = destinationAddress.toHex(),
        sourcePort = sourcePort,
        destinationPort = destinationPort
    )

    private fun UdpDatagram.copyDeep() = copy(
        sourceAddress = sourceAddress.copyOf(),
        destinationAddress = destinationAddress.copyOf(),
        payload = payload.copyOf()
    )

    private fun ByteArray.toHex(): String = joinToString(separator = "") { "%02x".format(it.toInt() and 0xff) }

    companion object {
        const val DEFAULT_MAX_FLOWS = 24
        const val MAX_ALLOWED_FLOWS = 256
        const val DEFAULT_IDLE_TIMEOUT_MILLIS = 60_000L
        const val MAX_IDLE_TIMEOUT_MILLIS = 300_000L
        const val DEFAULT_RECEIVE_TIMEOUT_MILLIS = 1_000
        const val DEFAULT_MTU = 1500
        private const val MAX_UDP_PAYLOAD = 65_535
        private const val NANOS_PER_MILLISECOND = 1_000_000L
    }
}
