package com.exeteee.nexdpi.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.content.pm.ServiceInfo
import com.exeteee.nexdpi.MainActivity
import com.exeteee.nexdpi.data.WhitelistRepository
import com.exeteee.nexdpi.proxy.ProxyProfile
import com.exeteee.nexdpi.proxy.ProxyProfileStore
import com.exeteee.nexdpi.proxy.ProxyType
import com.exeteee.nexdpi.proxy.HttpConnectClient
import com.exeteee.nexdpi.proxy.Socks5Client
import com.exeteee.nexdpi.proxy.Socks5UdpAssociation
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.RejectedExecutionHandler
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.flow.MutableStateFlow

/** Independent local TCP/UDP VPN datapath with encrypted DNS and SNI-aware TCP stream splitting. */
class NexDpiVpnService : VpnService() {
    private val running = AtomicBoolean(false)
    private val sessionGeneration = AtomicLong(0)
    private val lifecycleLock = Any()
    private val writeLock = Any()
    private var tunnel: ParcelFileDescriptor? = null
    private var readerThread: Thread? = null
    private var packetWorkers: ThreadPoolExecutor? = null
    private var transportWorker: ThreadPoolExecutor? = null
    private var udpWorker: ThreadPoolExecutor? = null
    private var tcpRelay: TcpFlowRelay? = null
    private var udpRelay: UdpFlowRelay? = null
    private val resolver = DnsOverHttpsResolver()
    private val fragmentReassembler = IpFragmentReassembler()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return when (intent?.action) {
            ACTION_STOP -> {
                stopTunnel()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf(startId)
                START_NOT_STICKY
            }
            ACTION_RESTART -> {
                stopTunnel()
                if (startTunnel()) START_STICKY else START_NOT_STICKY
            }
            else -> if (startTunnel()) START_STICKY else START_NOT_STICKY
        }
    }

    private fun startTunnel(): Boolean = synchronized(lifecycleLock) {
        if (running.get()) return@synchronized true
        lastError.value = null
        val generation = sessionGeneration.incrementAndGet()
        try {
            val proxySettings = ProxyProfileStore(applicationContext).read()
            val activeProxy = proxySettings.selected().takeIf { proxySettings.enabled }
            if (activeProxy?.type == ProxyType.MTPROTO) {
                throw IllegalStateException("MTProxy работает только внутри Telegram. Для системного трафика выбери SOCKS5 или HTTP CONNECT.")
            }
            val configureIntent = PendingIntent.getActivity(
                this,
                1,
                Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val builder = Builder()
                .setSession("NexDPI")
                .setConfigureIntent(configureIntent)
                .setMtu(VPN_MTU)
                .setBlocking(true)
                // Dedicated virtual DNS targets are also used by Android's system resolver.
                .addAddress(IPV4_CLIENT, 32)
                .addDnsServer(IPV4_DNS)
                .addRoute(IPV4_DNS, 32)
                .addAddress(IPV6_CLIENT, 128)
                .addDnsServer(IPV6_DNS)
                .addRoute(IPV6_DNS, 128)
                // TCP and UDP are relayed locally; unsupported IP protocols are fail-closed.
                .addRoute("0.0.0.0", 0)
                .addRoute("::", 0)

            // The engine's own HTTPS requests must use the underlying network.
            builder.addDisallowedApplication(packageName)
            WhitelistRepository(applicationContext).getPackages().forEach { packageName ->
                if (packageName != this.packageName) {
                    try {
                        builder.addDisallowedApplication(packageName)
                    } catch (_: android.content.pm.PackageManager.NameNotFoundException) {
                        // Ignore apps that have been uninstalled since the list was saved.
                    }
                }
            }

            val established = builder.establish()
                ?: throw IllegalStateException("Android не разрешил создать VPN-интерфейс")
            tunnel = established
            startForegroundCompat()
            running.set(true)
            isRunning.value = true
            startPacketReader(established, generation, activeProxy)
            true
        } catch (error: Exception) {
            lastError.value = error.message ?: error.javaClass.simpleName
            stopTunnelLocked()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            false
        }
    }

    private fun startPacketReader(descriptor: ParcelFileDescriptor, generation: Long, proxyProfile: ProxyProfile?) {
        val dnsWorkers = ThreadPoolExecutor(
            1,
            MAX_DNS_WORKERS,
            30,
            TimeUnit.SECONDS,
            ArrayBlockingQueue(MAX_PENDING_DNS),
            { runnable -> Thread(runnable, "NexDPI-DNS-worker").apply { isDaemon = true } },
            ThreadPoolExecutor.AbortPolicy()
        )
        packetWorkers = dnsWorkers

        // Different five-tuples may progress concurrently. TCP/UDP relays serialize each
        // individual flow internally, so a blocked socket must not stall unrelated traffic.
        val transportPool = ThreadPoolExecutor(
            TRANSPORT_CORE_WORKERS,
            TRANSPORT_MAX_WORKERS,
            30,
            TimeUnit.SECONDS,
            ArrayBlockingQueue(MAX_PENDING_TRANSPORT),
            { runnable -> Thread(runnable, "NexDPI-transport-worker").apply { isDaemon = true } },
            BlockingBackpressurePolicy()
        )
        transportWorker = transportPool
        // UDP datagrams are submitted in TUN order and sent by one worker so the
        // relay itself does not introduce avoidable reordering (e.g. for QUIC).
        val udpPool = ThreadPoolExecutor(
            UDP_WORKERS,
            UDP_WORKERS,
            30,
            TimeUnit.SECONDS,
            ArrayBlockingQueue(MAX_PENDING_UDP),
            { runnable -> Thread(runnable, "NexDPI-UDP-worker").apply { isDaemon = true } },
            ThreadPoolExecutor.AbortPolicy()
        )
        udpWorker = udpPool

        val input = FileInputStream(descriptor.fileDescriptor)
        val output = FileOutputStream(descriptor.fileDescriptor)
        val tcp = TcpFlowRelay(
            protectSocket = { socket -> protect(socket) },
            packetWriter = { packet -> writePacket(output, packet, generation) },
            mtu = VPN_MTU,
            socketConnector = { socket, address, port, timeout ->
                val profile = proxyProfile
                when (profile?.type) {
                    null -> socket.connect(java.net.InetSocketAddress(address, port), timeout)
                    ProxyType.SOCKS5 -> Socks5Client.connect(socket, requireNotNull(profile), address.address, port, timeout)
                    ProxyType.HTTP_CONNECT -> HttpConnectClient.connect(socket, requireNotNull(profile), address, port, timeout)
                    ProxyType.MTPROTO -> throw java.io.IOException("MTProxy не поддерживает общий TCP-туннель")
                }
            }
        )
        val udp = UdpFlowRelay(
            protectSocket = { socket -> protect(socket) },
            packetWriter = { packet -> writePacket(output, packet, generation) },
            mtu = VPN_MTU,
            proxyAssociationFactory = proxyProfile?.takeIf { it.type == ProxyType.SOCKS5 }?.let { profile ->
                { datagram ->
                    Socks5UdpAssociation(
                        profile = profile,
                        destinationAddress = datagram.destinationAddress.copyOf(),
                        destinationPort = datagram.destinationPort,
                        protectTcp = { socket -> protect(socket) },
                        protectUdp = { socket -> protect(socket) }
                    )
                }
            },
            allowDirectFlows = proxyProfile == null
        )
        tcpRelay = tcp
        udpRelay = udp

        val dispatcher = NexDpiPacketDispatcher(
            onDns = { query ->
                try {
                    dnsWorkers.execute { processDnsQuery(query, output, generation) }
                } catch (_: java.util.concurrent.RejectedExecutionException) {
                    // Session is shutting down; the query is intentionally discarded.
                }
            },
            onUdp = { datagram ->
                try {
                    udpPool.execute {
                        try {
                            udp.send(datagram)
                        } catch (_: Exception) {
                            // A failed UDP flow is isolated; it must not stop unrelated traffic.
                        }
                    }
                } catch (_: java.util.concurrent.RejectedExecutionException) {
                    // Drop the newest datagram on sustained overload rather than blocking TCP.
                }
            },
            onTcp = { packet ->
                transportPool.execute { tcp.handlePacket(packet) }
            },
            onTcpDns = { reset -> writePacket(output, reset, generation) }
        )

        readerThread = Thread({
            val packetBuffer = ByteArray(READ_BUFFER_SIZE)
            try {
                while (running.get()) {
                    val size = input.read(packetBuffer)
                    if (size < 0) break
                    if (size == 0) continue
                    if (!running.get() || sessionGeneration.get() != generation) break
                    val packet = packetBuffer.copyOf(size)
                    val completePacket = fragmentReassembler.accept(packet) ?: continue
                    // Classification is sequential. UDP is queued in arrival order; only TCP
                    // handling is parallelized because its stream reassembler handles reordering.
                    dispatcher.dispatch(completePacket)
                }
            } catch (error: Exception) {
                if (running.get()) lastError.value = error.message ?: "Ошибка чтения VPN-интерфейса"
            } finally {
                synchronized(lifecycleLock) {
                    if (running.get() && sessionGeneration.get() == generation) {
                        stopTunnelLocked()
                        stopForeground(STOP_FOREGROUND_REMOVE)
                        stopSelf()
                    }
                }
            }
        }, "NexDPI-TUN-reader").apply {
            isDaemon = true
            start()
        }
    }

    private fun writePacket(output: FileOutputStream, packet: ByteArray, generation: Long) {
        try {
            synchronized(writeLock) {
                if (running.get() && sessionGeneration.get() == generation) output.write(packet)
            }
        } catch (_: Exception) {
            // Service shutdown or revoked VPN permission.
        }
    }

    private fun processDnsQuery(query: DnsUdpQuery, output: FileOutputStream, generation: Long) {
        val dnsResponse = try {
            resolver.resolve(query.dnsMessage)
        } catch (_: Exception) {
            DnsPacketCodec.servfail(query.dnsMessage)
        } ?: return
        val responsePackets = DnsPacketCodec.buildResponsePackets(query, dnsResponse, VPN_MTU) ?: return
        responsePackets.forEach { writePacket(output, it, generation) }
    }

    private fun startForegroundCompat() {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(
                    NOTIFICATION_CHANNEL,
                    "NexDPI connection",
                    NotificationManager.IMPORTANCE_LOW
                ).apply { description = "Статус локальной обработки трафика NexDPI" }
            )
        }
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, NOTIFICATION_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("NexDPI активен")
            .setContentText("Локальная TCP/UDP-обработка и DNS через HTTPS")
            .setContentIntent(openApp)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun stopTunnel() {
        synchronized(lifecycleLock) {
            stopTunnelLocked()
        }
    }

    /** Must be called while holding lifecycleLock. */
    private fun stopTunnelLocked() {
        // Invalidate callbacks from the previous TUN session before closing it.
        sessionGeneration.incrementAndGet()
        running.set(false)
        isRunning.value = false
        try {
            tunnel?.close()
        } catch (_: Exception) {
        }
        tunnel = null
        readerThread?.interrupt()
        readerThread = null
        packetWorkers?.shutdownNow()
        packetWorkers = null
        transportWorker?.shutdownNow()
        transportWorker = null
        udpWorker?.shutdownNow()
        udpWorker = null
        tcpRelay?.close()
        tcpRelay = null
        udpRelay?.close()
        udpRelay = null
        fragmentReassembler.clear()
    }

    override fun onRevoke() {
        stopTunnel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopTunnel()
        super.onDestroy()
    }

    private class BlockingBackpressurePolicy : RejectedExecutionHandler {
        override fun rejectedExecution(task: Runnable, executor: ThreadPoolExecutor) {
            if (executor.isShutdown) return
            try {
                executor.queue.put(task)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
            }
        }
    }

    companion object {
        const val ACTION_START = "com.exeteee.nexdpi.vpn.START"
        const val ACTION_STOP = "com.exeteee.nexdpi.vpn.STOP"
        const val ACTION_RESTART = "com.exeteee.nexdpi.vpn.RESTART"

        val isRunning = MutableStateFlow(false)
        val lastError = MutableStateFlow<String?>(null)

        private const val VPN_MTU = 1500
        private const val IPV4_CLIENT = "10.77.0.2"
        private const val IPV4_DNS = "10.77.0.1"
        private const val IPV6_CLIENT = "fd77:77::2"
        private const val IPV6_DNS = "fd77:77::1"
        private const val NOTIFICATION_CHANNEL = "nexdpi_vpn_status"
        private const val NOTIFICATION_ID = 7701
        private const val READ_BUFFER_SIZE = 32_768
        private const val MAX_DNS_WORKERS = 3
        private const val MAX_PENDING_DNS = 32
        private const val TRANSPORT_CORE_WORKERS = 4
        private const val TRANSPORT_MAX_WORKERS = 4
        private const val MAX_PENDING_TRANSPORT = 512
        private const val UDP_WORKERS = 1
        private const val MAX_PENDING_UDP = 512
    }
}
