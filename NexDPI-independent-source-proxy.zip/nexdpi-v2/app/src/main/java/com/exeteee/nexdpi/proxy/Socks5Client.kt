package com.exeteee.nexdpi.proxy

import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.charset.StandardCharsets

/** RFC 1928/1929 SOCKS5 handshake for an already VPN-protected TCP socket. */
object Socks5Client {
    fun connect(
        socket: Socket,
        profile: ProxyProfile,
        targetAddress: ByteArray,
        targetPort: Int,
        timeoutMillis: Int
    ) {
        require(profile.type == ProxyType.SOCKS5)
        require(targetPort in 1..65535)
        require(targetAddress.size == 4 || targetAddress.size == 16)
        val proxyAddress = InetAddress.getByName(profile.server)
        socket.connect(InetSocketAddress(proxyAddress, profile.port), timeoutMillis)
        socket.soTimeout = timeoutMillis

        val hasCredentials = !profile.username.isNullOrEmpty() || !profile.password.isNullOrEmpty()
        val methods = if (hasCredentials) byteArrayOf(0x00, 0x02) else byteArrayOf(0x00)
        socket.getOutputStream().apply {
            write(byteArrayOf(0x05, methods.size.toByte()) + methods)
            flush()
        }
        val methodReply = readFully(socket.getInputStream(), 2)
        if (methodReply[0].toInt() != 5) throw IOException("SOCKS5: неверная версия ответа")
        when (methodReply[1].toInt() and 0xff) {
            0x00 -> Unit
            0x02 -> authenticate(socket, profile)
            0xff -> throw IOException("SOCKS5: сервер отклонил способы авторизации")
            else -> throw IOException("SOCKS5: сервер запросил неподдерживаемую авторизацию")
        }

        val addressType = if (targetAddress.size == 4) 0x01 else 0x04
        val request = byteArrayOf(0x05, 0x01, 0x00, addressType.toByte()) + targetAddress +
            byteArrayOf((targetPort ushr 8).toByte(), targetPort.toByte())
        socket.getOutputStream().apply { write(request); flush() }
        val input = socket.getInputStream()
        val head = readFully(input, 4)
        if ((head[0].toInt() and 0xff) != 5) throw IOException("SOCKS5: неверный ответ CONNECT")
        val status = head[1].toInt() and 0xff
        if (status != 0) throw IOException("SOCKS5: CONNECT отклонён (код $status)")
        consumeAddress(input, head[3].toInt() and 0xff)
        readFully(input, 2) // BND.PORT
        socket.soTimeout = 0
    }

    internal fun authenticate(socket: Socket, profile: ProxyProfile) {
        val username = profile.username.orEmpty().toByteArray(StandardCharsets.UTF_8)
        val password = profile.password.orEmpty().toByteArray(StandardCharsets.UTF_8)
        if (username.isEmpty() || username.size > 255 || password.size > 255) {
            throw IOException("SOCKS5: для авторизации нужны корректные логин и пароль")
        }
        socket.getOutputStream().apply {
            write(byteArrayOf(0x01, username.size.toByte()) + username + byteArrayOf(password.size.toByte()) + password)
            flush()
        }
        val reply = readFully(socket.getInputStream(), 2)
        if (reply[0].toInt() != 1 || reply[1].toInt() != 0) {
            throw IOException("SOCKS5: неверный логин или пароль")
        }
    }

    internal fun readFully(input: InputStream, length: Int): ByteArray {
        val result = ByteArray(length)
        var offset = 0
        while (offset < length) {
            val count = input.read(result, offset, length - offset)
            if (count < 0) throw EOFException("SOCKS5: соединение закрыто во время рукопожатия")
            if (count == 0) continue
            offset += count
        }
        return result
    }

    internal fun consumeAddress(input: InputStream, addressType: Int): ByteArray {
        return when (addressType) {
            0x01 -> readFully(input, 4)
            0x04 -> readFully(input, 16)
            0x03 -> {
                val length = readFully(input, 1)[0].toInt() and 0xff
                readFully(input, length)
            }
            else -> throw IOException("SOCKS5: неизвестный тип адреса $addressType")
        }
    }
}

/** One RFC 1928 UDP association with its TCP control connection kept alive. */
class Socks5UdpAssociation(
    private val profile: ProxyProfile,
    private val destinationAddress: ByteArray,
    private val destinationPort: Int,
    private val protectTcp: (Socket) -> Boolean,
    private val protectUdp: (DatagramSocket) -> Boolean,
    private val udpSocketFactory: () -> DatagramSocket = { DatagramSocket(null) },
    private val timeoutMillis: Int = 5_000
) : AutoCloseable {
    private val control = Socket()
    private val udp = udpSocketFactory()
    private val relayAddress: InetAddress
    private val relayPort: Int

    init {
        require(profile.type == ProxyType.SOCKS5)
        try {
            if (!protectTcp(control)) throw IOException("Не удалось исключить SOCKS5 control socket из VPN")
            control.connect(InetSocketAddress(InetAddress.getByName(profile.server), profile.port), timeoutMillis)
            control.soTimeout = timeoutMillis
            val hasCredentials = !profile.username.isNullOrEmpty() || !profile.password.isNullOrEmpty()
            val methods = if (hasCredentials) byteArrayOf(0x00, 0x02) else byteArrayOf(0x00)
            control.getOutputStream().apply { write(byteArrayOf(0x05, methods.size.toByte()) + methods); flush() }
            val selected = Socks5Client.readFully(control.getInputStream(), 2)
            if ((selected[0].toInt() and 0xff) != 5) throw IOException("SOCKS5: ошибка авторизации UDP")
            when (selected[1].toInt() and 0xff) {
                0x00 -> Unit
                0x02 -> Socks5Client.authenticate(control, profile)
                else -> throw IOException("SOCKS5: UDP ASSOCIATE требует неподдерживаемую авторизацию")
            }

            val request = byteArrayOf(0x05, 0x03, 0x00, 0x01, 0, 0, 0, 0, 0, 0)
            control.getOutputStream().apply { write(request); flush() }
            val input = control.getInputStream()
            val response = Socks5Client.readFully(input, 4)
            if ((response[0].toInt() and 0xff) != 5 || (response[1].toInt() and 0xff) != 0) {
                throw IOException("SOCKS5: UDP ASSOCIATE не поддерживается сервером")
            }
            val boundAddressBytes = Socks5Client.consumeAddress(input, response[3].toInt() and 0xff)
            val boundPortBytes = Socks5Client.readFully(input, 2)
            val parsedAddress = when (response[3].toInt() and 0xff) {
                0x01, 0x04 -> InetAddress.getByAddress(boundAddressBytes)
                0x03 -> InetAddress.getByName(boundAddressBytes.toString(StandardCharsets.US_ASCII))
                else -> throw IOException("SOCKS5: некорректный UDP relay address")
            }
            relayAddress = if (parsedAddress.isAnyLocalAddress) InetAddress.getByName(profile.server) else parsedAddress
            relayPort = ((boundPortBytes[0].toInt() and 0xff) shl 8) or (boundPortBytes[1].toInt() and 0xff)
            if (relayPort == 0) throw IOException("SOCKS5: сервер вернул нулевой UDP relay port")

            if (!protectUdp(udp)) throw IOException("Не удалось исключить SOCKS5 UDP socket из VPN")
            udp.soTimeout = timeoutMillis
            control.soTimeout = 0 // Keep the association alive until this channel is closed.
        } catch (error: Exception) {
            try { udp.close() } catch (_: Exception) { }
            try { control.close() } catch (_: Exception) { }
            if (error is IOException) throw error
            throw IOException("Не удалось создать SOCKS5 UDP association", error)
        }
    }

    @Synchronized
    fun send(payload: ByteArray) {
        val atyp = when (destinationAddress.size) { 4 -> 1; 16 -> 4; else -> throw IOException("Некорректный адрес назначения") }
        val header = byteArrayOf(0, 0, 0, atyp.toByte()) + destinationAddress +
            byteArrayOf((destinationPort ushr 8).toByte(), destinationPort.toByte())
        val packet = header + payload
        udp.send(DatagramPacket(packet, packet.size, relayAddress, relayPort))
    }

    @Synchronized
    fun receive(): ByteArray {
        val buffer = ByteArray(MAX_UDP_PACKET)
        val packet = DatagramPacket(buffer, buffer.size)
        udp.receive(packet)
        if (packet.address != relayAddress || packet.port != relayPort) {
            throw IOException("SOCKS5 UDP: пакет пришёл не от согласованного relay")
        }
        if (packet.length < 4) throw IOException("SOCKS5 UDP: короткий ответ")
        val data = packet.data
        val start = packet.offset
        val end = start + packet.length
        if (data[start].toInt() != 0 || data[start + 1].toInt() != 0) throw IOException("SOCKS5 UDP: неверный RSV")
        if (data[start + 2].toInt() != 0) throw IOException("SOCKS5 UDP: фрагментация не поддерживается")
        val atyp = data[start + 3].toInt() and 0xff
        var cursor = start + 4
        val source = when (atyp) {
            0x01 -> {
                if (cursor + 4 > end) throw IOException("SOCKS5 UDP: обрезанный IPv4 адрес")
                data.copyOfRange(cursor, cursor + 4).also { cursor += 4 }
            }
            0x04 -> {
                if (cursor + 16 > end) throw IOException("SOCKS5 UDP: обрезанный IPv6 адрес")
                data.copyOfRange(cursor, cursor + 16).also { cursor += 16 }
            }
            0x03 -> {
                if (cursor + 1 > end) throw IOException("SOCKS5 UDP: отсутствует длина домена")
                val length = data[cursor++].toInt() and 0xff
                if (length == 0 || cursor + length > end) throw IOException("SOCKS5 UDP: обрезанный домен")
                val host = data.copyOfRange(cursor, cursor + length).toString(StandardCharsets.US_ASCII)
                cursor += length
                InetAddress.getByName(host).address
            }
            else -> throw IOException("SOCKS5 UDP: неизвестный ATYP")
        }
        if (cursor + 2 > end) throw IOException("SOCKS5 UDP: нет порта источника")
        val sourcePort = ((data[cursor].toInt() and 0xff) shl 8) or (data[cursor + 1].toInt() and 0xff)
        cursor += 2
        if (!source.contentEquals(destinationAddress) || sourcePort != destinationPort) {
            throw IOException("SOCKS5 UDP: ответ не соответствует исходному адресу")
        }
        return data.copyOfRange(cursor, end)
    }

    override fun close() {
        try { udp.close() } finally { control.close() }
    }

    companion object { private const val MAX_UDP_PACKET = 65_535 }
}
