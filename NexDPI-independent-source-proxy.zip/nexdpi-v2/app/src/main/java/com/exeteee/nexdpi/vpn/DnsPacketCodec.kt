package com.exeteee.nexdpi.vpn

import java.util.concurrent.atomic.AtomicInteger

/** A DNS/UDP request received on the virtual DNS address of the local VPN. */
data class DnsUdpQuery(
    val ipVersion: Int,
    val sourceAddress: ByteArray,
    val destinationAddress: ByteArray,
    val sourcePort: Int,
    val dnsMessage: ByteArray
)

/**
 * DNS-specific IPv4/IPv6 + UDP parser and response encoder used by the wider local datapath.
 * Non-DNS packets, TCP DNS, and fragmented input packets are reassembled by IpFragmentReassembler before parsing.
 * Large DNS replies are fragmented to the TUN MTU before they are injected back.
 */
object DnsPacketCodec {
    private const val UDP_PROTOCOL = 17
    private const val DNS_PORT = 53
    private const val MAX_DNS_MESSAGE = 65_000
    private const val DEFAULT_MTU = 1500
    private const val MAX_DNS_COMPRESSION_JUMPS = 16
    private const val MAX_DNS_NAME_WIRE_LENGTH = 255
    // Fragment IDs must not repeat for concurrent DNS responses with the same transaction ID.
    private val nextIpv4Identification = AtomicInteger(1)
    private val nextIpv6Identification = AtomicInteger(1)

    fun parseQuery(packet: ByteArray, length: Int = packet.size): DnsUdpQuery? {
        if (length < 1 || length > packet.size) return null
        return when ((packet[0].toInt() ushr 4) and 0x0f) {
            4 -> parseIpv4(packet, length)
            6 -> parseIpv6(packet, length)
            else -> null
        }
    }

    private fun parseIpv4(packet: ByteArray, length: Int): DnsUdpQuery? {
        if (length < 28) return null
        val headerLength = (packet[0].toInt() and 0x0f) * 4
        if (headerLength < 20 || length < headerLength + 8) return null
        val totalLength = u16(packet, 2)
        if (totalLength < headerLength + 8 || totalLength > length) return null
        if ((packet[9].toInt() and 0xff) != UDP_PROTOCOL) return null

        // Do not parse a partial DNS datagram before the shared IP fragment reassembler completes it.
        val fragmentField = u16(packet, 6)
        if ((fragmentField and 0x3fff) != 0) return null

        val udpOffset = headerLength
        val sourcePort = u16(packet, udpOffset)
        val destinationPort = u16(packet, udpOffset + 2)
        val udpLength = u16(packet, udpOffset + 4)
        if (destinationPort != DNS_PORT || udpLength < 20 || udpLength > totalLength - udpOffset) {
            return null
        }
        val dnsLength = udpLength - 8
        if (dnsLength !in 12..MAX_DNS_MESSAGE) return null
        val dnsOffset = udpOffset + 8
        val dns = packet.copyOfRange(dnsOffset, dnsOffset + dnsLength)
        if (!isDnsQuery(dns)) return null

        return DnsUdpQuery(
            ipVersion = 4,
            sourceAddress = packet.copyOfRange(12, 16),
            destinationAddress = packet.copyOfRange(16, 20),
            sourcePort = sourcePort,
            dnsMessage = dns
        )
    }

    private fun parseIpv6(packet: ByteArray, length: Int): DnsUdpQuery? {
        if (length < 48) return null
        val payloadLength = u16(packet, 4)
        val totalLength = 40 + payloadLength
        if (payloadLength < 8 || totalLength > length) return null

        var nextHeader = packet[6].toInt() and 0xff
        var offset = 40
        // Walk the common variable-length IPv6 extension headers.
        while (nextHeader != UDP_PROTOCOL) {
            if (offset + 2 > totalLength) return null
            val following = packet[offset].toInt() and 0xff
            when (nextHeader) {
                0, 43, 60 -> {
                    val extensionLength = ((packet[offset + 1].toInt() and 0xff) + 1) * 8
                    if (extensionLength < 8 || offset + extensionLength > totalLength) return null
                    nextHeader = following
                    offset += extensionLength
                }
                44 -> {
                    if (offset + 8 > totalLength) return null
                    val fragmentField = u16(packet, offset + 2)
                    // Non-zero offset or M bit means this is a fragment.
                    if ((fragmentField and 0xfff9) != 0) return null
                    nextHeader = following
                    offset += 8
                }
                else -> return null
            }
        }

        if (offset + 8 > totalLength) return null
        val sourcePort = u16(packet, offset)
        val destinationPort = u16(packet, offset + 2)
        val udpLength = u16(packet, offset + 4)
        if (destinationPort != DNS_PORT || udpLength < 20 || offset + udpLength > totalLength) {
            return null
        }
        val dnsLength = udpLength - 8
        if (dnsLength !in 12..MAX_DNS_MESSAGE) return null
        val dns = packet.copyOfRange(offset + 8, offset + 8 + dnsLength)
        if (!isDnsQuery(dns)) return null

        return DnsUdpQuery(
            ipVersion = 6,
            sourceAddress = packet.copyOfRange(8, 24),
            destinationAddress = packet.copyOfRange(24, 40),
            sourcePort = sourcePort,
            dnsMessage = dns
        )
    }

    /** Validates the upstream DNS response against the query before it is sent to Android. */
    fun isValidDnsResponse(query: ByteArray, response: ByteArray): Boolean {
        if (!isDnsQuery(query) || response.size !in 12..MAX_DNS_MESSAGE) return false
        if (response[0] != query[0] || response[1] != query[1]) return false
        val queryFlags = u16(query, 2)
        val responseFlags = u16(response, 2)
        if ((responseFlags and 0x8000) == 0) return false // QR must indicate a response.
        if ((responseFlags and 0x7800) != (queryFlags and 0x7800)) return false // Opcode.
        if ((responseFlags and 0x0200) != 0) return false // No truncated UDP response.
        val questionCount = u16(query, 4)
        if (questionCount != u16(response, 4)) return false
        val queryQuestions = parseQuestions(query, questionCount) ?: return false
        val responseQuestions = parseQuestions(response, questionCount) ?: return false
        return queryQuestions == responseQuestions
    }

    private data class DnsQuestion(val name: List<Int>, val type: Int, val recordClass: Int)
    private data class DecodedName(val labels: List<Int>, val nextOffset: Int)

    /** Decode DNS names including bounded compression pointers and normalize ASCII case. */
    private fun parseQuestions(message: ByteArray, count: Int): List<DnsQuestion>? {
        if (count !in 1..64) return null
        val questions = ArrayList<DnsQuestion>(count)
        var offset = 12
        repeat(count) {
            val decoded = decodeName(message, offset) ?: return null
            offset = decoded.nextOffset
            if (offset + 4 > message.size) return null
            val type = u16(message, offset)
            val recordClass = u16(message, offset + 2)
            offset += 4
            questions += DnsQuestion(decoded.labels, type, recordClass)
        }
        return questions
    }

    private fun decodeName(message: ByteArray, start: Int): DecodedName? {
        if (start !in 12 until message.size) return null
        val labels = ArrayList<Int>()
        val visitedPointers = HashSet<Int>()
        var cursor = start
        var nextOffset = -1
        var jumps = 0
        var expandedLength = 1

        while (true) {
            if (cursor !in message.indices) return null
            val length = message[cursor].toInt() and 0xff
            when {
                length == 0 -> {
                    if (nextOffset < 0) nextOffset = cursor + 1
                    return DecodedName(labels, nextOffset)
                }
                (length and 0xc0) == 0xc0 -> {
                    if (cursor + 1 >= message.size) return null
                    val pointer = ((length and 0x3f) shl 8) or (message[cursor + 1].toInt() and 0xff)
                    if (pointer !in 12 until message.size || !visitedPointers.add(pointer)) return null
                    jumps++
                    if (jumps > MAX_DNS_COMPRESSION_JUMPS) return null
                    if (nextOffset < 0) nextOffset = cursor + 2
                    cursor = pointer
                }
                (length and 0xc0) != 0 -> return null
                else -> {
                    if (length > 63 || cursor + 1 + length > message.size) return null
                    expandedLength += length + 1
                    if (expandedLength > MAX_DNS_NAME_WIRE_LENGTH) return null
                    labels += length
                    for (index in cursor + 1 until cursor + 1 + length) {
                        val value = message[index].toInt() and 0xff
                        labels += if (value in 0x41..0x5a) value + 0x20 else value
                    }
                    cursor += length + 1
                }
            }
        }
    }

    private fun isDnsQuery(message: ByteArray): Boolean {
        if (message.size < 12) return false
        val flags = u16(message, 2)
        val questionCount = u16(message, 4)
        return (flags and 0x8000) == 0 && questionCount in 1..64
    }

    /**
     * Convenience method for tests and small replies that fit in one IP packet.
     * A fragmented response is available through [buildResponsePackets].
     */
    fun buildResponse(query: DnsUdpQuery, dnsResponse: ByteArray): ByteArray? =
        buildResponsePackets(query, dnsResponse)?.singleOrNull()

    fun buildResponsePackets(
        query: DnsUdpQuery,
        dnsResponse: ByteArray,
        mtu: Int = DEFAULT_MTU
    ): List<ByteArray>? {
        if (dnsResponse.size !in 12..MAX_DNS_MESSAGE || mtu < 576) return null
        return when (query.ipVersion) {
            4 -> buildIpv4Responses(query, dnsResponse, mtu)
            6 -> buildIpv6Responses(query, dnsResponse, mtu)
            else -> null
        }
    }

    private fun buildIpv4Responses(
        query: DnsUdpQuery,
        dns: ByteArray,
        mtu: Int
    ): List<ByteArray>? {
        if (query.sourceAddress.size != 4 || query.destinationAddress.size != 4) return null
        val udpLength = 8 + dns.size
        val fullLength = 20 + udpLength
        if (fullLength > 65_535) return null

        val fullPacket = ByteArray(fullLength)
        fullPacket[0] = 0x45
        put16(fullPacket, 2, fullLength)
        val identification = nextIpv4Identification.getAndIncrement() and 0xffff
        put16(fullPacket, 4, identification)
        fullPacket[8] = 64
        fullPacket[9] = UDP_PROTOCOL.toByte()
        query.destinationAddress.copyInto(fullPacket, 12)
        query.sourceAddress.copyInto(fullPacket, 16)
        put16(fullPacket, 20, DNS_PORT)
        put16(fullPacket, 22, query.sourcePort)
        put16(fullPacket, 24, udpLength)
        dns.copyInto(fullPacket, 28)
        val udpChecksum = udpChecksumV4(fullPacket, 20, udpLength)
        put16(fullPacket, 26, if (udpChecksum == 0) 0xffff else udpChecksum)

        if (fullLength <= mtu) {
            put16(fullPacket, 10, checksum(fullPacket, 0, 20))
            return listOf(fullPacket)
        }

        val fragmentPayloadSize = ((mtu - 20) / 8) * 8
        if (fragmentPayloadSize < 8) return null
        val udpSegment = fullPacket.copyOfRange(20, fullLength)
        val packets = ArrayList<ByteArray>()
        var fragmentOffset = 0
        while (fragmentOffset < udpSegment.size) {
            val chunkSize = minOf(fragmentPayloadSize, udpSegment.size - fragmentOffset)
            val moreFragments = fragmentOffset + chunkSize < udpSegment.size
            val fragment = ByteArray(20 + chunkSize)
            fragment[0] = 0x45
            put16(fragment, 2, fragment.size)
            put16(fragment, 4, identification)
            val offsetAndFlags = (fragmentOffset / 8) or if (moreFragments) 0x2000 else 0
            put16(fragment, 6, offsetAndFlags)
            fragment[8] = 64
            fragment[9] = UDP_PROTOCOL.toByte()
            query.destinationAddress.copyInto(fragment, 12)
            query.sourceAddress.copyInto(fragment, 16)
            udpSegment.copyInto(fragment, 20, fragmentOffset, fragmentOffset + chunkSize)
            put16(fragment, 10, checksum(fragment, 0, 20))
            packets.add(fragment)
            fragmentOffset += chunkSize
        }
        return packets
    }

    private fun buildIpv6Responses(
        query: DnsUdpQuery,
        dns: ByteArray,
        mtu: Int
    ): List<ByteArray>? {
        if (query.sourceAddress.size != 16 || query.destinationAddress.size != 16) return null
        val udpLength = 8 + dns.size
        if (udpLength > 65_527) return null

        val fullPacket = ByteArray(40 + udpLength)
        fullPacket[0] = 0x60
        put16(fullPacket, 4, udpLength)
        fullPacket[6] = UDP_PROTOCOL.toByte()
        fullPacket[7] = 64
        query.destinationAddress.copyInto(fullPacket, 8)
        query.sourceAddress.copyInto(fullPacket, 24)
        put16(fullPacket, 40, DNS_PORT)
        put16(fullPacket, 42, query.sourcePort)
        put16(fullPacket, 44, udpLength)
        dns.copyInto(fullPacket, 48)
        val udpChecksum = udpChecksumV6(fullPacket, 40, udpLength)
        put16(fullPacket, 46, if (udpChecksum == 0) 0xffff else udpChecksum)

        if (fullPacket.size <= mtu) return listOf(fullPacket)

        // IPv6 routers do not fragment packets; the source must add a Fragment header.
        val fragmentPayloadSize = ((mtu - 48) / 8) * 8
        if (fragmentPayloadSize < 8) return null
        val udpSegment = fullPacket.copyOfRange(40, fullPacket.size)
        val fragmentId = nextIpv6Identification.getAndIncrement()
        val packets = ArrayList<ByteArray>()
        var fragmentOffset = 0
        while (fragmentOffset < udpSegment.size) {
            val chunkSize = minOf(fragmentPayloadSize, udpSegment.size - fragmentOffset)
            val moreFragments = fragmentOffset + chunkSize < udpSegment.size
            val fragment = ByteArray(48 + chunkSize)
            fragment[0] = 0x60
            put16(fragment, 4, 8 + chunkSize)
            fragment[6] = 44 // Fragment extension header.
            fragment[7] = 64
            query.destinationAddress.copyInto(fragment, 8)
            query.sourceAddress.copyInto(fragment, 24)
            fragment[40] = UDP_PROTOCOL.toByte()
            fragment[41] = 0
            val offsetAndFlags = ((fragmentOffset / 8) shl 3) or if (moreFragments) 1 else 0
            put16(fragment, 42, offsetAndFlags)
            put32(fragment, 44, fragmentId)
            udpSegment.copyInto(fragment, 48, fragmentOffset, fragmentOffset + chunkSize)
            packets.add(fragment)
            fragmentOffset += chunkSize
        }
        return packets
    }

    /** Creates a DNS SERVFAIL response while preserving the original question. */
    fun servfail(query: ByteArray): ByteArray? {
        if (!isDnsQuery(query)) return null
        val response = query.copyOf()
        val oldFlags = u16(response, 2)
        val flags = (oldFlags and 0x0100) or 0x8082 // QR + RA + SERVFAIL; preserve RD.
        put16(response, 2, flags)
        put16(response, 6, 0)
        put16(response, 8, 0)
        put16(response, 10, 0)
        return response
    }

    private fun dnsTransactionId(dns: ByteArray): Int = u16(dns, 0)

    private fun udpChecksumV4(packet: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        sum = addWords(sum, packet, 12, 8)
        sum += UDP_PROTOCOL.toLong()
        sum += length.toLong()
        sum = addWords(sum, packet, offset, length)
        return finishChecksum(sum)
    }

    private fun udpChecksumV6(packet: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        sum = addWords(sum, packet, 8, 32)
        sum += ((length ushr 16) and 0xffff).toLong()
        sum += (length and 0xffff).toLong()
        sum += UDP_PROTOCOL.toLong()
        sum = addWords(sum, packet, offset, length)
        return finishChecksum(sum)
    }

    private fun checksum(bytes: ByteArray, offset: Int, length: Int): Int =
        finishChecksum(addWords(0L, bytes, offset, length))

    private fun addWords(initial: Long, bytes: ByteArray, offset: Int, length: Int): Long {
        var sum = initial
        var index = offset
        val end = offset + length
        while (index + 1 < end) {
            sum += (((bytes[index].toInt() and 0xff) shl 8) or
                (bytes[index + 1].toInt() and 0xff)).toLong()
            index += 2
        }
        if (index < end) sum += ((bytes[index].toInt() and 0xff) shl 8).toLong()
        return sum
    }

    private fun finishChecksum(value: Long): Int {
        var sum = value
        while ((sum ushr 16) != 0L) sum = (sum and 0xffff) + (sum ushr 16)
        return sum.inv().toInt() and 0xffff
    }

    private fun u16(bytes: ByteArray, offset: Int): Int =
        ((bytes[offset].toInt() and 0xff) shl 8) or (bytes[offset + 1].toInt() and 0xff)

    private fun put16(bytes: ByteArray, offset: Int, value: Int) {
        bytes[offset] = (value ushr 8).toByte()
        bytes[offset + 1] = value.toByte()
    }

    private fun put32(bytes: ByteArray, offset: Int, value: Int) {
        bytes[offset] = (value ushr 24).toByte()
        bytes[offset + 1] = (value ushr 16).toByte()
        bytes[offset + 2] = (value ushr 8).toByte()
        bytes[offset + 3] = value.toByte()
    }
}
