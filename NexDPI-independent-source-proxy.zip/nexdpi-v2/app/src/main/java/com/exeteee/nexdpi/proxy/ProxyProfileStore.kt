package com.exeteee.nexdpi.proxy

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Stores proxy credentials as AES-GCM ciphertext; the AES key never leaves Android Keystore. */
class ProxyProfileStore(context: Context) {
    private val preferences = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun read(): ProxySettings {
        val encrypted = preferences.getString(KEY_DATA, null) ?: return ProxySettings()
        return try {
            decode(decrypt(Base64.decode(encrypted, Base64.NO_WRAP)))
        } catch (_: Exception) {
            // Do not silently use a corrupted or undecryptable proxy profile.
            ProxySettings()
        }
    }

    @Synchronized
    fun save(settings: ProxySettings) {
        preferences.edit()
            .putString(KEY_DATA, Base64.encodeToString(encrypt(encode(settings)), Base64.NO_WRAP))
            .apply()
    }

    @Synchronized
    fun upsert(profile: ProxyProfile, enable: Boolean = true) {
        val old = read()
        val profiles = (old.profiles.filterNot { it.id == profile.id } + profile).takeLast(MAX_PROFILES)
        save(old.copy(
            profiles = profiles,
            selectedId = profile.id,
            enabled = enable && profile.type != ProxyType.MTPROTO
        ))
    }

    @Synchronized
    fun select(profileId: String?, enabled: Boolean) {
        val old = read()
        val selected = profileId?.let { id -> old.profiles.firstOrNull { it.id == id } }
        require(profileId == null || selected != null)
        require(!enabled || selected?.type != ProxyType.MTPROTO) { "MTProxy нельзя включить как системный прокси" }
        save(old.copy(selectedId = profileId, enabled = enabled && selected != null))
    }

    @Synchronized
    fun remove(profileId: String) {
        val old = read()
        val profiles = old.profiles.filterNot { it.id == profileId }
        val nextId = if (old.selectedId == profileId) profiles.lastOrNull()?.id else old.selectedId
        val nextProfile = profiles.firstOrNull { it.id == nextId }
        save(old.copy(
            profiles = profiles,
            selectedId = nextId,
            enabled = old.enabled && nextProfile != null && nextProfile.type != ProxyType.MTPROTO
        ))
    }

    private fun encode(settings: ProxySettings): ByteArray {
        val root = JSONObject()
            .put("selected", settings.selectedId)
            .put("enabled", settings.enabled)
        val array = JSONArray()
        settings.profiles.forEach { profile ->
            val item = JSONObject()
                .put("id", profile.id)
                .put("type", profile.type.name)
                .put("server", profile.server)
                .put("port", profile.port)
                .put("label", profile.label)
            profile.username?.let { item.put("username", it) }
            profile.password?.let { item.put("password", it) }
            profile.secret?.let { item.put("secret", it) }
            array.put(item)
        }
        root.put("profiles", array)
        return root.toString().toByteArray(Charsets.UTF_8)
    }

    private fun decode(data: ByteArray): ProxySettings {
        val root = JSONObject(data.toString(Charsets.UTF_8))
        val array = root.optJSONArray("profiles") ?: JSONArray()
        val profiles = buildList {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                val type = runCatching { ProxyType.valueOf(item.getString("type")) }.getOrNull() ?: continue
                runCatching {
                    add(
                        ProxyProfile(
                            id = item.getString("id"),
                            type = type,
                            server = item.getString("server"),
                            port = item.getInt("port"),
                            username = item.optString("username").takeIf(String::isNotEmpty),
                            password = item.optString("password").takeIf(String::isNotEmpty),
                            secret = item.optString("secret").takeIf(String::isNotEmpty),
                            label = item.optString("label")
                        )
                    )
                }
            }
        }.takeLast(MAX_PROFILES)
        val selected = root.optString("selected").takeIf(String::isNotBlank)
            ?.takeIf { id -> profiles.any { it.id == id } }
        val selectedProfile = profiles.firstOrNull { it.id == selected }
        return ProxySettings(
            profiles,
            selected,
            root.optBoolean("enabled", false) && selectedProfile != null && selectedProfile.type != ProxyType.MTPROTO
        )
    }

    private fun encrypt(plain: ByteArray): ByteArray {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(plain)
        return cipher.iv + encrypted
    }

    private fun decrypt(blob: ByteArray): ByteArray {
        require(blob.size > GCM_IV_BYTES + GCM_TAG_BYTES) { "Invalid encrypted proxy storage" }
        val iv = blob.copyOfRange(0, GCM_IV_BYTES)
        val payload = blob.copyOfRange(GCM_IV_BYTES, blob.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(GCM_TAG_BITS, iv))
        return cipher.doFinal(payload)
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        (keyStore.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    companion object {
        private const val PREFS = "nexdpi_proxy_profiles"
        private const val KEY_DATA = "encrypted_profiles_v1"
        private const val KEY_ALIAS = "nexdpi_proxy_profiles_aes_v1"
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val GCM_IV_BYTES = 12
        private const val GCM_TAG_BITS = 128
        private const val GCM_TAG_BYTES = GCM_TAG_BITS / 8
        private const val MAX_PROFILES = 32
    }
}
