package com.exeteee.nexdpi.vpn

import java.util.LinkedHashMap
import java.util.TreeMap

/**
 * Bounded IPv4/IPv6 fragment reassembly for packets arriving from the TUN.
 * Non-fragmented packets pass through unchanged. Incomplete, overlapping,
 * oversized or expired fragment sets are discarded.
 */
class IpFragmentReassembler(
    private val maxActiveDatagrams: Int = MAX_ACTIVE_DATAGRAMS,
    private val maxBufferedBytes: Int = MAX_BUFFERED_BYTES,
    private val timeoutNanos: Long = DEFAULT_TIMEOUT_NANOS,
    private val clockNanos: () -> Long = System::nanoTime
) {
    private data class FragmentKey(
        val version: Int,
        val source: String,
        val destination: String,
        val identification: Long,
        val protocol: Int
    )

    private data class FragmentSet(
        val pieces: TreeMap<Int, ByteArray> = TreeMap(),
        var prefix: ByteArray? = null,
        var finalPayloadSize: Int? = null,
        var bufferedBytes: Int = 0,
        var updatedAt: Long
    )

    private val lock = Any()
    private val fragments = LinkedHashMap<FragmentKey, FragmentSet>()
    private var bufferedBytes = 0

    init {
        require(maxActiveDatagrams > 0)
        require(maxBufferedBytes >= 65_535)
        require(timeoutNanos > 0)
    }

    /** Drops all incomplete datagrams, for example when the VPN session is restarted. */
    fun clear() = synchronized(lock) {
        fragments.clear()
        bufferedBytes = 0
    }

    /** Returns a complete packet, the original unfragmented packet, or null while reassembly is pending. */
    fun accept(packet: ByteArray): ByteArray? {
        if (packet.isEmpty()) return null
        return when ((packet[0].toInt() ushr 4) and 0x0f) {
            4 -> acceptIpv4(packet)
            6 -> acceptIpv6(packet)
            else -> null
        }
    }

    private fun acceptIpv4(packet: ByteArray): ByteArray? {
        if (packet.size < 20) return null
        val headerLength = (packet[0].toInt() and 0x0f) * 4
        if (headerLength !in 20..60 || packet.size < headerLength) return null
        if (checksum(packet, 0, headerLength) != 0) return null
        val totalLength = u16(packet, 2)
        if (totalLength < headerLength || totalLength > packet.size) return null

        val fragmentField = u16(packet, 6)
        if ((fragmentField and 0x8000) != 0) return null // Reserved flag must be zero.
        val offsetBytes = (fragmentField and 0x1fff) * 8
        val moreFragments = (fragmentField and 0x2000) != 0
        if (offsetBytes == 0 && !moreFragments) return packet
        if ((fragmentField and 0x4000) != 0) return null // DF and fragmentation cannot coexist.

        val payload = packet.copyOfRange(headerLength, totalLength)
        if (payload.isEmpty() || (moreFragments && payload.size % 8 != 0)) return null
        if (offsetBytes + payload.size > MAX_REASSEMBLED_SIZE) return null

        val protocol = packet[9].toInt() and 0xff
        val key = FragmentKey(
            version = 4,
            source = hex(packet, 12, 4),
            destination = hex(packet, 16, 4),
            identification = u16(packet, 4).toLong(),
            protocol = protocol
        )
        val prefix = if (offsetBytes == 0) packet.copyOfRange(0, headerLength) else null
        return addFragment(key, offsetBytes, payload, moreFragments, prefix) { header, body ->
            if (header.size + body.size > 65_535) return@addFragment null
            val result = ByteArray(header.size + body.size)
            header.copyInto(result)
            body.copyInto(result, header.size)
            put16(result, 2, result.size)
            put16(result, 6, u16(result, 6) and 0x4000)
            put16(result, 10, 0)
            put16(result, 10, checksum(result, 0, header.size))
            result
        }
    }

    private fun acceptIpv6(packet: ByteArray): ByteArray? {
        if (packet.size < 40) return null
        val payloadLength = u16(packet, 4)
        if (payloadLength == 0) return null // Jumbograms are not part of this DNS datapath.
        val totalLength = 40 + payloadLength
        if (totalLength > packet.size) return null

        var nextHeader = packet[6].toInt() and 0xff
        var offset = 40
        var previousNextHeaderOffset = 6
        while (nextHeader != IPV6_FRAGMENT_HEADER) {
            if (offset + 2 > totalLength) return null
            val following = packet[offset].toInt() and 0xff
            val extensionLength = when (nextHeader) {
                IPV6_HOP_BY_HOP, IPV6_ROUTING, IPV6_DESTINATION_OPTIONS ->
                    ((packet[offset + 1].toInt() and 0xff) + 1) * 8
                IPV6_AUTHENTICATION -> ((packet[offset + 1].toInt() and 0xff) + 2) * 4
                else -> return packet // No fragment header before the unsupported/upper-layer header.
            }
            if (extensionLength < 8 || offset + extensionLength > totalLength) return null
            previousNextHeaderOffset = offset
            offset += extensionLength
            nextHeader = following
        }

        if (offset + 8 > totalLength) return null
        val followingHeader = packet[offset].toInt() and 0xff
        val fragmentField = u16(packet, offset + 2)
        if ((fragmentField and 0x0006) != 0) return null // Reserved bits must be zero.
        val offsetBytes = fragmentField and 0xfff8
        val moreFragments = (fragmentField and 1) != 0
        if (offsetBytes == 0 && !moreFragments) return packet // Atomic fragment; codec can parse it.

        val payload = packet.copyOfRange(offset + 8, totalLength)
        if (payload.isEmpty() || (moreFragments && payload.size % 8 != 0)) return null
        if (offsetBytes + payload.size > MAX_REASSEMBLED_SIZE) return null

        val key = FragmentKey(
            version = 6,
            source = hex(packet, 8, 16),
            destination = hex(packet, 24, 16),
            identification = u32(packet, offset + 4),
            protocol = followingHeader
        )
        val prefix = if (offsetBytes == 0) {
            packet.copyOfRange(0, offset).also { it[previousNextHeaderOffset] = followingHeader.toByte() }
        } else {
            null
        }
        return addFragment(key, offsetBytes, payload, moreFragments, prefix) { header, body ->
            val newPayloadLength = header.size - 40 + body.size
            if (newPayloadLength !in 1..65_535) return@addFragment null
            val result = ByteArray(header.size + body.size)
            header.copyInto(result)
            body.copyInto(result, header.size)
            put16(result, 4, newPayloadLength)
            result
        }
    }

    private inline fun addFragment(
        key: FragmentKey,
        offset: Int,
        payload: ByteArray,
        moreFragments: Boolean,
        prefix: ByteArray?,
        buildPacket: (ByteArray, ByteArray) -> ByteArray?
    ): ByteArray? = synchronized(lock) {
        pruneExpired(clockNanos())
        val now = clockNanos()
        var set = fragments[key]
        if (set == null) {
            while (fragments.size >= maxActiveDatagrams) {
                val oldestKey = fragments.keys.firstOrNull() ?: break
                removeSet(oldestKey)
            }
            set = FragmentSet(updatedAt = now)
            fragments[key] = set
        }

        val end = offset + payload.size
        val finalSize = set.finalPayloadSize
        if (end > MAX_REASSEMBLED_SIZE || (finalSize != null && end > finalSize)) {
            removeSet(key)
            return@synchronized null
        }
        if (!moreFragments) {
            if (finalSize != null && finalSize != end) {
                removeSet(key)
                return@synchronized null
            }
            if (set.pieces.any { (pieceOffset, piece) -> pieceOffset + piece.size > end }) {
                removeSet(key)
                return@synchronized null
            }
            set.finalPayloadSize = end
        }

        val sameOffset = set.pieces[offset]
        if (sameOffset != null) {
            if (sameOffset.contentEquals(payload)) return@synchronized null
            removeSet(key)
            return@synchronized null
        }
        val overlaps = set.pieces.any { (pieceOffset, piece) ->
            offset < pieceOffset + piece.size && pieceOffset < end
        }
        if (overlaps) {
            removeSet(key)
            return@synchronized null
        }

        if (prefix != null) {
            val existingPrefix = set.prefix
            if (existingPrefix != null && !existingPrefix.contentEquals(prefix)) {
                removeSet(key)
                return@synchronized null
            }
            set.prefix = prefix
        }

        if (bufferedBytes + payload.size > maxBufferedBytes) {
            removeSet(key)
            return@synchronized null
        }
        set.pieces[offset] = payload
        set.bufferedBytes += payload.size
        bufferedBytes += payload.size
        set.updatedAt = now

        val expectedSize = set.finalPayloadSize ?: return@synchronized null
        val packetPrefix = set.prefix ?: return@synchronized null
        var cursor = 0
        for ((pieceOffset, piece) in set.pieces) {
            if (pieceOffset != cursor) return@synchronized null
            cursor += piece.size
        }
        if (cursor != expectedSize) return@synchronized null

        val body = ByteArray(expectedSize)
        for ((pieceOffset, piece) in set.pieces) piece.copyInto(body, pieceOffset)
        val result = buildPacket(packetPrefix, body)
        removeSet(key)
        result
    }

    private fun pruneExpired(now: Long) {
        val expired = fragments.filterValues { now - it.updatedAt > timeoutNanos }.keys.toList()
        expired.forEach(::removeSet)
    }

    private fun removeSet(key: FragmentKey) {
        val removed = fragments.remove(key) ?: return
        bufferedBytes = (bufferedBytes - removed.bufferedBytes).coerceAtLeast(0)
    }

    private fun hex(bytes: ByteArray, offset: Int, length: Int): String = buildString(length * 2) {
        for (index in offset until offset + length) {
            val value = bytes[index].toInt() and 0xff
            append(HEX[value ushr 4])
            append(HEX[value and 0x0f])
        }
    }

    private fun checksum(bytes: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var index = offset
        val end = offset + length
        while (index + 1 < end) {
            sum += (((bytes[index].toInt() and 0xff) shl 8) or
                (bytes[index + 1].toInt() and 0xff)).toLong()
            index += 2
        }
        if (index < end) sum += ((bytes[index].toInt() and 0xff) shl 8).toLong()
        while ((sum ushr 16) != 0L) sum = (sum and 0xffff) + (sum ushr 16)
        return sum.inv().toInt() and 0xffff
    }

    private fun u16(bytes: ByteArray, offset: Int): Int =
        ((bytes[offset].toInt() and 0xff) shl 8) or (bytes[offset + 1].toInt() and 0xff)

    private fun u32(bytes: ByteArray, offset: Int): Long =
        ((bytes[offset].toLong() and 0xff) shl 24) or
            ((bytes[offset + 1].toLong() and 0xff) shl 16) or
            ((bytes[offset + 2].toLong() and 0xff) shl 8) or
            (bytes[offset + 3].toLong() and 0xff)

    private fun put16(bytes: ByteArray, offset: Int, value: Int) {
        bytes[offset] = (value ushr 8).toByte()
        bytes[offset + 1] = value.toByte()
    }

    companion object {
        private const val IPV6_HOP_BY_HOP = 0
        private const val IPV6_ROUTING = 43
        private const val IPV6_FRAGMENT_HEADER = 44
        private const val IPV6_AUTHENTICATION = 51
        private const val IPV6_DESTINATION_OPTIONS = 60
        private const val MAX_REASSEMBLED_SIZE = 65_535
        private const val MAX_ACTIVE_DATAGRAMS = 32
        private const val MAX_BUFFERED_BYTES = 2 * 1024 * 1024
        private const val DEFAULT_TIMEOUT_NANOS = 15_000_000_000L
        private const val HEX = "0123456789abcdef"
    }
}
