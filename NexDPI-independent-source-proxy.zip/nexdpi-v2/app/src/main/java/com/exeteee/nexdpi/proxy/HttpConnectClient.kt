package com.exeteee.nexdpi.proxy

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.charset.StandardCharsets
import java.util.Base64

/** HTTP/1.1 CONNECT tunnel setup for a socket already protected from the Android VPN loop. */
object HttpConnectClient {
    private const val MAX_RESPONSE_HEADER_BYTES = 16 * 1024

    fun connect(
        socket: Socket,
        profile: ProxyProfile,
        targetAddress: InetAddress,
        targetPort: Int,
        timeoutMillis: Int
    ) {
        require(profile.type == ProxyType.HTTP_CONNECT)
        require(targetPort in 1..65535)
        socket.connect(InetSocketAddress(InetAddress.getByName(profile.server), profile.port), timeoutMillis)
        socket.soTimeout = timeoutMillis

        val host = if (targetAddress is java.net.Inet6Address) "[${targetAddress.hostAddress.substringBefore('%')}]" else targetAddress.hostAddress
        val authority = "$host:$targetPort"
        val request = StringBuilder()
            .append("CONNECT ").append(authority).append(" HTTP/1.1\r\n")
            .append("Host: ").append(authority).append("\r\n")
            .append("Proxy-Connection: Keep-Alive\r\n")
        if (!profile.username.isNullOrEmpty() || !profile.password.isNullOrEmpty()) {
            val credentials = "${profile.username.orEmpty()}:${profile.password.orEmpty()}"
            val encoded = Base64.getEncoder().encodeToString(credentials.toByteArray(StandardCharsets.UTF_8))
            request.append("Proxy-Authorization: Basic ").append(encoded).append("\r\n")
        }
        request.append("\r\n")
        socket.getOutputStream().apply {
            write(request.toString().toByteArray(StandardCharsets.US_ASCII))
            flush()
        }

        val headers = readHeaderBlock(socket)
        val statusLine = headers.substringBefore("\r\n")
        val match = Regex("^HTTP/1\\.[01] ([0-9]{3})(?: .*)?$").matchEntire(statusLine)
            ?: throw IOException("HTTP proxy: некорректная строка ответа")
        val status = match.groupValues[1].toInt()
        if (status != 200) {
            val reason = when (status) {
                407 -> "требуется или неверна авторизация"
                403 -> "доступ запрещён"
                502, 503, 504 -> "прокси не может соединиться с узлом назначения"
                else -> "CONNECT отклонён (HTTP $status)"
            }
            throw IOException("HTTP proxy: $reason")
        }
        socket.soTimeout = 0
    }

    private fun readHeaderBlock(socket: Socket): String {
        val output = ByteArrayOutputStream()
        var matched = 0
        val delimiter = byteArrayOf(13, 10, 13, 10)
        while (output.size() < MAX_RESPONSE_HEADER_BYTES) {
            val value = socket.getInputStream().read()
            if (value < 0) throw IOException("HTTP proxy: соединение закрыто до ответа")
            output.write(value)
            matched = when {
                value == (delimiter[matched].toInt() and 0xff) -> matched + 1
                value == 13 -> 1
                else -> 0
            }
            if (matched == delimiter.size) return output.toByteArray().toString(StandardCharsets.ISO_8859_1)
        }
        throw IOException("HTTP proxy: слишком большие заголовки ответа")
    }
}
