package com.exeteee.nexdpi.vpn

import java.io.ByteArrayOutputStream
import kotlin.math.ln
import kotlin.math.sqrt

sealed interface TlsGateDecision {
    data object Hold : TlsGateDecision
    data class ForwardRaw(val bytes: ByteArray) : TlsGateDecision
    data class SplitClientHello(val bytes: ByteArray, val hello: TlsClientHello) : TlsGateDecision
}

/**
 * Buffers only the first TLS record long enough to identify a complete ClientHello.
 * Non-TLS, malformed, SNI-less, ECH-marked and timed-out streams are forwarded byte-for-byte.
 */
class TlsClientHelloGate(
    private val timeoutMillis: Long = DEFAULT_TIMEOUT_MILLIS,
    private val clockNanos: () -> Long = System::nanoTime
) {
    private val buffer = ByteArrayOutputStream()
    private var startedAtNanos = 0L
    private var decided = false

    init {
        require(timeoutMillis in 50..2_000) { "TLS inspection timeout must be 50..2000 ms" }
    }

    @Synchronized
    fun append(bytes: ByteArray): TlsGateDecision {
        if (bytes.isEmpty()) return TlsGateDecision.Hold
        if (decided) return TlsGateDecision.ForwardRaw(bytes.copyOf())
        if (buffer.size() == 0) startedAtNanos = clockNanos()
        buffer.write(bytes)
        val stream = buffer.toByteArray()

        if (stream.size > MAX_BUFFERED_TLS_RECORD) return passThrough(stream)
        if ((stream[0].toInt() and 0xff) != TLS_HANDSHAKE_CONTENT_TYPE) return passThrough(stream)
        if (stream.size >= 3) {
            val version = u16(stream, 1)
            if (version !in 0x0300..0x0303) return passThrough(stream)
        }
        if (stream.size < TLS_RECORD_HEADER_SIZE) return TlsGateDecision.Hold

        val recordLength = u16(stream, 3)
        if (recordLength !in 4..MAX_TLS_RECORD_SIZE) return passThrough(stream)
        val recordEnd = TLS_RECORD_HEADER_SIZE + recordLength
        if (stream.size < recordEnd) return TlsGateDecision.Hold

        val hello = TlsClientHelloParser.parse(stream)
        if (hello?.serverName == null || hello.encryptedClientHello) return passThrough(stream)
        decided = true
        buffer.reset()
        return TlsGateDecision.SplitClientHello(stream, hello)
    }

    @Synchronized
    fun flushIfExpired(nowNanos: Long = clockNanos()): ByteArray? {
        if (decided || buffer.size() == 0) return null
        val ageNanos = nowNanos - startedAtNanos
        if (ageNanos < timeoutMillis * NANOS_PER_MILLISECOND) return null
        val bytes = buffer.toByteArray()
        decided = true
        buffer.reset()
        return bytes
    }

    @Synchronized
    fun clear() {
        buffer.reset()
        startedAtNanos = 0L
        decided = true
    }

    private fun passThrough(bytes: ByteArray): TlsGateDecision.ForwardRaw {
        decided = true
        buffer.reset()
        return TlsGateDecision.ForwardRaw(bytes)
    }

    private fun u16(bytes: ByteArray, offset: Int): Int =
        ((bytes[offset].toInt() and 0xff) shl 8) or (bytes[offset + 1].toInt() and 0xff)

    companion object {
        private const val TLS_HANDSHAKE_CONTENT_TYPE = 22
        private const val TLS_RECORD_HEADER_SIZE = 5
        private const val MAX_TLS_RECORD_SIZE = 18_432
        private const val MAX_BUFFERED_TLS_RECORD = TLS_RECORD_HEADER_SIZE + MAX_TLS_RECORD_SIZE
        private const val DEFAULT_TIMEOUT_MILLIS = 350L
        private const val NANOS_PER_MILLISECOND = 1_000_000L
    }
}

/**
 * Bounded per-host strategy selector. It explores each split candidate, then uses a UCB-style
 * score based on whether the remote endpoint sent data after the ClientHello. This is a network
 * reachability signal, not proof that DPI was bypassed or that the TLS handshake succeeded.
 */
class TlsSplitStrategySelector(
    private val strategies: List<TlsSplitPoint> = TlsSplitPoint.entries,
    private val maxTrackedHosts: Int = DEFAULT_MAX_TRACKED_HOSTS
) {
    private data class OutcomeStats(
        var attempts: Int = 0,
        var successes: Int = 0,
        var failures: Int = 0
    )

    private class HostStats {
        val byStrategy = LinkedHashMap<TlsSplitPoint, OutcomeStats>()
    }

    private val hosts = LinkedHashMap<String, HostStats>(16, 0.75f, true)

    init {
        require(strategies.isNotEmpty()) { "At least one TLS split strategy is required" }
        require(strategies.distinct().size == strategies.size) { "TLS split strategies must be unique" }
        require(maxTrackedHosts in 1..MAX_ALLOWED_TRACKED_HOSTS) { "Invalid host-history limit" }
    }

    @Synchronized
    fun next(hostname: String?): TlsSplitPoint {
        val state = stateFor(normalizeHost(hostname))
        val unexplored = strategies.firstOrNull { (state.byStrategy[it]?.attempts ?: 0) == 0 }
        val selected = unexplored ?: strategies.maxBy { strategy ->
            val stats = state.byStrategy.getValue(strategy)
            val completed = stats.successes + stats.failures
            val totalAttempts = state.byStrategy.values.sumOf { it.attempts }.coerceAtLeast(1)
            val mean = (stats.successes + 1.0) / (completed + 2.0)
            val exploration = sqrt(2.0 * ln(totalAttempts + 1.0) / stats.attempts.coerceAtLeast(1))
            mean + exploration
        }
        state.byStrategy.getOrPut(selected) { OutcomeStats() }.attempts++
        return selected
    }

    @Synchronized
    fun recordOutcome(hostname: String?, strategy: TlsSplitPoint, remoteResponded: Boolean) {
        val state = stateFor(normalizeHost(hostname))
        val stats = state.byStrategy[strategy] ?: return
        val completed = stats.successes + stats.failures
        if (completed >= stats.attempts) return
        if (remoteResponded) stats.successes++ else stats.failures++
    }

    @Synchronized
    fun trackedHostCount(): Int = hosts.size

    @Synchronized
    fun outcomeCounts(hostname: String?, strategy: TlsSplitPoint): Pair<Int, Int>? {
        val stats = hosts[normalizeHost(hostname)]?.byStrategy?.get(strategy) ?: return null
        return stats.successes to stats.failures
    }

    private fun stateFor(host: String): HostStats {
        hosts[host]?.let { return it }
        while (hosts.size >= maxTrackedHosts) {
            val oldest = hosts.keys.firstOrNull() ?: break
            hosts.remove(oldest)
        }
        return HostStats().also { hosts[host] = it }
    }

    private fun normalizeHost(hostname: String?): String =
        hostname?.trim()?.lowercase()?.takeIf { it.isNotEmpty() && it.length <= 253 } ?: UNKNOWN_HOST

    companion object {
        const val DEFAULT_MAX_TRACKED_HOSTS = 128
        const val MAX_ALLOWED_TRACKED_HOSTS = 1_024
        private const val UNKNOWN_HOST = "<unknown>"
    }
}
