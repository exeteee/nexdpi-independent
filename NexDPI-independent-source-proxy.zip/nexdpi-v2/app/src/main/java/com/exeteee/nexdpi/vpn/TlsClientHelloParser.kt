package com.exeteee.nexdpi.vpn

/**
 * Parsed metadata from the first TLS ClientHello carried in a single TLS handshake record.
 * Offsets are relative to the beginning of the supplied byte stream and are suitable for
 * planning application-stream write boundaries. No TLS bytes are modified by this class.
 */
data class TlsClientHello(
    val legacyVersion: Int,
    val serverName: String?,
    val serverNameOffset: Int?,
    val serverNameLength: Int?,
    val handshakeEndOffset: Int,
    val recordEndOffset: Int,
    val encryptedClientHello: Boolean = false
)

/**
 * Bounded parser for a contiguous TLS record containing a ClientHello.
 * It intentionally rejects incomplete, malformed, oversized and multi-record handshakes.
 */
object TlsClientHelloParser {
    private const val TLS_HANDSHAKE_CONTENT_TYPE = 22
    private const val CLIENT_HELLO_HANDSHAKE_TYPE = 1
    private const val SERVER_NAME_EXTENSION = 0x0000
    private const val ENCRYPTED_CLIENT_HELLO_EXTENSION = 0xfe0d
    private const val MAX_TLS_RECORD_SIZE = 18_432
    private const val MAX_CLIENT_HELLO_SIZE = 65_535
    private const val MAX_SERVER_NAME_SIZE = 253

    fun parse(bytes: ByteArray): TlsClientHello? {
        if (bytes.size < TLS_RECORD_HEADER_SIZE + HANDSHAKE_HEADER_SIZE) return null
        if ((bytes[0].toInt() and 0xff) != TLS_HANDSHAKE_CONTENT_TYPE) return null

        val recordVersion = u16(bytes, 1)
        // TLS record legacy versions used by ClientHello are in the 0x0300..0x0303 range.
        if (recordVersion !in 0x0300..0x0303) return null

        val recordPayloadLength = u16(bytes, 3)
        if (recordPayloadLength !in HANDSHAKE_HEADER_SIZE..MAX_TLS_RECORD_SIZE) return null
        val recordEnd = TLS_RECORD_HEADER_SIZE + recordPayloadLength
        if (bytes.size < recordEnd) return null

        val handshakeOffset = TLS_RECORD_HEADER_SIZE
        if ((bytes[handshakeOffset].toInt() and 0xff) != CLIENT_HELLO_HANDSHAKE_TYPE) return null
        val handshakeLength = u24(bytes, handshakeOffset + 1)
        if (handshakeLength !in 34..MAX_CLIENT_HELLO_SIZE) return null
        val handshakeEnd = handshakeOffset + HANDSHAKE_HEADER_SIZE + handshakeLength
        if (handshakeEnd > recordEnd) return null

        val cursor = Cursor(bytes, handshakeOffset + HANDSHAKE_HEADER_SIZE, handshakeEnd)
        val legacyVersion = cursor.readU16() ?: return null
        if (legacyVersion !in 0x0300..0x0303) return null
        if (!cursor.skip(32)) return null // random

        val sessionIdLength = cursor.readU8() ?: return null
        if (sessionIdLength > 32 || !cursor.skip(sessionIdLength)) return null

        val cipherSuitesLength = cursor.readU16() ?: return null
        if (cipherSuitesLength < 2 || cipherSuitesLength % 2 != 0) return null
        if (!cursor.skip(cipherSuitesLength)) return null

        val compressionLength = cursor.readU8() ?: return null
        if (compressionLength < 1 || !cursor.skip(compressionLength)) return null

        // Older ClientHello messages may omit extensions entirely.
        if (cursor.remaining == 0) {
            return TlsClientHello(
                legacyVersion = legacyVersion,
                serverName = null,
                serverNameOffset = null,
                serverNameLength = null,
                handshakeEndOffset = handshakeEnd,
                recordEndOffset = recordEnd
            )
        }

        val extensionsLength = cursor.readU16() ?: return null
        if (extensionsLength != cursor.remaining) return null
        val extensionsEnd = cursor.position + extensionsLength
        var parsedServerName: String? = null
        var parsedServerNameOffset: Int? = null
        var parsedServerNameLength: Int? = null
        var encryptedClientHello = false

        while (cursor.position < extensionsEnd) {
            val extensionType = cursor.readU16() ?: return null
            val extensionLength = cursor.readU16() ?: return null
            val extensionEnd = cursor.position + extensionLength
            if (extensionEnd > extensionsEnd) return null

            if (extensionType == ENCRYPTED_CLIENT_HELLO_EXTENSION) {
                encryptedClientHello = true
            }

            if (extensionType == SERVER_NAME_EXTENSION && parsedServerName == null) {
                val listLength = cursor.readU16() ?: return null
                if (listLength != extensionEnd - cursor.position) return null
                val listEnd = cursor.position + listLength
                while (cursor.position < listEnd) {
                    val nameType = cursor.readU8() ?: return null
                    val nameLength = cursor.readU16() ?: return null
                    if (nameLength == 0 || cursor.position + nameLength > listEnd) return null
                    val nameOffset = cursor.position
                    val nameBytes = cursor.readBytes(nameLength) ?: return null
                    if (nameType == 0 && parsedServerName == null) {
                        if (nameLength > MAX_SERVER_NAME_SIZE) return null
                        if (nameBytes.any { (it.toInt() and 0xff) !in 0x21..0x7e }) return null
                        val candidate = nameBytes.toString(Charsets.US_ASCII).lowercase()
                        if (!isValidHostname(candidate)) return null
                        parsedServerName = candidate
                        parsedServerNameOffset = nameOffset
                        parsedServerNameLength = nameLength
                    }
                }
                if (cursor.position != listEnd) return null
            }

            if (!cursor.moveTo(extensionEnd)) return null
        }
        if (cursor.position != extensionsEnd) return null

        return TlsClientHello(
            legacyVersion = legacyVersion,
            serverName = parsedServerName,
            serverNameOffset = parsedServerNameOffset,
            serverNameLength = parsedServerNameLength,
            handshakeEndOffset = handshakeEnd,
            recordEndOffset = recordEnd,
            encryptedClientHello = encryptedClientHello
        )
    }

    private fun isValidHostname(host: String): Boolean {
        if (host.isBlank() || host.length > MAX_SERVER_NAME_SIZE || host.startsWith('.') || host.endsWith('.')) {
            return false
        }
        if (host.contains("..")) return false
        return host.split('.').all { label ->
            label.isNotEmpty() && label.length <= 63 &&
                label.first() != '-' && label.last() != '-' &&
                label.all { it in 'a'..'z' || it in '0'..'9' || it == '-' }
        }
    }

    private class Cursor(
        private val bytes: ByteArray,
        start: Int,
        private val end: Int
    ) {
        var position: Int = start
            private set
        val remaining: Int get() = end - position

        fun readU8(): Int? {
            if (remaining < 1) return null
            return bytes[position++].toInt() and 0xff
        }

        fun readU16(): Int? {
            if (remaining < 2) return null
            val value = u16(bytes, position)
            position += 2
            return value
        }

        fun readBytes(length: Int): ByteArray? {
            if (length < 0 || length > remaining) return null
            return bytes.copyOfRange(position, position + length).also { position += length }
        }

        fun skip(length: Int): Boolean {
            if (length < 0 || length > remaining) return false
            position += length
            return true
        }

        fun moveTo(target: Int): Boolean {
            if (target < position || target > end) return false
            position = target
            return true
        }
    }

    private fun u16(bytes: ByteArray, offset: Int): Int =
        ((bytes[offset].toInt() and 0xff) shl 8) or (bytes[offset + 1].toInt() and 0xff)

    private fun u24(bytes: ByteArray, offset: Int): Int =
        ((bytes[offset].toInt() and 0xff) shl 16) or
            ((bytes[offset + 1].toInt() and 0xff) shl 8) or
            (bytes[offset + 2].toInt() and 0xff)

    private const val TLS_RECORD_HEADER_SIZE = 5
    private const val HANDSHAKE_HEADER_SIZE = 4
}

/** Available stream-boundary candidates; these are planning values, not packet-level guarantees. */
enum class TlsSplitPoint {
    BEFORE_SNI,
    MIDDLE_OF_SNI,
    AFTER_SNI
}

/**
 * Calculates a split offset for the local TCP relay. Splitting socket writes is
 * best-effort: Android's TCP stack may coalesce writes, so this does not guarantee wire segments.
 */
object TlsSplitPlanner {
    fun splitOffset(hello: TlsClientHello, strategy: TlsSplitPoint): Int? {
        val start = hello.serverNameOffset ?: return null
        val length = hello.serverNameLength ?: return null
        if (length < 2) return null
        val offset = when (strategy) {
            TlsSplitPoint.BEFORE_SNI -> start
            TlsSplitPoint.MIDDLE_OF_SNI -> start + length / 2
            TlsSplitPoint.AFTER_SNI -> start + length
        }
        return offset.takeIf { it > 0 && it < hello.handshakeEndOffset }
    }

    /** Creates byte-preserving chunks for the local socket relay; it does not emit TCP packets. */
    fun splitWrites(
        stream: ByteArray,
        hello: TlsClientHello,
        strategy: TlsSplitPoint
    ): List<ByteArray>? {
        val offset = splitOffset(hello, strategy) ?: return null
        if (offset >= stream.size) return null
        return listOf(
            stream.copyOfRange(0, offset),
            stream.copyOfRange(offset, stream.size)
        )
    }
}

/** Best-effort direct-socket writer used by the local TCP relay. */
object TlsSplitWriter {
    @Throws(java.io.IOException::class, InterruptedException::class)
    fun write(
        socket: java.net.Socket,
        stream: ByteArray,
        hello: TlsClientHello,
        strategy: TlsSplitPoint,
        interWriteDelayMillis: Long = DEFAULT_INTER_WRITE_DELAY_MILLIS
    ) {
        require(interWriteDelayMillis in 0..MAX_INTER_WRITE_DELAY_MILLIS) {
            "Inter-write delay must be between 0 and $MAX_INTER_WRITE_DELAY_MILLIS ms"
        }
        check(socket.isConnected && !socket.isClosed) { "Socket must be connected and open" }
        val chunks = TlsSplitPlanner.splitWrites(stream, hello, strategy)
            ?: throw java.io.IOException("No safe SNI split point is available")

        // TCP_NODELAY avoids Nagle buffering; the delay is still only best-effort and
        // does not guarantee that the operating system emits two separate TCP segments.
        socket.tcpNoDelay = true
        val output = socket.getOutputStream()
        output.write(chunks[0])
        output.flush()
        if (interWriteDelayMillis > 0) Thread.sleep(interWriteDelayMillis)
        output.write(chunks[1])
        output.flush()
    }

    private const val DEFAULT_INTER_WRITE_DELAY_MILLIS = 20L
    private const val MAX_INTER_WRITE_DELAY_MILLIS = 250L
}
