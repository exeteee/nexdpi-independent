package com.exeteee.nexdpi.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

/**
 * The white list is stored only on this device. Entries represent packages that
 * must bypass NexDPI packet processing; no installed-app inventory is uploaded.
 */
class WhitelistRepository(context: Context) {
    private val preferences = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)

    fun getPackages(): Set<String> = preferences.getStringSet(KEY_PACKAGES, emptySet())
        ?.toSet()
        ?: emptySet()

    fun setIncluded(packageName: String, included: Boolean) {
        val updated = getPackages().toMutableSet()
        if (included) updated.add(packageName) else updated.remove(packageName)
        preferences.edit().putStringSet(KEY_PACKAGES, updated).apply()
    }

    companion object {
        private const val PREFERENCES_NAME = "nexdpi_local_preferences"
        private const val KEY_PACKAGES = "whitelist_packages"
    }
}

data class InstalledApp(
    val packageName: String,
    val label: String
)

object InstalledAppCatalog {
    fun load(context: Context): List<InstalledApp> {
        val packageManager = context.packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)

        val activities = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            packageManager.queryIntentActivities(
                launcherIntent,
                PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_ALL.toLong())
            )
        } else {
            @Suppress("DEPRECATION")
            packageManager.queryIntentActivities(launcherIntent, PackageManager.MATCH_ALL)
        }

        return activities.mapNotNull { resolveInfo ->
            val activityInfo = resolveInfo.activityInfo ?: return@mapNotNull null
            val packageName = activityInfo.packageName
            if (packageName == context.packageName) return@mapNotNull null

            InstalledApp(
                packageName = packageName,
                label = resolveInfo.loadLabel(packageManager).toString()
            )
        }
            .distinctBy(InstalledApp::packageName)
            .sortedBy { it.label.lowercase() }
    }
}
