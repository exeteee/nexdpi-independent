package com.exeteee.nexdpi.vpn

import java.util.concurrent.atomic.AtomicInteger

/** Parsed UDP datagram carried by an IPv4 or IPv6 packet. */
data class UdpDatagram(
    val ipVersion: Int,
    val sourceAddress: ByteArray,
    val destinationAddress: ByteArray,
    val sourcePort: Int,
    val destinationPort: Int,
    val payload: ByteArray
)

/**
 * Generic IPv4/IPv6 UDP codec for the independent local datagram relay.
 * Input IP fragments must be reassembled before parsing. Output datagrams are
 * fragmented at the IP layer when necessary to respect the TUN MTU.
 */
object UdpPacketCodec {
    private const val UDP_PROTOCOL = 17
    private const val IPV4_HEADER = 20
    private const val IPV6_HEADER = 40
    private const val UDP_HEADER = 8
    private const val MAX_UDP_LENGTH = 65_535
    private val nextIpv4Identification = AtomicInteger(0x4e00)
    private val nextIpv6FragmentId = AtomicInteger(0x4e580001)

    fun parse(packet: ByteArray, length: Int = packet.size): UdpDatagram? {
        if (length < 1 || length > packet.size) return null
        return when ((packet[0].toInt() ushr 4) and 0x0f) {
            4 -> parseIpv4(packet, length)
            6 -> parseIpv6(packet, length)
            else -> null
        }
    }

    private fun parseIpv4(packet: ByteArray, length: Int): UdpDatagram? {
        if (length < IPV4_HEADER + UDP_HEADER) return null
        val headerLength = (packet[0].toInt() and 0x0f) * 4
        if (headerLength !in IPV4_HEADER..60 || length < headerLength + UDP_HEADER) return null
        if (checksum(packet, 0, headerLength) != 0) return null
        val totalLength = u16(packet, 2)
        if (totalLength < headerLength + UDP_HEADER || totalLength > length) return null
        if ((packet[9].toInt() and 0xff) != UDP_PROTOCOL) return null
        val fragmentField = u16(packet, 6)
        // DF is allowed; reserved, MF and non-zero offset are not.
        if ((fragmentField and 0x8000) != 0 || (fragmentField and 0x3fff) != 0) return null

        val udpOffset = headerLength
        val udpLength = u16(packet, udpOffset + 4)
        if (udpLength < UDP_HEADER || udpLength > totalLength - udpOffset) return null
        val checksum = u16(packet, udpOffset + 6)
        val source = packet.copyOfRange(12, 16)
        val destination = packet.copyOfRange(16, 20)
        if (checksum != 0 && udpChecksumV4(source, destination, packet, udpOffset, udpLength) != 0) return null

        return UdpDatagram(
            ipVersion = 4,
            sourceAddress = source,
            destinationAddress = destination,
            sourcePort = u16(packet, udpOffset),
            destinationPort = u16(packet, udpOffset + 2),
            payload = packet.copyOfRange(udpOffset + UDP_HEADER, udpOffset + udpLength)
        )
    }

    private fun parseIpv6(packet: ByteArray, length: Int): UdpDatagram? {
        if (length < IPV6_HEADER + UDP_HEADER) return null
        val payloadLength = u16(packet, 4)
        if (payloadLength == 0) return null // Jumbograms are outside the bounded datapath.
        val packetEnd = IPV6_HEADER + payloadLength
        if (packetEnd > length) return null

        var nextHeader = packet[6].toInt() and 0xff
        var udpOffset = IPV6_HEADER
        while (nextHeader != UDP_PROTOCOL) {
            if (udpOffset + 2 > packetEnd) return null
            val following = packet[udpOffset].toInt() and 0xff
            val extensionLength = when (nextHeader) {
                IPV6_HOP_BY_HOP, IPV6_ROUTING, IPV6_DESTINATION_OPTIONS ->
                    ((packet[udpOffset + 1].toInt() and 0xff) + 1) * 8
                IPV6_AUTHENTICATION -> ((packet[udpOffset + 1].toInt() and 0xff) + 2) * 4
                IPV6_FRAGMENT -> {
                    if (udpOffset + 8 > packetEnd) return null
                    val fragmentField = u16(packet, udpOffset + 2)
                    // Only an atomic fragment can be consumed without reassembly.
                    if ((fragmentField and 0x0006) != 0 || (fragmentField and 0xfff9) != 0) return null
                    8
                }
                else -> return null
            }
            if (extensionLength < 8 || udpOffset + extensionLength > packetEnd) return null
            nextHeader = following
            udpOffset += extensionLength
        }

        if (udpOffset + UDP_HEADER > packetEnd) return null
        val udpLength = u16(packet, udpOffset + 4)
        if (udpLength < UDP_HEADER || udpLength > packetEnd - udpOffset) return null
        if (u16(packet, udpOffset + 6) == 0) return null // IPv6 requires a UDP checksum.

        val source = packet.copyOfRange(8, 24)
        val destination = packet.copyOfRange(24, 40)
        if (udpChecksumV6(source, destination, packet, udpOffset, udpLength) != 0) return null

        return UdpDatagram(
            ipVersion = 6,
            sourceAddress = source,
            destinationAddress = destination,
            sourcePort = u16(packet, udpOffset),
            destinationPort = u16(packet, udpOffset + 2),
            payload = packet.copyOfRange(udpOffset + UDP_HEADER, udpOffset + udpLength)
        )
    }

    /** Builds the reverse-direction packet sequence for a datagram response. */
    fun buildResponsePackets(
        request: UdpDatagram,
        responsePayload: ByteArray,
        mtu: Int = 1500
    ): List<ByteArray>? {
        if (request.sourcePort !in 0..65_535 || request.destinationPort !in 0..65_535) return null
        if (responsePayload.size > MAX_UDP_LENGTH - UDP_HEADER || mtu < 576) return null
        val udpLength = UDP_HEADER + responsePayload.size
        return when (request.ipVersion) {
            4 -> buildIpv4(request, responsePayload, udpLength, mtu)
            6 -> buildIpv6(request, responsePayload, udpLength, mtu)
            else -> null
        }
    }

    private fun buildIpv4(
        request: UdpDatagram,
        payload: ByteArray,
        udpLength: Int,
        mtu: Int
    ): List<ByteArray>? {
        if (request.sourceAddress.size != 4 || request.destinationAddress.size != 4) return null
        val totalLength = IPV4_HEADER + udpLength
        if (totalLength > 65_535) return null
        val identification = nextIpv4Identification.getAndIncrement() and 0xffff
        val full = ByteArray(totalLength)
        full[0] = 0x45
        put16(full, 2, totalLength)
        put16(full, 4, identification)
        full[8] = 64
        full[9] = UDP_PROTOCOL.toByte()
        request.destinationAddress.copyInto(full, 12)
        request.sourceAddress.copyInto(full, 16)
        put16(full, 20, request.destinationPort)
        put16(full, 22, request.sourcePort)
        put16(full, 24, udpLength)
        payload.copyInto(full, 28)
        val udpChecksum = udpChecksumV4(request.destinationAddress, request.sourceAddress, full, 20, udpLength)
        put16(full, 26, if (udpChecksum == 0) 0xffff else udpChecksum)

        if (totalLength <= mtu) {
            put16(full, 10, checksum(full, 0, IPV4_HEADER))
            return listOf(full)
        }

        val fragmentDataSize = ((mtu - IPV4_HEADER) / 8) * 8
        if (fragmentDataSize < 8) return null
        val udpSegment = full.copyOfRange(IPV4_HEADER, full.size)
        val fragments = ArrayList<ByteArray>()
        var offset = 0
        while (offset < udpSegment.size) {
            val chunk = minOf(fragmentDataSize, udpSegment.size - offset)
            val more = offset + chunk < udpSegment.size
            val fragment = ByteArray(IPV4_HEADER + chunk)
            fragment[0] = 0x45
            put16(fragment, 2, fragment.size)
            put16(fragment, 4, identification)
            put16(fragment, 6, (offset / 8) or if (more) 0x2000 else 0)
            fragment[8] = 64
            fragment[9] = UDP_PROTOCOL.toByte()
            request.destinationAddress.copyInto(fragment, 12)
            request.sourceAddress.copyInto(fragment, 16)
            udpSegment.copyInto(fragment, IPV4_HEADER, offset, offset + chunk)
            put16(fragment, 10, checksum(fragment, 0, IPV4_HEADER))
            fragments += fragment
            offset += chunk
        }
        return fragments
    }

    private fun buildIpv6(
        request: UdpDatagram,
        payload: ByteArray,
        udpLength: Int,
        mtu: Int
    ): List<ByteArray>? {
        if (request.sourceAddress.size != 16 || request.destinationAddress.size != 16) return null
        if (udpLength > 65_535) return null
        val full = ByteArray(IPV6_HEADER + udpLength)
        full[0] = 0x60
        put16(full, 4, udpLength)
        full[6] = UDP_PROTOCOL.toByte()
        full[7] = 64
        request.destinationAddress.copyInto(full, 8)
        request.sourceAddress.copyInto(full, 24)
        put16(full, 40, request.destinationPort)
        put16(full, 42, request.sourcePort)
        put16(full, 44, udpLength)
        payload.copyInto(full, 48)
        val udpChecksum = udpChecksumV6(request.destinationAddress, request.sourceAddress, full, 40, udpLength)
        put16(full, 46, if (udpChecksum == 0) 0xffff else udpChecksum)

        if (full.size <= mtu) return listOf(full)
        val fragmentDataSize = ((mtu - IPV6_HEADER - 8) / 8) * 8
        if (fragmentDataSize < 8) return null
        val fragmentId = nextIpv6FragmentId.getAndIncrement()
        val udpSegment = full.copyOfRange(IPV6_HEADER, full.size)
        val fragments = ArrayList<ByteArray>()
        var offset = 0
        while (offset < udpSegment.size) {
            val chunk = minOf(fragmentDataSize, udpSegment.size - offset)
            val more = offset + chunk < udpSegment.size
            val fragment = ByteArray(IPV6_HEADER + 8 + chunk)
            fragment[0] = 0x60
            put16(fragment, 4, 8 + chunk)
            fragment[6] = IPV6_FRAGMENT.toByte()
            fragment[7] = 64
            request.destinationAddress.copyInto(fragment, 8)
            request.sourceAddress.copyInto(fragment, 24)
            fragment[40] = UDP_PROTOCOL.toByte()
            put16(fragment, 42, (offset and 0xfff8) or if (more) 1 else 0)
            put32(fragment, 44, fragmentId)
            udpSegment.copyInto(fragment, 48, offset, offset + chunk)
            fragments += fragment
            offset += chunk
        }
        return fragments
    }

    fun isValidUdpChecksum(datagram: UdpDatagram, packet: ByteArray): Boolean {
        val parsed = parse(packet) ?: return false
        if (parsed.ipVersion != datagram.ipVersion ||
            parsed.sourcePort != datagram.sourcePort ||
            parsed.destinationPort != datagram.destinationPort ||
            !parsed.sourceAddress.contentEquals(datagram.sourceAddress) ||
            !parsed.destinationAddress.contentEquals(datagram.destinationAddress) ||
            !parsed.payload.contentEquals(datagram.payload)) return false
        val (offset, udpLength) = findUdpBounds(packet, datagram.ipVersion) ?: return false
        val value = when (datagram.ipVersion) {
            4 -> {
                val checksumValue = u16(packet, offset + 6)
                checksumValue == 0 || udpChecksumV4(datagram.sourceAddress, datagram.destinationAddress, packet, offset, udpLength) == 0
            }
            6 -> udpChecksumV6(datagram.sourceAddress, datagram.destinationAddress, packet, offset, udpLength) == 0
            else -> false
        }
        return value
    }

    private fun findUdpBounds(packet: ByteArray, ipVersion: Int): Pair<Int, Int>? {
        if (ipVersion == 4) {
            if (packet.size < IPV4_HEADER) return null
            val offset = (packet[0].toInt() and 0x0f) * 4
            val end = u16(packet, 2)
            if (offset < IPV4_HEADER || offset + UDP_HEADER > end || end > packet.size) return null
            return offset to u16(packet, offset + 4)
        }
        if (ipVersion != 6 || packet.size < IPV6_HEADER) return null
        val end = IPV6_HEADER + u16(packet, 4)
        if (end > packet.size) return null
        var next = packet[6].toInt() and 0xff
        var offset = IPV6_HEADER
        while (next != UDP_PROTOCOL) {
            if (offset + 2 > end) return null
            val following = packet[offset].toInt() and 0xff
            val size = when (next) {
                IPV6_HOP_BY_HOP, IPV6_ROUTING, IPV6_DESTINATION_OPTIONS ->
                    ((packet[offset + 1].toInt() and 0xff) + 1) * 8
                IPV6_AUTHENTICATION -> ((packet[offset + 1].toInt() and 0xff) + 2) * 4
                IPV6_FRAGMENT -> 8
                else -> return null
            }
            if (offset + size > end) return null
            next = following
            offset += size
        }
        if (offset + UDP_HEADER > end) return null
        return offset to u16(packet, offset + 4)
    }

    private fun udpChecksumV4(
        source: ByteArray,
        destination: ByteArray,
        packet: ByteArray,
        offset: Int,
        length: Int
    ): Int {
        var sum = 0L
        sum = addWords(sum, source, 0, source.size)
        sum = addWords(sum, destination, 0, destination.size)
        sum += UDP_PROTOCOL.toLong()
        sum += length.toLong()
        sum = addWords(sum, packet, offset, length)
        return finishChecksum(sum)
    }

    private fun udpChecksumV6(
        source: ByteArray,
        destination: ByteArray,
        packet: ByteArray,
        offset: Int,
        length: Int
    ): Int {
        var sum = 0L
        sum = addWords(sum, source, 0, source.size)
        sum = addWords(sum, destination, 0, destination.size)
        sum += ((length ushr 16) and 0xffff).toLong()
        sum += (length and 0xffff).toLong()
        sum += UDP_PROTOCOL.toLong()
        sum = addWords(sum, packet, offset, length)
        return finishChecksum(sum)
    }

    private fun checksum(bytes: ByteArray, offset: Int, length: Int): Int =
        finishChecksum(addWords(0L, bytes, offset, length))

    private fun addWords(initial: Long, bytes: ByteArray, offset: Int, length: Int): Long {
        var sum = initial
        var index = offset
        val end = offset + length
        while (index + 1 < end) {
            sum += (((bytes[index].toInt() and 0xff) shl 8) or
                (bytes[index + 1].toInt() and 0xff)).toLong()
            index += 2
        }
        if (index < end) sum += ((bytes[index].toInt() and 0xff) shl 8).toLong()
        return sum
    }

    private fun finishChecksum(value: Long): Int {
        var sum = value
        while ((sum ushr 16) != 0L) sum = (sum and 0xffff) + (sum ushr 16)
        return sum.inv().toInt() and 0xffff
    }

    private fun u16(bytes: ByteArray, offset: Int): Int =
        ((bytes[offset].toInt() and 0xff) shl 8) or (bytes[offset + 1].toInt() and 0xff)

    private fun put16(bytes: ByteArray, offset: Int, value: Int) {
        bytes[offset] = (value ushr 8).toByte()
        bytes[offset + 1] = value.toByte()
    }

    private fun put32(bytes: ByteArray, offset: Int, value: Int) {
        bytes[offset] = (value ushr 24).toByte()
        bytes[offset + 1] = (value ushr 16).toByte()
        bytes[offset + 2] = (value ushr 8).toByte()
        bytes[offset + 3] = value.toByte()
    }

    private const val IPV6_HOP_BY_HOP = 0
    private const val IPV6_ROUTING = 43
    private const val IPV6_FRAGMENT = 44
    private const val IPV6_AUTHENTICATION = 51
    private const val IPV6_DESTINATION_OPTIONS = 60
}
