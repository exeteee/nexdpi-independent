package com.exeteee.nexdpi.vpn

/** Parsed TCP segment embedded in an IPv4 or IPv6 packet. */
data class TcpSegment(
    val ipVersion: Int,
    val sourceAddress: ByteArray,
    val destinationAddress: ByteArray,
    val sourcePort: Int,
    val destinationPort: Int,
    val sequenceNumber: Long,
    val acknowledgementNumber: Long,
    val flags: Int,
    val windowSize: Int,
    val urgentPointer: Int,
    val options: ByteArray,
    val payload: ByteArray
) {
    val isFin: Boolean get() = (flags and TcpPacketCodec.FLAG_FIN) != 0
    val isSyn: Boolean get() = (flags and TcpPacketCodec.FLAG_SYN) != 0
    val isRst: Boolean get() = (flags and TcpPacketCodec.FLAG_RST) != 0
    val isPsh: Boolean get() = (flags and TcpPacketCodec.FLAG_PSH) != 0
    val isAck: Boolean get() = (flags and TcpPacketCodec.FLAG_ACK) != 0
}

/**
 * Bounded IPv4/IPv6 TCP packet codec used by the independent local transport engine.
 * It parses TCP after IP-fragment reassembly and builds unfragmented response segments.
 */
object TcpPacketCodec {
    const val FLAG_FIN = 0x001
    const val FLAG_SYN = 0x002
    const val FLAG_RST = 0x004
    const val FLAG_PSH = 0x008
    const val FLAG_ACK = 0x010
    const val FLAG_URG = 0x020
    const val FLAG_ECE = 0x040
    const val FLAG_CWR = 0x080
    const val FLAG_NS = 0x100

    private const val TCP_PROTOCOL = 6
    private const val MIN_TCP_HEADER = 20
    private const val IPV4_HEADER = 20
    private const val IPV6_HEADER = 40
    private const val MAX_PACKET_SIZE = 65_535

    fun parse(packet: ByteArray, length: Int = packet.size): TcpSegment? {
        if (length < 1 || length > packet.size) return null
        return when ((packet[0].toInt() ushr 4) and 0x0f) {
            4 -> parseIpv4(packet, length)
            6 -> parseIpv6(packet, length)
            else -> null
        }
    }

    private fun parseIpv4(packet: ByteArray, length: Int): TcpSegment? {
        if (length < IPV4_HEADER + MIN_TCP_HEADER) return null
        val ipHeaderLength = (packet[0].toInt() and 0x0f) * 4
        if (ipHeaderLength !in IPV4_HEADER..60 || length < ipHeaderLength + MIN_TCP_HEADER) return null
        if (checksum(packet, 0, ipHeaderLength) != 0) return null
        val totalLength = u16(packet, 2)
        if (totalLength < ipHeaderLength + MIN_TCP_HEADER || totalLength > length) return null
        if ((packet[9].toInt() and 0xff) != TCP_PROTOCOL) return null
        val fragmentField = u16(packet, 6)
        if ((fragmentField and 0x8000) != 0 || (fragmentField and 0x3fff) != 0) return null
        return parseTcp(
            packet = packet,
            packetEnd = totalLength,
            tcpOffset = ipHeaderLength,
            ipVersion = 4,
            sourceAddress = packet.copyOfRange(12, 16),
            destinationAddress = packet.copyOfRange(16, 20)
        )
    }

    private fun parseIpv6(packet: ByteArray, length: Int): TcpSegment? {
        if (length < IPV6_HEADER + MIN_TCP_HEADER) return null
        val payloadLength = u16(packet, 4)
        if (payloadLength == 0) return null // Jumbograms are not part of this bounded datapath.
        val packetEnd = IPV6_HEADER + payloadLength
        if (packetEnd > length) return null

        var nextHeader = packet[6].toInt() and 0xff
        var offset = IPV6_HEADER
        while (nextHeader != TCP_PROTOCOL) {
            if (offset + 2 > packetEnd) return null
            val following = packet[offset].toInt() and 0xff
            val extensionLength = when (nextHeader) {
                IPV6_HOP_BY_HOP, IPV6_ROUTING, IPV6_DESTINATION_OPTIONS ->
                    ((packet[offset + 1].toInt() and 0xff) + 1) * 8
                IPV6_AUTHENTICATION ->
                    ((packet[offset + 1].toInt() and 0xff) + 2) * 4
                IPV6_FRAGMENT -> {
                    if (offset + 8 > packetEnd) return null
                    val fragmentField = u16(packet, offset + 2)
                    if ((fragmentField and 0x0006) != 0 || (fragmentField and 0xfff9) != 0) return null
                    8
                }
                else -> return null
            }
            if (extensionLength < 8 || offset + extensionLength > packetEnd) return null
            nextHeader = following
            offset += extensionLength
        }

        return parseTcp(
            packet = packet,
            packetEnd = packetEnd,
            tcpOffset = offset,
            ipVersion = 6,
            sourceAddress = packet.copyOfRange(8, 24),
            destinationAddress = packet.copyOfRange(24, 40)
        )
    }

    private fun parseTcp(
        packet: ByteArray,
        packetEnd: Int,
        tcpOffset: Int,
        ipVersion: Int,
        sourceAddress: ByteArray,
        destinationAddress: ByteArray
    ): TcpSegment? {
        if (tcpOffset < 0 || tcpOffset + MIN_TCP_HEADER > packetEnd) return null
        val headerLength = ((packet[tcpOffset + 12].toInt() ushr 4) and 0x0f) * 4
        if (headerLength !in MIN_TCP_HEADER..60 || tcpOffset + headerLength > packetEnd) return null

        val sequence = u32(packet, tcpOffset + 4)
        val acknowledgement = u32(packet, tcpOffset + 8)
        val flags = ((packet[tcpOffset + 12].toInt() and 1) shl 8) or
            (packet[tcpOffset + 13].toInt() and 0xff)
        val payloadStart = tcpOffset + headerLength

        return TcpSegment(
            ipVersion = ipVersion,
            sourceAddress = sourceAddress,
            destinationAddress = destinationAddress,
            sourcePort = u16(packet, tcpOffset),
            destinationPort = u16(packet, tcpOffset + 2),
            sequenceNumber = sequence,
            acknowledgementNumber = acknowledgement,
            flags = flags,
            windowSize = u16(packet, tcpOffset + 14),
            urgentPointer = u16(packet, tcpOffset + 18),
            options = packet.copyOfRange(tcpOffset + MIN_TCP_HEADER, payloadStart),
            payload = packet.copyOfRange(payloadStart, packetEnd)
        )
    }

    /** Builds an RFC-style reset in response to an incoming segment. */
    fun buildResetForIncoming(segment: TcpSegment, mtu: Int = 1500): ByteArray? {
        if (segment.isRst) return null
        val sequence: Long
        val acknowledgement: Long
        val resetFlags: Int
        if (segment.isAck) {
            sequence = segment.acknowledgementNumber
            acknowledgement = 0
            resetFlags = FLAG_RST
        } else {
            sequence = 0
            val consumed = segment.payload.size.toLong() +
                (if (segment.isSyn) 1 else 0) + (if (segment.isFin) 1 else 0)
            acknowledgement = (segment.sequenceNumber + consumed) and 0xffff_ffffL
            resetFlags = FLAG_RST or FLAG_ACK
        }
        return build(
            ipVersion = segment.ipVersion,
            sourceAddress = segment.destinationAddress,
            destinationAddress = segment.sourceAddress,
            sourcePort = segment.destinationPort,
            destinationPort = segment.sourcePort,
            sequenceNumber = sequence,
            acknowledgementNumber = acknowledgement,
            flags = resetFlags,
            windowSize = 0,
            mtu = mtu
        )
    }

    fun build(
        ipVersion: Int,
        sourceAddress: ByteArray,
        destinationAddress: ByteArray,
        sourcePort: Int,
        destinationPort: Int,
        sequenceNumber: Long,
        acknowledgementNumber: Long,
        flags: Int,
        windowSize: Int,
        payload: ByteArray = ByteArray(0),
        tcpOptions: ByteArray = ByteArray(0),
        mtu: Int = 1500
    ): ByteArray? {
        if (sourcePort !in 0..65_535 || destinationPort !in 0..65_535) return null
        if (sequenceNumber !in 0..0xffff_ffffL || acknowledgementNumber !in 0..0xffff_ffffL) return null
        if (flags !in 0..0x1ff || windowSize !in 0..65_535 || mtu < 576) return null
        if (tcpOptions.size > 40 || tcpOptions.size % 4 != 0) return null
        val ipHeaderLength = when (ipVersion) {
            4 -> if (sourceAddress.size == 4 && destinationAddress.size == 4) IPV4_HEADER else return null
            6 -> if (sourceAddress.size == 16 && destinationAddress.size == 16) IPV6_HEADER else return null
            else -> return null
        }
        val tcpHeaderLength = MIN_TCP_HEADER + tcpOptions.size
        val totalLength = ipHeaderLength + tcpHeaderLength + payload.size
        if (totalLength > mtu || totalLength > MAX_PACKET_SIZE) return null
        if (ipVersion == 6 && totalLength - IPV6_HEADER > 65_535) return null

        val packet = ByteArray(totalLength)
        val tcpOffset = ipHeaderLength
        if (ipVersion == 4) {
            packet[0] = 0x45
            put16(packet, 2, totalLength)
            packet[8] = 64
            packet[9] = TCP_PROTOCOL.toByte()
            sourceAddress.copyInto(packet, 12)
            destinationAddress.copyInto(packet, 16)
        } else {
            packet[0] = 0x60
            put16(packet, 4, totalLength - IPV6_HEADER)
            packet[6] = TCP_PROTOCOL.toByte()
            packet[7] = 64
            sourceAddress.copyInto(packet, 8)
            destinationAddress.copyInto(packet, 24)
        }

        put16(packet, tcpOffset, sourcePort)
        put16(packet, tcpOffset + 2, destinationPort)
        put32(packet, tcpOffset + 4, sequenceNumber)
        put32(packet, tcpOffset + 8, acknowledgementNumber)
        packet[tcpOffset + 12] = (((tcpHeaderLength / 4) shl 4) or ((flags ushr 8) and 1)).toByte()
        packet[tcpOffset + 13] = flags.toByte()
        put16(packet, tcpOffset + 14, windowSize)
        put16(packet, tcpOffset + 18, 0)
        tcpOptions.copyInto(packet, tcpOffset + MIN_TCP_HEADER)
        payload.copyInto(packet, tcpOffset + tcpHeaderLength)

        val tcpLength = totalLength - tcpOffset
        val tcpChecksum = if (ipVersion == 4) {
            tcpChecksumV4(sourceAddress, destinationAddress, packet, tcpOffset, tcpLength)
        } else {
            tcpChecksumV6(sourceAddress, destinationAddress, packet, tcpOffset, tcpLength)
        }
        put16(packet, tcpOffset + 16, if (tcpChecksum == 0) 0xffff else tcpChecksum)
        if (ipVersion == 4) put16(packet, 10, checksum(packet, 0, IPV4_HEADER))
        return packet
    }

    fun isValidTcpChecksum(segment: TcpSegment, packet: ByteArray): Boolean {
        val parsed = parse(packet) ?: return false
        if (parsed.ipVersion != segment.ipVersion || parsed.sourcePort != segment.sourcePort ||
            parsed.destinationPort != segment.destinationPort ||
            !parsed.sourceAddress.contentEquals(segment.sourceAddress) ||
            !parsed.destinationAddress.contentEquals(segment.destinationAddress)) return false
        val tcpOffset = if (segment.ipVersion == 4) (packet[0].toInt() and 0x0f) * 4 else findIpv6TcpOffset(packet) ?: return false
        val totalLength = if (segment.ipVersion == 4) u16(packet, 2) else IPV6_HEADER + u16(packet, 4)
        val tcpLength = totalLength - tcpOffset
        if (tcpLength < MIN_TCP_HEADER || tcpOffset + tcpLength > packet.size) return false
        val checksumValue = if (segment.ipVersion == 4) {
            tcpChecksumV4(segment.sourceAddress, segment.destinationAddress, packet, tcpOffset, tcpLength)
        } else {
            tcpChecksumV6(segment.sourceAddress, segment.destinationAddress, packet, tcpOffset, tcpLength)
        }
        return checksumValue == 0
    }

    private fun findIpv6TcpOffset(packet: ByteArray): Int? {
        if (packet.size < IPV6_HEADER) return null
        val end = IPV6_HEADER + u16(packet, 4)
        if (end > packet.size) return null
        var next = packet[6].toInt() and 0xff
        var offset = IPV6_HEADER
        while (next != TCP_PROTOCOL) {
            if (offset + 2 > end) return null
            val following = packet[offset].toInt() and 0xff
            val size = when (next) {
                IPV6_HOP_BY_HOP, IPV6_ROUTING, IPV6_DESTINATION_OPTIONS ->
                    ((packet[offset + 1].toInt() and 0xff) + 1) * 8
                IPV6_AUTHENTICATION -> ((packet[offset + 1].toInt() and 0xff) + 2) * 4
                IPV6_FRAGMENT -> 8
                else -> return null
            }
            if (offset + size > end) return null
            next = following
            offset += size
        }
        return offset
    }

    private fun tcpChecksumV4(
        source: ByteArray,
        destination: ByteArray,
        packet: ByteArray,
        offset: Int,
        length: Int
    ): Int {
        var sum = 0L
        sum = addWords(sum, source, 0, source.size)
        sum = addWords(sum, destination, 0, destination.size)
        sum += TCP_PROTOCOL.toLong()
        sum += length.toLong()
        sum = addWords(sum, packet, offset, length)
        return finishChecksum(sum)
    }

    private fun tcpChecksumV6(
        source: ByteArray,
        destination: ByteArray,
        packet: ByteArray,
        offset: Int,
        length: Int
    ): Int {
        var sum = 0L
        sum = addWords(sum, source, 0, source.size)
        sum = addWords(sum, destination, 0, destination.size)
        sum += ((length ushr 16) and 0xffff).toLong()
        sum += (length and 0xffff).toLong()
        sum += TCP_PROTOCOL.toLong()
        sum = addWords(sum, packet, offset, length)
        return finishChecksum(sum)
    }

    private fun checksum(bytes: ByteArray, offset: Int, length: Int): Int =
        finishChecksum(addWords(0L, bytes, offset, length))

    private fun addWords(initial: Long, bytes: ByteArray, offset: Int, length: Int): Long {
        var sum = initial
        var index = offset
        val end = offset + length
        while (index + 1 < end) {
            sum += (((bytes[index].toInt() and 0xff) shl 8) or
                (bytes[index + 1].toInt() and 0xff)).toLong()
            index += 2
        }
        if (index < end) sum += ((bytes[index].toInt() and 0xff) shl 8).toLong()
        return sum
    }

    private fun finishChecksum(value: Long): Int {
        var sum = value
        while ((sum ushr 16) != 0L) sum = (sum and 0xffff) + (sum ushr 16)
        return sum.inv().toInt() and 0xffff
    }

    private fun u16(bytes: ByteArray, offset: Int): Int =
        ((bytes[offset].toInt() and 0xff) shl 8) or (bytes[offset + 1].toInt() and 0xff)

    private fun u32(bytes: ByteArray, offset: Int): Long =
        ((bytes[offset].toLong() and 0xff) shl 24) or
            ((bytes[offset + 1].toLong() and 0xff) shl 16) or
            ((bytes[offset + 2].toLong() and 0xff) shl 8) or
            (bytes[offset + 3].toLong() and 0xff)

    private fun put16(bytes: ByteArray, offset: Int, value: Int) {
        bytes[offset] = (value ushr 8).toByte()
        bytes[offset + 1] = value.toByte()
    }

    private fun put32(bytes: ByteArray, offset: Int, value: Long) {
        bytes[offset] = (value ushr 24).toByte()
        bytes[offset + 1] = (value ushr 16).toByte()
        bytes[offset + 2] = (value ushr 8).toByte()
        bytes[offset + 3] = value.toByte()
    }

    private const val IPV6_HOP_BY_HOP = 0
    private const val IPV6_ROUTING = 43
    private const val IPV6_FRAGMENT = 44
    private const val IPV6_AUTHENTICATION = 51
    private const val IPV6_DESTINATION_OPTIONS = 60
}
