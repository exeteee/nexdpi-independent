package com.exeteee.nexdpi.vpn

/**
 * Bounded rolling TCP receive window. Contiguous bytes are returned immediately and released,
 * so long-lived streams can exceed the configured memory window without growing memory use.
 */
class TcpSlidingWindow(
    initialSequenceNumber: Long,
    private val capacity: Int = DEFAULT_CAPACITY
) {
    private val bytes = ByteArray(validateCapacity(capacity))
    private val present = BooleanArray(capacity)
    private var baseSequence = validateSequence(initialSequenceNumber)
    private var head = 0
    private var buffered = 0
    private var failed = false

    @Synchronized
    fun accept(sequenceNumber: Long, payload: ByteArray): ByteArray? {
        if (failed || sequenceNumber !in 0..SEQUENCE_MASK) return fail()
        if (payload.isEmpty()) return ByteArray(0)

        val forward = (sequenceNumber - baseSequence) and SEQUENCE_MASK
        val signedOffset = if (forward >= HALF_SEQUENCE_SPACE) forward - SEQUENCE_SPACE else forward
        val trimPrefix = if (signedOffset < 0) -signedOffset else 0L
        if (trimPrefix >= payload.size.toLong()) return ByteArray(0)
        val offset = if (signedOffset < 0) 0L else signedOffset
        val sourceOffset = trimPrefix.toInt()
        val effectiveLength = payload.size - sourceOffset
        if (offset + effectiveLength > capacity.toLong()) return fail()

        for (index in 0 until effectiveLength) {
            val ringIndex = (head + offset.toInt() + index) % capacity
            val incoming = payload[sourceOffset + index]
            if (present[ringIndex]) {
                if (bytes[ringIndex] != incoming) return fail()
            } else {
                bytes[ringIndex] = incoming
                present[ringIndex] = true
                buffered++
            }
        }

        var contiguousLength = 0
        while (contiguousLength < capacity && present[(head + contiguousLength) % capacity]) {
            contiguousLength++
        }
        if (contiguousLength == 0) return ByteArray(0)

        val contiguous = ByteArray(contiguousLength)
        for (index in 0 until contiguousLength) {
            contiguous[index] = bytes[head]
            bytes[head] = 0
            present[head] = false
            head = (head + 1) % capacity
            buffered--
        }
        baseSequence = (baseSequence + contiguousLength) and SEQUENCE_MASK
        return contiguous
    }

    @Synchronized
    fun nextSequence(): Long = baseSequence

    @Synchronized
    fun bufferedBytes(): Int = buffered

    @Synchronized
    fun isFailed(): Boolean = failed

    @Synchronized
    fun clear() {
        bytes.fill(0)
        present.fill(false)
        head = 0
        buffered = 0
        failed = false
        // Clear deliberately preserves baseSequence; the instance is not reused across TCP flows.
    }

    private fun fail(): ByteArray? {
        failed = true
        bytes.fill(0)
        present.fill(false)
        buffered = 0
        return null
    }

    companion object {
        const val DEFAULT_CAPACITY = 65_536
        const val MAX_CAPACITY = 65_536
        private const val SEQUENCE_SPACE = 0x1_0000_0000L
        private const val HALF_SEQUENCE_SPACE = 0x8000_0000L
        private const val SEQUENCE_MASK = 0xffff_ffffL

        private fun validateSequence(value: Long): Long {
            require(value in 0..SEQUENCE_MASK) { "TCP sequence number must be unsigned 32-bit" }
            return value
        }

        private fun validateCapacity(value: Int): Int {
            require(value in 1..MAX_CAPACITY) { "TCP receive window capacity must be 1..$MAX_CAPACITY" }
            return value
        }
    }
}
