package com.exeteee.nexdpi.vpn

/** Result of routing one complete IP packet inside the local userspace VPN. */
enum class PacketDispatchResult {
    DNS,
    UDP,
    TCP,
    QUIC_BLOCKED_FOR_TCP_FALLBACK,
    TCP_DNS_REJECTED,
    DROPPED
}

/**
 * Protocol-aware packet dispatcher. DNS/UDP/TCP are handed to independent local engines.
 * QUIC (UDP/443) is denied by default so applications can retry HTTPS over TCP/TLS,
 * which is handled by the TLS ClientHello inspection/splitting path. This is a compatibility
 * fallback for networks that disrupt HTTP/3; it is not a bypass for destination-IP blocking.
 */
class NexDpiPacketDispatcher(
    private val onDns: (DnsUdpQuery) -> Unit,
    private val onUdp: (UdpDatagram) -> Unit,
    private val onTcp: (ByteArray) -> Unit,
    private val onTcpDns: (ByteArray) -> Unit,
    private val forceTcpFallbackForQuic: Boolean = true
) {
    fun dispatch(packet: ByteArray): PacketDispatchResult {
        val datagram = UdpPacketCodec.parse(packet)
        if (datagram != null) {
            if (datagram.destinationPort == 53) {
                val dnsQuery = DnsPacketCodec.parseQuery(packet) ?: return PacketDispatchResult.DROPPED
                onDns(dnsQuery)
                return PacketDispatchResult.DNS
            }
            // QUIC/HTTP3 normally uses UDP/443. Dropping it makes TCP-based HTTPS available
            // to apps that implement QUIC fallback, and routes that TCP through the TLS engine.
            if (forceTcpFallbackForQuic && datagram.destinationPort == QUIC_PORT) {
                return PacketDispatchResult.QUIC_BLOCKED_FOR_TCP_FALLBACK
            }
            onUdp(datagram)
            return PacketDispatchResult.UDP
        }

        val segment = TcpPacketCodec.parse(packet) ?: return PacketDispatchResult.DROPPED
        if (!TcpPacketCodec.isValidTcpChecksum(segment, packet)) return PacketDispatchResult.DROPPED
        if (segment.destinationPort == 53) {
            val reset = TcpPacketCodec.buildResetForIncoming(segment) ?: return PacketDispatchResult.DROPPED
            onTcpDns(reset)
            return PacketDispatchResult.TCP_DNS_REJECTED
        }
        onTcp(packet.copyOf())
        return PacketDispatchResult.TCP
    }

    companion object {
        private const val QUIC_PORT = 443
    }
}
