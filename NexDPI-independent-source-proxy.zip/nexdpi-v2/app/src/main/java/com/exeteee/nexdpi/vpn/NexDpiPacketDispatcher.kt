package com.exeteee.nexdpi.vpn

/** Result of routing one complete IP packet inside the local userspace VPN. */
enum class PacketDispatchResult { DNS, UDP, TCP, TCP_DNS_REJECTED, DROPPED }

/**
 * Protocol-aware packet dispatcher. DNS/UDP/TCP are handed to independent local engines;
 * unsupported IP protocols are deliberately dropped rather than leaked around the VPN.
 */
class NexDpiPacketDispatcher(
    private val onDns: (DnsUdpQuery) -> Unit,
    private val onUdp: (UdpDatagram) -> Unit,
    private val onTcp: (ByteArray) -> Unit,
    private val onTcpDns: (ByteArray) -> Unit
) {
    fun dispatch(packet: ByteArray): PacketDispatchResult {
        val datagram = UdpPacketCodec.parse(packet)
        if (datagram != null) {
            if (datagram.destinationPort == 53) {
                val dnsQuery = DnsPacketCodec.parseQuery(packet) ?: return PacketDispatchResult.DROPPED
                onDns(dnsQuery)
                return PacketDispatchResult.DNS
            }
            onUdp(datagram)
            return PacketDispatchResult.UDP
        }

        val segment = TcpPacketCodec.parse(packet) ?: return PacketDispatchResult.DROPPED
        if (!TcpPacketCodec.isValidTcpChecksum(segment, packet)) return PacketDispatchResult.DROPPED
        if (segment.destinationPort == 53) {
            val reset = TcpPacketCodec.buildResetForIncoming(segment) ?: return PacketDispatchResult.DROPPED
            onTcpDns(reset)
            return PacketDispatchResult.TCP_DNS_REJECTED
        }
        onTcp(packet.copyOf())
        return PacketDispatchResult.TCP
    }
}
