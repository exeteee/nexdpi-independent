package com.exeteee.nexdpi.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NexColors = darkColorScheme(
    primary = Color(0xFFC8FF4D),
    onPrimary = Color(0xFF11170A),
    secondary = Color(0xFF9CBF62),
    background = Color(0xFF080D12),
    surface = Color(0xFF111A23),
    onBackground = Color(0xFFF0F4EA),
    onSurface = Color(0xFFF0F4EA),
    outline = Color(0xFF33414D)
)

@Composable
fun NexDpiTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = NexColors,
        content = content
    )
}
