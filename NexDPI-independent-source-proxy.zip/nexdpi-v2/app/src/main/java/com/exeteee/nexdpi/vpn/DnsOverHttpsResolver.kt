package com.exeteee.nexdpi.vpn

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.Base64
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

/**
 * Local DNS transport with ordered DoH fallback. The app itself is excluded from
 * the VPN, so these HTTPS connections use the underlying Android network and do
 * not recurse into the virtual DNS address. OkHttp negotiates HTTP/2 for providers
 * that no longer accept HTTP/1.1.
 */
class DnsOverHttpsResolver {
    private data class Upstream(val name: String, val endpoint: String)

    private val upstreams = listOf(
        Upstream("Cloudflare", "https://cloudflare-dns.com/dns-query"),
        Upstream("Google", "https://dns.google/dns-query"),
        Upstream("Quad9", "https://dns.quad9.net/dns-query")
    )
    // Keep one preferred provider to avoid scattering every DNS query across vendors.
    // Switch only when the current provider fails or returns SERVFAIL/REFUSED.
    private val preferredProvider = AtomicInteger(0)
    private val client = OkHttpClient.Builder()
        .dns(DohBootstrapDns())
        .protocols(listOf(Protocol.HTTP_2, Protocol.HTTP_1_1))
        .connectTimeout(CONNECT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .readTimeout(READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .callTimeout(CALL_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    @Throws(IOException::class)
    fun resolve(query: ByteArray): ByteArray {
        val start = Math.floorMod(preferredProvider.get(), upstreams.size)
        var lastError: Exception? = null

        for (offset in upstreams.indices) {
            val index = (start + offset) % upstreams.size
            val upstream = upstreams[index]
            try {
                val result = request(upstream, query)
                val responseCode = result[3].toInt() and 0x0f
                if (responseCode == DNS_RCODE_SERVFAIL || responseCode == DNS_RCODE_REFUSED) {
                    throw IOException("${upstream.name}: DNS response code $responseCode")
                }
                preferredProvider.set(index)
                return result
            } catch (error: Exception) {
                lastError = error
            }
        }

        throw IOException("All encrypted DNS providers failed", lastError)
    }

    private fun request(upstream: Upstream, query: ByteArray): ByteArray {
        return try {
            executeRequest(upstream, query, useGet = false)
        } catch (unsupported: UnsupportedPostException) {
            if (query.size > MAX_GET_QUERY_BYTES) throw unsupported
            // RFC 8484 GET fallback for endpoints or networks that reject POST.
            executeRequest(upstream, query, useGet = true)
        }
    }

    private fun executeRequest(
        upstream: Upstream,
        query: ByteArray,
        useGet: Boolean
    ): ByteArray {
        val requestBuilder = Request.Builder()
            .header("Accept", DNS_MEDIA_TYPE.toString())
            .header("Cache-Control", "no-cache")
        val request = if (useGet) {
            val encodedQuery = Base64.getUrlEncoder().withoutPadding().encodeToString(query)
            requestBuilder
                .url("${upstream.endpoint}?dns=$encodedQuery")
                .get()
                .build()
        } else {
            requestBuilder
                .url(upstream.endpoint)
                .post(query.toRequestBody(DNS_MEDIA_TYPE))
                .build()
        }

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                if (!useGet && response.code in UNSUPPORTED_POST_CODES) {
                    throw UnsupportedPostException(upstream.name, response.code)
                }
                throw IOException("${upstream.name}: HTTP ${response.code}")
            }
            val responseBody = response.body
                ?: throw IOException("${upstream.name}: empty response")
            val contentType = responseBody.contentType()
            if (contentType?.type != "application" || contentType.subtype != "dns-message") {
                throw IOException("${upstream.name}: invalid DoH content type")
            }
            val responseBytes = responseBody.byteStream().use { input ->
                val output = ByteArrayOutputStream()
                val buffer = ByteArray(4096)
                var total = 0
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    total += count
                    if (total > MAX_RESPONSE_BYTES) throw IOException("DNS response too large")
                    output.write(buffer, 0, count)
                }
                output.toByteArray()
            }
            if (!DnsPacketCodec.isValidDnsResponse(query, responseBytes)) {
                throw IOException("${upstream.name}: invalid or truncated DNS response")
            }
            return responseBytes
        }
    }

    private class UnsupportedPostException(provider: String, statusCode: Int) :
        IOException("$provider: POST not supported (HTTP $statusCode)")

    companion object {
        private val DNS_MEDIA_TYPE = "application/dns-message".toMediaType()
        private const val CONNECT_TIMEOUT_SECONDS = 2L
        private const val READ_TIMEOUT_SECONDS = 3L
        private const val CALL_TIMEOUT_SECONDS = 4L
        private const val MAX_RESPONSE_BYTES = 65_000
        private const val DNS_RCODE_SERVFAIL = 2
        private const val DNS_RCODE_REFUSED = 5
        private const val MAX_GET_QUERY_BYTES = 1_024
        private val UNSUPPORTED_POST_CODES = setOf(405, 415, 501)
    }
}
